/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G350X

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)


#define GPIO_HFXT_PORT                                                     GPIOA
#define GPIO_HFXIN_PIN                                             DL_GPIO_PIN_5
#define GPIO_HFXIN_IOMUX                                         (IOMUX_PINCM10)
#define GPIO_HFXOUT_PIN                                            DL_GPIO_PIN_6
#define GPIO_HFXOUT_IOMUX                                        (IOMUX_PINCM11)
#define CPUCLK_FREQ                                                     80000000



/* Defines for PWM_RIGHT */
#define PWM_RIGHT_INST                                                     TIMG7
#define PWM_RIGHT_INST_IRQHandler                               TIMG7_IRQHandler
#define PWM_RIGHT_INST_INT_IRQN                                 (TIMG7_INT_IRQn)
#define PWM_RIGHT_INST_CLK_FREQ                                         40000000
/* GPIO defines for channel 0 */
#define GPIO_PWM_RIGHT_C0_PORT                                             GPIOA
#define GPIO_PWM_RIGHT_C0_PIN                                     DL_GPIO_PIN_28
#define GPIO_PWM_RIGHT_C0_IOMUX                                   (IOMUX_PINCM3)
#define GPIO_PWM_RIGHT_C0_IOMUX_FUNC                  IOMUX_PINCM3_PF_TIMG7_CCP0
#define GPIO_PWM_RIGHT_C0_IDX                                DL_TIMER_CC_0_INDEX

/* Defines for PWM_LEFT */
#define PWM_LEFT_INST                                                      TIMA0
#define PWM_LEFT_INST_IRQHandler                                TIMA0_IRQHandler
#define PWM_LEFT_INST_INT_IRQN                                  (TIMA0_INT_IRQn)
#define PWM_LEFT_INST_CLK_FREQ                                          40000000
/* GPIO defines for channel 0 */
#define GPIO_PWM_LEFT_C0_PORT                                              GPIOB
#define GPIO_PWM_LEFT_C0_PIN                                       DL_GPIO_PIN_8
#define GPIO_PWM_LEFT_C0_IOMUX                                   (IOMUX_PINCM25)
#define GPIO_PWM_LEFT_C0_IOMUX_FUNC                  IOMUX_PINCM25_PF_TIMA0_CCP0
#define GPIO_PWM_LEFT_C0_IDX                                 DL_TIMER_CC_0_INDEX

/* Defines for PWM_TURN */
#define PWM_TURN_INST                                                      TIMA1
#define PWM_TURN_INST_IRQHandler                                TIMA1_IRQHandler
#define PWM_TURN_INST_INT_IRQN                                  (TIMA1_INT_IRQn)
#define PWM_TURN_INST_CLK_FREQ                                             50000
/* GPIO defines for channel 0 */
#define GPIO_PWM_TURN_C0_PORT                                              GPIOA
#define GPIO_PWM_TURN_C0_PIN                                      DL_GPIO_PIN_15
#define GPIO_PWM_TURN_C0_IOMUX                                   (IOMUX_PINCM37)
#define GPIO_PWM_TURN_C0_IOMUX_FUNC                  IOMUX_PINCM37_PF_TIMA1_CCP0
#define GPIO_PWM_TURN_C0_IDX                                 DL_TIMER_CC_0_INDEX

/* Defines for PWM_DJ */
#define PWM_DJ_INST                                                        TIMG8
#define PWM_DJ_INST_IRQHandler                                  TIMG8_IRQHandler
#define PWM_DJ_INST_INT_IRQN                                    (TIMG8_INT_IRQn)
#define PWM_DJ_INST_CLK_FREQ                                             5000000
/* GPIO defines for channel 0 */
#define GPIO_PWM_DJ_C0_PORT                                                GPIOA
#define GPIO_PWM_DJ_C0_PIN                                         DL_GPIO_PIN_1
#define GPIO_PWM_DJ_C0_IOMUX                                      (IOMUX_PINCM2)
#define GPIO_PWM_DJ_C0_IOMUX_FUNC                     IOMUX_PINCM2_PF_TIMG8_CCP0
#define GPIO_PWM_DJ_C0_IDX                                   DL_TIMER_CC_0_INDEX



/* Defines for TIMER_0 */
#define TIMER_0_INST                                                     (TIMG0)
#define TIMER_0_INST_IRQHandler                                 TIMG0_IRQHandler
#define TIMER_0_INST_INT_IRQN                                   (TIMG0_INT_IRQn)
#define TIMER_0_INST_LOAD_VALUE                                           (249U)
/* Defines for TIMER_1 */
#define TIMER_1_INST                                                     (TIMG6)
#define TIMER_1_INST_IRQHandler                                 TIMG6_IRQHandler
#define TIMER_1_INST_INT_IRQN                                   (TIMG6_INT_IRQn)
#define TIMER_1_INST_LOAD_VALUE                                           (249U)



/* Defines for UART_2_K210 */
#define UART_2_K210_INST                                                   UART2
#define UART_2_K210_INST_IRQHandler                             UART2_IRQHandler
#define UART_2_K210_INST_INT_IRQN                                 UART2_INT_IRQn
#define GPIO_UART_2_K210_RX_PORT                                           GPIOA
#define GPIO_UART_2_K210_TX_PORT                                           GPIOA
#define GPIO_UART_2_K210_RX_PIN                                   DL_GPIO_PIN_24
#define GPIO_UART_2_K210_TX_PIN                                   DL_GPIO_PIN_21
#define GPIO_UART_2_K210_IOMUX_RX                                (IOMUX_PINCM54)
#define GPIO_UART_2_K210_IOMUX_TX                                (IOMUX_PINCM46)
#define GPIO_UART_2_K210_IOMUX_RX_FUNC                 IOMUX_PINCM54_PF_UART2_RX
#define GPIO_UART_2_K210_IOMUX_TX_FUNC                 IOMUX_PINCM46_PF_UART2_TX
#define UART_2_K210_BAUD_RATE                                           (115200)
#define UART_2_K210_IBRD_40_MHZ_115200_BAUD                                 (21)
#define UART_2_K210_FBRD_40_MHZ_115200_BAUD                                 (45)
/* Defines for UART_0_TEST */
#define UART_0_TEST_INST                                                   UART0
#define UART_0_TEST_INST_IRQHandler                             UART0_IRQHandler
#define UART_0_TEST_INST_INT_IRQN                                 UART0_INT_IRQn
#define GPIO_UART_0_TEST_RX_PORT                                           GPIOA
#define GPIO_UART_0_TEST_TX_PORT                                           GPIOA
#define GPIO_UART_0_TEST_RX_PIN                                   DL_GPIO_PIN_11
#define GPIO_UART_0_TEST_TX_PIN                                   DL_GPIO_PIN_10
#define GPIO_UART_0_TEST_IOMUX_RX                                (IOMUX_PINCM22)
#define GPIO_UART_0_TEST_IOMUX_TX                                (IOMUX_PINCM21)
#define GPIO_UART_0_TEST_IOMUX_RX_FUNC                 IOMUX_PINCM22_PF_UART0_RX
#define GPIO_UART_0_TEST_IOMUX_TX_FUNC                 IOMUX_PINCM21_PF_UART0_TX
#define UART_0_TEST_BAUD_RATE                                           (115200)
#define UART_0_TEST_IBRD_4_MHZ_115200_BAUD                                   (2)
#define UART_0_TEST_FBRD_4_MHZ_115200_BAUD                                  (11)
/* Defines for UART_1_BNO08X */
#define UART_1_BNO08X_INST                                                 UART1
#define UART_1_BNO08X_INST_IRQHandler                           UART1_IRQHandler
#define UART_1_BNO08X_INST_INT_IRQN                               UART1_INT_IRQn
#define GPIO_UART_1_BNO08X_RX_PORT                                         GPIOA
#define GPIO_UART_1_BNO08X_RX_PIN                                  DL_GPIO_PIN_9
#define GPIO_UART_1_BNO08X_IOMUX_RX                              (IOMUX_PINCM20)
#define GPIO_UART_1_BNO08X_IOMUX_RX_FUNC               IOMUX_PINCM20_PF_UART1_RX
#define UART_1_BNO08X_BAUD_RATE                                         (115200)
#define UART_1_BNO08X_IBRD_40_MHZ_115200_BAUD                               (21)
#define UART_1_BNO08X_FBRD_40_MHZ_115200_BAUD                               (45)





/* Defines for DMA_CH0 */
#define DMA_CH0_CHAN_ID                                                      (0)
#define UART_1_BNO08X_INST_DMA_TRIGGER                       (DMA_UART1_RX_TRIG)



/* Port definition for Pin Group OLED */
#define OLED_PORT                                                        (GPIOA)

/* Defines for SCL: GPIOA.26 with pinCMx 59 on package pin 30 */
#define OLED_SCL_PIN                                            (DL_GPIO_PIN_26)
#define OLED_SCL_IOMUX                                           (IOMUX_PINCM59)
/* Defines for SDA: GPIOA.27 with pinCMx 60 on package pin 31 */
#define OLED_SDA_PIN                                            (DL_GPIO_PIN_27)
#define OLED_SDA_IOMUX                                           (IOMUX_PINCM60)
/* Port definition for Pin Group GPIO_Encoder */
#define GPIO_Encoder_PORT                                                (GPIOA)

/* Defines for PIN_A_LEFT: GPIOA.7 with pinCMx 14 on package pin 49 */
// pins affected by this interrupt request:["PIN_A_LEFT","PIN_A_RIGHT"]
#define GPIO_Encoder_INT_IRQN                                   (GPIOA_INT_IRQn)
#define GPIO_Encoder_INT_IIDX                   (DL_INTERRUPT_GROUP1_IIDX_GPIOA)
#define GPIO_Encoder_PIN_A_LEFT_IIDX                         (DL_GPIO_IIDX_DIO7)
#define GPIO_Encoder_PIN_A_LEFT_PIN                              (DL_GPIO_PIN_7)
#define GPIO_Encoder_PIN_A_LEFT_IOMUX                            (IOMUX_PINCM14)
/* Defines for PIN_B_LEFT: GPIOA.8 with pinCMx 19 on package pin 54 */
#define GPIO_Encoder_PIN_B_LEFT_PIN                              (DL_GPIO_PIN_8)
#define GPIO_Encoder_PIN_B_LEFT_IOMUX                            (IOMUX_PINCM19)
/* Defines for PIN_A_RIGHT: GPIOA.12 with pinCMx 34 on package pin 5 */
#define GPIO_Encoder_PIN_A_RIGHT_IIDX                       (DL_GPIO_IIDX_DIO12)
#define GPIO_Encoder_PIN_A_RIGHT_PIN                            (DL_GPIO_PIN_12)
#define GPIO_Encoder_PIN_A_RIGHT_IOMUX                           (IOMUX_PINCM34)
/* Defines for PIN_B_RIGHT: GPIOA.13 with pinCMx 35 on package pin 6 */
#define GPIO_Encoder_PIN_B_RIGHT_PIN                            (DL_GPIO_PIN_13)
#define GPIO_Encoder_PIN_B_RIGHT_IOMUX                           (IOMUX_PINCM35)
/* Port definition for Pin Group GPIO_Motor */
#define GPIO_Motor_PORT                                                  (GPIOB)

/* Defines for PIN_A_1: GPIOB.6 with pinCMx 23 on package pin 58 */
#define GPIO_Motor_PIN_A_1_PIN                                   (DL_GPIO_PIN_6)
#define GPIO_Motor_PIN_A_1_IOMUX                                 (IOMUX_PINCM23)
/* Defines for PIN_A_2: GPIOB.7 with pinCMx 24 on package pin 59 */
#define GPIO_Motor_PIN_A_2_PIN                                   (DL_GPIO_PIN_7)
#define GPIO_Motor_PIN_A_2_IOMUX                                 (IOMUX_PINCM24)
/* Defines for PIN_B_1: GPIOB.24 with pinCMx 52 on package pin 23 */
#define GPIO_Motor_PIN_B_1_PIN                                  (DL_GPIO_PIN_24)
#define GPIO_Motor_PIN_B_1_IOMUX                                 (IOMUX_PINCM52)
/* Defines for PIN_B_2: GPIOB.20 with pinCMx 48 on package pin 19 */
#define GPIO_Motor_PIN_B_2_PIN                                  (DL_GPIO_PIN_20)
#define GPIO_Motor_PIN_B_2_IOMUX                                 (IOMUX_PINCM48)
/* Defines for PIN_STBY: GPIOB.3 with pinCMx 16 on package pin 51 */
#define GPIO_Motor_PIN_STBY_PIN                                  (DL_GPIO_PIN_3)
#define GPIO_Motor_PIN_STBY_IOMUX                                (IOMUX_PINCM16)
/* Port definition for Pin Group KEY */
#define KEY_PORT                                                         (GPIOA)

/* Defines for PIN_Change: GPIOA.2 with pinCMx 7 on package pin 42 */
#define KEY_PIN_Change_PIN                                       (DL_GPIO_PIN_2)
#define KEY_PIN_Change_IOMUX                                      (IOMUX_PINCM7)
/* Defines for PIN_Change_2: GPIOA.16 with pinCMx 38 on package pin 9 */
#define KEY_PIN_Change_2_PIN                                    (DL_GPIO_PIN_16)
#define KEY_PIN_Change_2_IOMUX                                   (IOMUX_PINCM38)
/* Defines for PIN_18: GPIOA.18 with pinCMx 40 on package pin 11 */
#define KEY_PIN_18_PIN                                          (DL_GPIO_PIN_18)
#define KEY_PIN_18_IOMUX                                         (IOMUX_PINCM40)
/* Defines for PIN_1: GPIOA.31 with pinCMx 6 on package pin 39 */
#define Grey_PIN_1_PORT                                                  (GPIOA)
#define Grey_PIN_1_PIN                                          (DL_GPIO_PIN_31)
#define Grey_PIN_1_IOMUX                                          (IOMUX_PINCM6)
/* Defines for PIN_0: GPIOA.0 with pinCMx 1 on package pin 33 */
#define Grey_PIN_0_PORT                                                  (GPIOA)
#define Grey_PIN_0_PIN                                           (DL_GPIO_PIN_0)
#define Grey_PIN_0_IOMUX                                          (IOMUX_PINCM1)
/* Defines for PIN_2: GPIOB.4 with pinCMx 17 on package pin 52 */
#define Grey_PIN_2_PORT                                                  (GPIOB)
#define Grey_PIN_2_PIN                                           (DL_GPIO_PIN_4)
#define Grey_PIN_2_IOMUX                                         (IOMUX_PINCM17)
/* Port definition for Pin Group ShuMaGuan */
#define ShuMaGuan_PORT                                                   (GPIOB)

/* Defines for CLK: GPIOB.2 with pinCMx 15 on package pin 50 */
#define ShuMaGuan_CLK_PIN                                        (DL_GPIO_PIN_2)
#define ShuMaGuan_CLK_IOMUX                                      (IOMUX_PINCM15)
/* Defines for DIO: GPIOB.9 with pinCMx 26 on package pin 61 */
#define ShuMaGuan_DIO_PIN                                        (DL_GPIO_PIN_9)
#define ShuMaGuan_DIO_IOMUX                                      (IOMUX_PINCM26)
/* Defines for PIN_3: GPIOB.5 with pinCMx 18 on package pin 53 */
#define Grey_PIN_3_PORT                                                  (GPIOB)
#define Grey_PIN_3_PIN                                           (DL_GPIO_PIN_5)
#define Grey_PIN_3_IOMUX                                         (IOMUX_PINCM18)
/* Defines for PIN_4: GPIOB.15 with pinCMx 32 on package pin 3 */
#define Grey_PIN_4_PORT                                                  (GPIOB)
#define Grey_PIN_4_PIN                                          (DL_GPIO_PIN_15)
#define Grey_PIN_4_IOMUX                                         (IOMUX_PINCM32)
/* Defines for PIN_5: GPIOB.16 with pinCMx 33 on package pin 4 */
#define Grey_PIN_5_PORT                                                  (GPIOB)
#define Grey_PIN_5_PIN                                          (DL_GPIO_PIN_16)
#define Grey_PIN_5_IOMUX                                         (IOMUX_PINCM33)
/* Defines for PIN_6: GPIOB.12 with pinCMx 29 on package pin 64 */
#define Grey_PIN_6_PORT                                                  (GPIOB)
#define Grey_PIN_6_PIN                                          (DL_GPIO_PIN_12)
#define Grey_PIN_6_IOMUX                                         (IOMUX_PINCM29)
/* Defines for PIN_7: GPIOB.13 with pinCMx 30 on package pin 1 */
#define Grey_PIN_7_PORT                                                  (GPIOB)
#define Grey_PIN_7_PIN                                          (DL_GPIO_PIN_13)
#define Grey_PIN_7_IOMUX                                         (IOMUX_PINCM30)



/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);
void SYSCFG_DL_PWM_RIGHT_init(void);
void SYSCFG_DL_PWM_LEFT_init(void);
void SYSCFG_DL_PWM_TURN_init(void);
void SYSCFG_DL_PWM_DJ_init(void);
void SYSCFG_DL_TIMER_0_init(void);
void SYSCFG_DL_TIMER_1_init(void);
void SYSCFG_DL_UART_2_K210_init(void);
void SYSCFG_DL_UART_0_TEST_init(void);
void SYSCFG_DL_UART_1_BNO08X_init(void);
void SYSCFG_DL_DMA_init(void);

void SYSCFG_DL_SYSTICK_init(void);

bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */
