./objects/uart_host.o: bluetooth\UART_host.c
