./objects/no_mcu_ganv_grayscale_sensor.o: \
  grey_sensor\No_Mcu_Ganv_Grayscale_Sensor.c
