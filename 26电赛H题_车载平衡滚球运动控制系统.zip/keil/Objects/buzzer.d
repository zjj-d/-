./objects/buzzer.o: hardware\buzzer.c
