./objects/adc.o: grey_sensor\adc.c
