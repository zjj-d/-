#ifndef __TM1637_H
#define __TM1637_H

#include "ti_msp_dl_config.h"
#include <stdint.h>

/* ���ź궨�壬���� SysConfig ���ɵ����� */
#define TM_CLK_PORT     ShuMaGuan_PORT
#define TM_CLK_PIN      ShuMaGuan_CLK_PIN
#define TM_DIO_PORT     ShuMaGuan_PORT
#define TM_DIO_PIN      ShuMaGuan_DIO_PIN
#define TM_DIO_IOMUX    ShuMaGuan_DIO_IOMUX  /* ������DIO���ŵ�IOMUX��� */

/* ��ƽ������ */
#define CLK_1           DL_GPIO_setPins(TM_CLK_PORT, TM_CLK_PIN)
#define CLK_0           DL_GPIO_clearPins(TM_CLK_PORT, TM_CLK_PIN)
#define DIO_1           DL_GPIO_setPins(TM_DIO_PORT, TM_DIO_PIN)
#define DIO_0           DL_GPIO_clearPins(TM_DIO_PORT, TM_DIO_PIN)

/* �������� */
void TM1637_Init(void);
void TM1637_start(void);
void TM1637_ack(void);
void TM1637_stop(void);
void TM1637_Write(uint8_t DATA);
void TM1637_display(uint8_t a, uint8_t b, uint8_t c, uint8_t d, uint8_t h);

#endif