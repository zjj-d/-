//#include "UART_host.h"
//#include "uart.h"
//#include "string.h"

//uint16_t calculateChecksum(const uint8_t *data, uint8_t length) //校验和
//{    
//    uint8_t checksum = 0;
//    for(uint8_t i = 0; i < length; i++) 
//    {        
//        checksum += data[i];
//    }    
//    return checksum&0xFF;
//}

//void Create_Packet(const uint8_t *data, uint8_t dataLen)
//{
//   uint8_t index = 0;

//   
//   if(gTXCheckUART_Blue ==  true)
//   {
//		// 构造数据包
//	   gTxPacket_Blue[index++] = packethead;//1包头
//	   for (int i = 0; i < dataLen; i++) 
//	   {
//		   gTxPacket_Blue[index++] = data[i];//4数据
//	   }

//	   // 计算并添加校验和
//	   uint8_t checksum = calculateChecksum(gTxPacket_Blue, index);
//	   gTxPacket_Blue[index++] = checksum;//5校验和
//	   
//	   DL_DMA_setSrcIncrement(DMA, DMA_CH3_CHAN_ID, DL_DMA_ADDR_INCREMENT);
//		DL_DMA_setDestIncrement(DMA, DMA_CH3_CHAN_ID, DL_DMA_ADDR_UNCHANGED); // 目标是 UART TXDATA 寄存器，地址不变
//		/**DMA发送**/
//		DL_DMA_setSrcAddr(DMA, DMA_CH3_CHAN_ID, (uint32_t) &gTxPacket_Blue[0]);
//		DL_DMA_setDestAddr(DMA, DMA_CH3_CHAN_ID, (uint32_t)(&UART_3_BLUE_INST->TXDATA));
//		DL_DMA_setTransferSize(
//			DMA, DMA_CH3_CHAN_ID, sizeof(gTxPacket_Blue) / sizeof(gTxPacket_Blue[0]));
//		gTXCheckUART_Blue = false;
//		gTXDMADone_Blue  = false;
//		DL_DMA_enableChannel(DMA, DMA_CH3_CHAN_ID);
//		/**DMA发送**/
//   }
//	
//}

///**此函数解算来自蓝牙的串口数据**/
//volatile uint16_t Blue_Data=0;//接收蓝牙数据
//uint8_t Uart_Blue_Data[10];//包头：0xCC，包尾校验和
////uint8_t Uart_Location=0;//数字位置
////uint8_t Uart_Wide=0;//红线宽度
////uint8_t Uart_Num=0;//识别的病房号
//uint8_t Blue_Receive_Flag=0;
//uint8_t Blue_ReceiveData(uint8_t RxData)
//{
//	uint8_t Success_Flag = 0;
//	if(Blue_Receive_Flag == 0)
//	{
//		if(RxData == 0xCC)
//		{
//			Blue_Receive_Flag = 1;
//			Uart_Blue_Data[0] = RxData;
//		}
//	}
//	else if(Blue_Receive_Flag >= 1 && Blue_Receive_Flag <= 4)
//	{
//		Uart_Blue_Data[Blue_Receive_Flag] = RxData;
//		Blue_Receive_Flag++;
//	}
//	else if(Blue_Receive_Flag == 5 && RxData == ((0xCC + Uart_Blue_Data[1] + Uart_Blue_Data[2] + Uart_Blue_Data[3] + Uart_Blue_Data[4]) & 0xFF))
//	{
//		
//		Blue_Data = Uart_Blue_Data[1];
//		
////		Black_Line_Data = 0;
////		Black_Line_Data = Black_Line_Data | (Uart_Blue_Data[1] << 8);
////		Black_Line_Data = Black_Line_Data | Uart_Blue_Data[2];
////		Uart_Location = Uart_Blue_Data[4];
////		Uart_Wide = Uart_Blue_Data[3];
////		Uart_Num = Uart_Blue_Data[5];
//		Blue_Receive_Flag = 0;
//		Success_Flag = 1;
//		
//	}
//	else
//	{
//		Blue_Receive_Flag = 0;
//	}
//	 return Success_Flag;
//}