//#ifndef __UART_HOST_H
//#define __UART_HOST_H
//#include "ti_msp_dl_config.h"

////包头，命令，数据长度，数据包，校验和

//#define packethead 0xCC //包头,包尾是校验和
//#define MAX_PACKET_SIZE 256 // 最大 数据包 大小

////#define uart_port   UART_0_INST //串口
////#define uart_irqn   UART_0_INST_INT_IRQN // 中断索引
//typedef struct {
//    uint8_t state;          // 当前状态：0-等待包头，1-命令，2-长度，3-数据，4-校验
//    uint8_t buffer[MAX_PACKET_SIZE];//包
//    uint8_t index;//数据位置索引
//    uint8_t dataLen;//数据长度
//    uint8_t command;//命令
//} PacketReceiver;
////PacketReceiver receiver;//定义一个结构体变量

//extern volatile uint16_t Blue_Data;//接收蓝牙数据

//uint16_t calculateChecksum(const uint8_t *data, uint8_t length);
//void Serial_SendByte(uint8_t Byte);
//uint8_t Blue_ReceiveData(uint8_t RxData);
//void Create_Packet(const uint8_t *data, uint8_t dataLen);//创建发送数据包

//#endif
