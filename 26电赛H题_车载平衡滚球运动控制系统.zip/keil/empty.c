#include "ti_msp_dl_config.h"
#include "OLED.h"
#include "delay.h"
#include "uart.h"
#include "bno08x_uart_rvc.h"
#include "encoder.h"
#include "pid.h"
#include "motor.h"
#include "software_iic.h"
#include "IIC.h"
#include "stdio.h"
#include "buzzer.h"
#include "cradle_head.h"
#include "UART_host.h"
#include "key.h"
#include "stdio.h"
#include "No_Mcu_Ganv_Grayscale_Sensor_Config.h"
#include "SR04.h"
#include "uart_callback.h"
#include "cradle_head.h"
#include "TM1637.h"
#include "DJ.h"
//// 灰度全局变量定义///
//unsigned short Anolog[8]={0};
//unsigned short black[8]={1285,1901,1214,854,845,1615,784,1230};
//unsigned short white[8]={3222,3253,3242,3185,3191,3228,3074,3220};

//unsigned short Normal[8];
//No_MCU_Sensor sensor;              // 传感器数据结构体
//unsigned char Digtal;							 // 数字量
extern volatile uint8_t Calibration_Mode;


//uint8_t Test_Buffer[4]={0x02, 0x89, 0x11, 0x55};
volatile uint8_t Send_BlueData_Flag=0;//
volatile float SR04_Distance=0;
volatile uint8_t Grey_Data=0;//存放灰度传感器的数据
volatile uint8_t Page_Flag=1;//OLED页面
volatile uint8_t Clear_Flag=0;//OLED清屏标志
char Str_Data[50];//串口发送数据的数组
uint8_t Start_Flag=0;//程序开始标志位
volatile uint8_t Question_Flag=0;//题目标志位
extern uint8_t Grey[8];//OLED显示用
uint8_t n = 0;
extern volatile int flag;
//串口初始化放在后面低电平上电会无法进入中断, 串口引脚尽量不要悬空，串口2RX引脚禁止悬空，PA18口尽量不要用
int main(void)
{
	
	SYSCFG_DL_init();

//	No_MCU_Ganv_Sensor_Init(&sensor,white,black);
//	NVIC_EnableIRQ(ADC12_0_INST_INT_IRQN);
	UART_Init();
	// Delay_ms(2500);

	BNO08X_Init();// 陀螺仪初始化，上电位置为初始0值
//	 UART_Init_Bluetooth();
	Encoder_Init();
	OLED_Init();
	Key_Init();

//	SR04_Init();
	Total_PID_Init();	
	
	//清除定时器中断标志
	NVIC_ClearPendingIRQ(TIMER_0_INST_INT_IRQN);
	// //使能定时器中断
	NVIC_EnableIRQ(TIMER_0_INST_INT_IRQN);
	//清除定时器中断标志
	NVIC_ClearPendingIRQ(TIMER_1_INST_INT_IRQN);
	//使能定时器中断
	NVIC_EnableIRQ(TIMER_1_INST_INT_IRQN);

	Motor_Start();//打开电机
	Q3_Servo_Init();//舵机上电即回到机械中位
	/* 2. 初始化TM1637（设置空闲电平） */
    TM1637_Init();

	/* 3. 调用显示函数，示例：显示 12:34 最后一位为中间感叹号*/
	    // TM1637_display(1, 0, 3, 4, 0);
		delay_ms(1000);
	while (1)
		 { 
			// Question_Flag = 8;
			// Start_Flag = 1;
		if(Page_Flag == 1)
				{
				// 	OLED_ShowString(0, 0, "Grey:", OLED_6X8);
				// 	OLED_ShowSignedNum(13, 0, Grey[0], 1, OLED_6X8);
				// 	OLED_ShowSignedNum(26, 0, Grey[1], 1, OLED_6X8);
				// 	OLED_ShowSignedNum(40, 0, Grey[2], 1, OLED_6X8);
				// 	OLED_ShowSignedNum(53, 0, Grey[3], 1, OLED_6X8);
				// 	OLED_ShowSignedNum(66, 0, Grey[4], 1, OLED_6X8);
				// 	OLED_ShowSignedNum(79, 0, Grey[5], 1, OLED_6X8);
				// 	OLED_ShowSignedNum(84, 0, Grey[6], 1, OLED_6X8);
				// 	OLED_ShowSignedNum(100, 0, Grey[7], 1, OLED_6X8);
				//   OLED_Update();
					OLED_ShowString(0, 0, "Y:", OLED_6X8);
					OLED_ShowSignedNum(13, 0, bno08x_data.yaw, 3, OLED_6X8);
					OLED_ShowString(0, 10, "P:", OLED_6X8);
					OLED_ShowSignedNum(13, 10, bno08x_data.pitch, 3, OLED_6X8);
					OLED_ShowString(0, 20, " Q3:", OLED_6X8);
					OLED_ShowSignedNum(13, 20, Question_3_Flag, 2, OLED_6X8);

					OLED_ShowString(46, 0, "Gx:", OLED_6X8);
					OLED_ShowSignedNum(70, 0, bno08x_data.ax, 4, OLED_6X8);
					OLED_ShowString(46, 10, "Gy:", OLED_6X8);
					OLED_ShowSignedNum(70, 10, bno08x_data.ay, 4, OLED_6X8);
					OLED_ShowString(46, 20, "Gz:", OLED_6X8);
					OLED_ShowSignedNum(70, 20, bno08x_data.az , 4, OLED_6X8);

					OLED_ShowString(0, 30, "L_S:", OLED_6X8);
					OLED_ShowSignedNum(26, 30, EncoderCnt_L, 4, OLED_6X8);
					OLED_ShowString(0, 40, "R_S:", OLED_6X8);
					OLED_ShowSignedNum(26, 40, EncoderCnt_R, 4, OLED_6X8);

					OLED_ShowString(58, 30, "L_D:", OLED_6X8);
					OLED_ShowSignedNum(84, 30, Distance_Left, 4, OLED_6X8);

					OLED_ShowString(58, 40, "R_D:", OLED_6X8);
					OLED_ShowSignedNum(84, 40, Distance_Right, 4, OLED_6X8);
					// OLED_ShowString(0, 50, "Grey:", OLED_6X8);
					// OLED_ShowSignedNum(32, 50, Grey_Data, 3,  OLED_6X8);
					OLED_ShowString(0, 50, "H_D:", OLED_6X8);
//					OLED_ShowSignedNum(26, 50, HC_distance, 3, OLED_6X8);
//					OLED_ShowString(62, 50, "Q:", OLED_6X8);

					// OLED_ShowSignedNum(34, 50, Black_Line_Data, 3,  OLED_6X8);
					OLED_ShowNum(70, 50, Question_Flag, 2, OLED_6X8);
					OLED_ShowString(85, 50, "C:", OLED_6X8);
					OLED_ShowNum(98, 50, Question_Circle_Num, 2, OLED_6X8);

					OLED_Update();
				}
				else if(Page_Flag == 0)
				{
					OLED_ShowString(0, 20, "T:", OLED_6X8);
					OLED_ShowFloatNum(10, 20, Uart_Target, 4, 4, OLED_6X8);
					OLED_ShowString(0, 30, "P:", OLED_6X8);
					OLED_ShowFloatNum(10, 30, Uart_KP, 4, 4, OLED_6X8);
					OLED_ShowString(0, 40, "I:", OLED_6X8);
					OLED_ShowFloatNum(10, 40, Uart_KI, 4 , 4, OLED_6X8);
					OLED_ShowString(0, 50, "D:", OLED_6X8);
					OLED_ShowFloatNum(10, 50, Uart_KD, 4, 4, OLED_6X8);


					OLED_ShowString(0, 10, "MV:", OLED_6X8);
					OLED_ShowSignedNum(20, 10, Black_Line_Data, 3,  OLED_6X8);
					
					
					OLED_Update();
				}
				else if (Page_Flag == 2)
				{
					
					OLED_Update();
				}
				
				if(Clear_Flag == 0)
				{
					OLED_Clear();
					Clear_Flag = 1;
					
				}      
				
    }
}


uint8_t UART0_Reset_Flag=0;
uint8_t UART2_Reset_Flag=0;
uint8_t UART3_Reset_Flag=0;


void Timer_DataHandle(void);
//10ms控制一次
void TIMER_0_INST_IRQHandler(void)
{
//		 DL_GPIO_togglePins(LED_PORT, LED_PIN_14_PIN);
    //如果产生了定时器中断
//	 DL_GPIO_togglePins(LED_PORT, LED_PIN_14_PIN);
		/**串口DMA发送到蓝牙**/
    switch( DL_TimerG_getPendingInterrupt(TIMER_0_INST) )
    {
        case DL_TIMER_IIDX_ZERO://如果是0溢出中断
					
					Timer_DataHandle();//处理传感器数据
					uart_work();				//解算K230数据
// PWM_Output(1,1000);
// PWM_Output(0,1000);
					if(Start_Flag == 1)
					{
						Car_PID_Calculate();
					}
						
					break;
        default://其他的定时器中断
            break;    
    }
//	DL_GPIO_togglePins(LED_PORT, LED_PIN_14_PIN);
}

//5ms运算一次距离
void TIMER_1_INST_IRQHandler(void)
{

    //如果产生了定时器中断
    switch( DL_TimerG_getPendingInterrupt(TIMER_1_INST) )
    {
      case DL_TIMER_IIDX_ZERO://如果是0溢出中断
			// DL_GPIO_togglePins(LED_PORT, LED_PIN_14_PIN);
			EncoderCnt_L = Encoder_Get_Speed(ENCODER_LEFT);//获取左轮实际速度cm/s
			EncoderCnt_R = Encoder_Get_Speed(ENCODER_RIGHT);//获取右轮实际速度cm/s
			Distance_Left += EncoderCnt_L * 0.005;//计算左轮路程
			Distance_Right += EncoderCnt_R * 0.005;//计算右轮路程
			break;

        default://其他的定时器中断
            break; 
    }

}

void Timer_DataHandle(void)
{
	/**按键检测**/
	Key_Handle();
	/**按键检测**/

		UART2_Reset_Flag = 0;

//	/**解算摄像头数据**/
//	
//	/**蓝牙数据接收解析**/
//	if (Uart_Calculate_Blue_Data() == 1) {
//		// 蓝牙数据解析成功，Blue_Data 为收到的数据
//		// 可以在这里处理蓝牙指令，例如控制小车运动
//	}
	
}