#ifndef __UART_H__
#define __UART_H__

#include "ti_msp_dl_config.h"
extern uint16_t Speed_Data;//Vofa发送的速度数据
extern char Str_Data[50];//串口发送数据的数组
extern volatile uint16_t Black_Line_Data;//OPENMV接收的数据
extern volatile float Uart_KP, Uart_KI, Uart_KD;//VOFA调试PID接收的PID参数
extern volatile float Uart_Target;//VOFA+发送的目标值
extern volatile uint8_t Uart_Camera_Data[14];
extern  uint8_t uart_rx_len_ ;

#define UART_PACKET_SIZE (33)
#define UART_PACKET_SIZE_K210 (15)
#define UART_PACKET_SIZE_BLUE (6)    // 蓝牙协议帧：0xCC + 4数据 + 校验和

extern volatile uint8_t gRxPacket_K210[UART_PACKET_SIZE_K210];
extern volatile uint8_t gRxPacket_K210_2[UART_PACKET_SIZE_K210];

extern volatile uint8_t gRxPacket_Blue[UART_PACKET_SIZE_BLUE];
extern volatile uint8_t gRxPacket_Blue_2[UART_PACKET_SIZE_BLUE];

extern volatile uint8_t VOFA_Flag;
extern volatile uint8_t gTxPacket_Blue[UART_PACKET_SIZE_BLUE];//串口DMA发送蓝牙数据的数组
extern volatile uint8_t gTXCheckUART_Blue;//串口发送完成标志位
extern volatile uint8_t gTXDMADone_Blue;//串口DMA搬运完成标志


void UART_Init(void);
void UART_Init_K210(void);
void uart0_send_char(UART_Regs *UARTX, char ch);
void uart0_send_string(UART_Regs *UARTX,  char* str);
void Uart_ReceivePID_Data(uint8_t RxData);

int uart_work(void); //串口函数
uint8_t Uart_Calculate_GY62_Data(void);
uint8_t Uart_Calculate_K210_Data(void);
uint8_t Uart_Calculate_Blue_Data(void);
//void UART_Init_Bluetooth(void);
void UART_Reset(uint8_t Uart_X);
/**蓝牙发送函数**/
void uart3_blue_send(uint8_t data);
void uart3_blue_send_array(uint8_t *data, uint8_t len);
#endif
