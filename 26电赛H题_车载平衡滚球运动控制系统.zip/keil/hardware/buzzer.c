//#include "buzzer.h"


////打开蜂鸣器，PA22
//void Buzzer_Open(void)
//{
//	DL_GPIO_setPins(Buzzer_PORT, Buzzer_pin_PIN);
//}
////关闭蜂鸣器，PA22
//void Buzzer_Close(void)
//{
//	DL_GPIO_clearPins(Buzzer_PORT, Buzzer_pin_PIN);
//}    

////打开电磁铁，PA0      低电平触发
//void ChiTie_Open(void)
//{
//	DL_GPIO_clearPins(ChiTie_PORT, ChiTie_chitie_PIN);
//}
////关闭电磁铁，PA0
//void ChiTie_Close(void)
//{
//	DL_GPIO_setPins(ChiTie_PORT, ChiTie_chitie_PIN);
//}    