#ifndef __ENCODER_H__
#define __ENCODER_H__

#include "ti_msp_dl_config.h"

#define ENCODER_LEFT    0
#define ENCODER_RIGHT   1

extern float EncoderCnt_L;//左编码器计数值
extern float EncoderCnt_R;//右编码器计数值
extern float Distance_Left;//左轮路程
extern float Distance_Right;//右轮路程
extern volatile uint8_t Page_Flag;//OLED页面
extern volatile uint8_t Clear_Flag;//清屏标志
void Encoder_Init(void);
	
float Encoder_Get_Speed(uint8_t Encoder_x);
extern uint8_t Start_Flag;//程序开始标志位

extern volatile int32_t EncoderPos_Left;   // 累计位置（脉冲数）
extern volatile int32_t EncoderPos_Right;
void Encoder_UpdatePosition(void);         // 位置累加函数（在读取速度前调用）
float Encoder_GetDistance(uint8_t encoder); // 可选：获取物理距离（脉冲×系数）

#endif