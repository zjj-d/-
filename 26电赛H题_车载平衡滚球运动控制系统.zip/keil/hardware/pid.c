 #include "bno08x_uart_rvc.h"
#include "pid.h"
#include "motor.h"
#include "encoder.h"
#include "uart.h"
#include "gw_grayscale_sensor.h"
#include "stdio.h"
#include "SR04.h"
#include "UART_host.h"
#include "Fuzzy_pid.h"
#include "cradle_head.h"
#include "stdlib.h"
#include "No_Mcu_Ganv_Grayscale_Sensor_Config.h"
#include <math.h>
#include "TM1637.h"
#include "DJ.h"

// 初始化PID控制器
void PID_Init(PID_Structure* pid, float Kp, float Ki, float Kd, float Output_Limit, float Target_Value) 
{
    pid->Kp = Kp;
    pid->Ki = Ki;
    pid->Kd = Kd;
    pid->Output_Limit = Output_Limit;
    pid->Prev_Error = 0.0f;
    pid->Integral = 0.0f;
	pid->Target_Value = Target_Value;
}
FuzzyPIDController FZ_Grey_BlackLine_Pid;
PID_Structure Speed_Left_Pid;//左轮PID初始化,0.5-·1m/s的PID
PID_Structure Speed_Right_Pid;//右轮PID初始化,0.5-1m/s的PID;

PID_Structure Position_Left_Pid;   // 左轮位置环
PID_Structure Position_Right_Pid;  // 右轮位置环

PID_Structure Grey_BlackLine_Pid;//灰度循迹PID
PID_Structure NO_Speed_Turn_Pid_Out;//无速度转向外环
PID_Structure NO_Speed_Turn_Pid_In;//无速度转向内环
PID_Structure Target_Tracking_X;
PID_Structure Target_Tracking_Y;


PID_Structure PID_Structure_Steer_X;//舵机增量式PID结构体
// PID_Structure PID_Structure_Steer_Y;//步进电机增量式PID结构体
// PID_Structure_Incremental PID_Structure_Steer_X;//步进电机增量式PID结构体
// PID_Structure_Incremental PID_Structure_Steer_Y;//步进电机增量式PID结构体


void Total_PID_Init(void) 
{
	/**无速度转向环**/
	PID_Init(&NO_Speed_Turn_Pid_Out,  5, 0.2, 0, 160, 0);
	PID_Init(&NO_Speed_Turn_Pid_In,  -16, -0.5, 6, 4000, 0);
	/**无速度转向环**/

	/**速度环**/
	PID_Init(&Speed_Left_Pid, 33, 1.2, 0, 4000, 0);//左轮PID初始化,0.8m/s*
	PID_Init(&Speed_Right_Pid,  33, 1.2, 0, 4000, 0);//右轮PID初始化,0.8m/s
	/**速度环**/
	 
	/*位置环*/
	PID_Init(&Position_Left_Pid,  2.0f, 0.1f, 0.0f, 100.0f, 0);  // 输出目标速度上限100
	PID_Init(&Position_Right_Pid, 2.0f, 0.1f, 0.0f, 100.0f, 0);
	
	/**灰度循迹PID */
//	PID_Init(&Grey_BlackLine_Pid,  0.8, -0, -0.55, 70, 0);//灰度循迹PID，0.3m/s
	PID_Init(&Grey_BlackLine_Pid,  0.95, -0, -0.35, 100, 0);//灰度循迹PID，0.4m/s 0.45
	/**灰度循迹PID */

	/**步进电机PID */
	//舵机PID
PID_Init(&PID_Structure_Steer_X, -0.142, 0.00, -0.021, 200, 0);//云台X轴PID初始化，降低增益减少过冲
	// PID_Init(&PID_Structure_Steer_Y,  -0.19, 0.0, -0.022, 200, 0);//云台Y轴PID初始化，降低增益减少过冲
//	PID_Init(&PID_Structure_Steer_X, -0.0142, 0.00, -0.021, 200, 0);//云台X轴PID初始化，降低增益减少过冲
//	PID_Init(&PID_Structure_Steer_Y,  -0.019, 0.0, -0.022, 200, 0);//云台Y轴PID初始化，降低增益减少过冲
	

}




// 单级PID计算函数（角度输入）
float PID_Calculate(PID_Structure* pid, float Current_Value) 
{
	// 1. 计算当前误差
	float Error = pid->Target_Value - Current_Value;

	// 2. 积分项计算（带抗饱和）
	pid->Integral += Error;
	// 积分限幅防止饱和
	if (pid->Integral > pid->Output_Limit) pid->Integral = pid->Output_Limit;
	else if (pid->Integral < -pid->Output_Limit) pid->Integral = -pid->Output_Limit;

	// 3. 微分项计算（使用两次误差差）
	float derivative = Error - pid->Prev_Error; // KD采用两次误差差

	// 4. 计算PID输出
	float Output = (pid->Kp * Error)           // 比例项
				+ (pid->Ki * pid->Integral)    // 积分项
				+ (pid->Kd * derivative);      // 微分项（重点）

	// 5. 输出限幅
	if (Output > pid->Output_Limit) Output = pid->Output_Limit;
	else if (Output < -pid->Output_Limit) Output = -pid->Output_Limit;

	// 6. 更新误差记录
	pid->Prev_Error = Error;

	return Output;
}
// 单级PID计算函数,微分项采用陀螺仪角速度
float PID_Calculate_2(PID_Structure* pid, float Current_Value, int16_t Angle_Speed) 
{
	// 1. 计算当前误差
	float Error = pid->Target_Value - Current_Value;

	// 2. 积分项计算（带抗饱和）
	pid->Integral += Error;
	// 积分限幅防止饱和
	if (pid->Integral > pid->Output_Limit) pid->Integral = pid->Output_Limit;
	else if (pid->Integral < -pid->Output_Limit) pid->Integral = -pid->Output_Limit;



	// 4. 计算PID输出
	float Output = (pid->Kp * Error)           // 比例项
				+ (pid->Ki * pid->Integral)    // 积分项
				+ (pid->Kd * Angle_Speed);      // 微分项（重点）

	// 5. 输出限幅
	if (Output > pid->Output_Limit) Output = pid->Output_Limit;
	else if (Output < -pid->Output_Limit) Output = -pid->Output_Limit;

	return Output;
}

// 角度环专用PID函数
float PID_Calculate_No_Speed(PID_Structure* pid, float Current_Value, int16_t Angle_Speed) 
{
	// 1. 计算当前误差
	float Error = pid->Target_Value - Current_Value;
    if (Error > 180) 
	Error -= 360;   // 误差>180°时顺时针修正
    else if(Error < -180) 
	Error += 360; // 误差<-180°时逆时针修正

	// 2. 积分项计算（带抗饱和）
	pid->Integral += Error;
	// 积分限幅防止饱和
	if (pid->Integral > pid->Output_Limit) pid->Integral = pid->Output_Limit;
	else if (pid->Integral < -pid->Output_Limit) pid->Integral = -pid->Output_Limit;



	// 4. 计算PID输出
	float Output = (pid->Kp * Error)           // 比例项
				+ (pid->Ki * pid->Integral)    // 积分项
				+ (pid->Kd * Angle_Speed);      // 微分项（重点）

	// 5. 输出限幅
	if (Output > pid->Output_Limit) Output = pid->Output_Limit;
	else if (Output < -pid->Output_Limit) Output = -pid->Output_Limit;

	return Output;
}

// 初始化增量式PID参数
void PID_Incremental_Init(PID_Structure_Incremental* pid, 
                          float Kp, float Ki, float Kd, 
                          float DeltaOutput_Limit, float Target_Value) 
{
    pid->Kp = Kp;
    pid->Ki = Ki;
    pid->Kd = Kd;
    pid->DeltaOutput_Limit = DeltaOutput_Limit;
    pid->Target_Value = Target_Value;
    pid->Prev_Error = 0.0f;
    pid->Prev_Error2 = 0.0f;
}

// 增量式PID计算函数（返回控制增量）
float PID_Incremental_Calculate(PID_Structure_Incremental* pid, float Current_Value) 
{
    // 1. 计算当前误差
    float Error = pid->Target_Value - Current_Value;

    // 2. 计算增量式PID三项
    float P = pid->Kp * (Error - pid->Prev_Error);           // 比例项：当前与上次误差差
    float I = pid->Ki * Error;                              // 积分项：当前误差
    float D = pid->Kd * (Error - 2*pid->Prev_Error + pid->Prev_Error2); // 微分项：误差变化率

    // 3. 计算控制增量
    float DeltaOutput = P + I + D;

    // 4. 增量限幅（防止突变）
    if (DeltaOutput > pid->DeltaOutput_Limit) 
        DeltaOutput = pid->DeltaOutput_Limit;
    else if (DeltaOutput < -pid->DeltaOutput_Limit) 
        DeltaOutput = -pid->DeltaOutput_Limit;

    // 5. 更新误差记录
    pid->Prev_Error2 = pid->Prev_Error;
    pid->Prev_Error = Error;

    return DeltaOutput;  // 返回控制增量
}

int16_t Left_Speed_PID_Out;
int16_t Right_Speed_PID_Out;
int16_t Angle_PID_Out=0;



/**状态机参数**/
/*********************************接收的K230坐标*****************************************************/
volatile int16_t x_site,y_site;

/**状态机参数**/
int16_t Grey_Current_Line_Data=0;
//int16_t Weight_Grey[5]={-40, -25, -0, 18, 40};//0.3-0.5m/s权重
// int16_t Weight_Grey[8]={-99, -73, -10, -0.2, 0.2, 10, 73, 99};//0.7m/s权重
volatile int16_t Weight_Grey[8]={-65, -38, -18, -3, 3, 18, 38, 65};//0.8m/s权重
volatile uint8_t Road_Flag=1;//判断一次路口左转,0:左转中，1：直行中,2:直行起步阶段，不判断转弯
volatile uint8_t Road_Flag_Last=1;//判断一次路口左转,0:左转中，1：直行中
volatile uint8_t Stop_Flag=0;//停止标志位，1：停止
volatile int16_t Grey_Speed=20;//灰度循迹速度
volatile uint8_t clear_flag=0;
volatile uint8_t clear_cnt=0;	
volatile uint8_t Grey[8];//OLED显示用
volatile int8_t Grey_sum= 0 ;//灰度传感器数字量总和
void Calculate_Grey_Data(void)
{
	 
    Grey_Data = 0;
	 Grey_sum = 0;
    volatile uint8_t Weight_Tem[8] = {0};
		uint8_t edge_only_flag = 0;                // 跳变标志
		static int16_t last_valid_grey_data = 0;   // 上一次可靠的偏差值
		static uint8_t last_grey_sum = 0;          // 上一轮的触发总数
    // ---------- 1. 读取8路灰度传感器，记录哪些传感器看到黑线 ----------
    for (uint8_t i = 0; i < 8; i++)
    {
        switch(i)
        {
            case 0:
                if(DL_GPIO_readPins(Grey_PIN_0_PORT, Grey_PIN_0_PIN) == 0)
                {
                    Weight_Tem[0] = 1;
                    Grey_Data |= (0x01 << i);
                }
                break;
            case 1:
                if(DL_GPIO_readPins(Grey_PIN_1_PORT, Grey_PIN_1_PIN) == 0)
                {
                    Weight_Tem[1] = 1;
                    Grey_Data |= (0x01 << i);
                }
                break;
            case 2:
                if(DL_GPIO_readPins(Grey_PIN_2_PORT, Grey_PIN_2_PIN) == 0)
                {
                    Weight_Tem[2] = 1;
                    Grey_Data |= (0x01 << i);
                }
                break;
            case 3:
                if(DL_GPIO_readPins(Grey_PIN_3_PORT, Grey_PIN_3_PIN) == 0)
                {
                    Weight_Tem[3] = 1;
                    Grey_Data |= (0x01 << i);
                }
                break;
            case 4:
                if(DL_GPIO_readPins(Grey_PIN_4_PORT, Grey_PIN_4_PIN) == 0)
                {
                    Weight_Tem[4] = 1;
                    Grey_Data |= (0x01 << i);
                }
                break;
            case 5:
                if(DL_GPIO_readPins(Grey_PIN_5_PORT, Grey_PIN_5_PIN) == 0)
                {
                    Weight_Tem[5] = 1;
                    Grey_Data |= (0x01 << i);
                }
                break;   
            case 6:
                if(DL_GPIO_readPins(Grey_PIN_6_PORT, Grey_PIN_6_PIN) == 0)
                {
                    Weight_Tem[6] = 1;
                    Grey_Data |= (0x01 << i);
                }
                break;   
            case 7:
                if(DL_GPIO_readPins(Grey_PIN_7_PORT, Grey_PIN_7_PIN) == 0)
                {
                    Weight_Tem[7] = 1;
                    Grey_Data |= (0x01 << i);
                }
                break;
        }
    }
	for(uint8_t i = 0; i < 8; i++)
	{
		Grey[i] = Weight_Tem[i];
		if(Weight_Tem[i] == 1)
		{
			
			Grey_sum += 1;
		}
	}
	
	// ---- 跳变检测 + 偏差处理 ---- //
    if (Grey_sum >= 5)   // 横线干扰，保持
    {
        Grey_Current_Line_Data = last_valid_grey_data;
    }
    else if (Grey_sum == 0)   // 丢线，保持
    {
        Grey_Current_Line_Data = last_valid_grey_data;
    }
    else
    {
        // 判断是否属于“左侧单触发”跳变
        uint8_t left_edge_jump = 0;
        if (Grey_sum == 1 && last_grey_sum >= 2)
        {
            // 检查唯一触发的传感器是否是左侧三个（索引0,1,2）之一
            if (Weight_Tem[0] == 1 || Weight_Tem[1] == 1 || Weight_Tem[2] == 1)
            {
                left_edge_jump = 1;   // 认定为左边缘异常跳变
            }
        }

        if (left_edge_jump)
        {
            // 跳变发生，使用上一次可靠偏差，不更新记录
            Grey_Current_Line_Data = last_valid_grey_data;
        }
        else
        {
            // 正常情况：使用你原有的覆盖逻辑计算偏差
            Grey_Current_Line_Data = 0;   // 初值
            for (int8_t i = 0; i <= 3; i++)
            {
                if(Weight_Tem[i] == 1)
                    Grey_Current_Line_Data = Weight_Grey[i];
            }
            for (uint8_t i = 4; i < 8; i++)
            {
                if(Weight_Tem[i] == 1)
                    Grey_Current_Line_Data = Weight_Grey[i];
            }

            // 更新可靠记录（只有非跳变时才更新）
            last_valid_grey_data = Grey_Current_Line_Data;
        }
    }

    // 记录本轮触发总数
    last_grey_sum = Grey_sum;
}
int32_t Grey_Black_Line_PID_Out=0;
int32_t Distance_PID_Out=0;
 /**灰度循迹串级PID **/
void Execute_PID_INTimer_Grey_Black(void)
{

	Calculate_Grey_Data();//处理灰度传感器数据
 	Grey_BlackLine_Pid.Target_Value = 0;//设置循迹PID目标值
//	Distance_Structure.Target_Value = 0;//设定距离值
//	  Grey_BlackLine_Pid.Kp = Uart_KP;
//	  Grey_BlackLine_Pid.Ki = Uart_KI;
//	 Grey_BlackLine_Pid.Kd = -Uart_KD;
//	Speed_Left_Pid.Kp = Uart_KP;
//	Speed_Left_Pid.Ki = Uart_KI;
//	Speed_Left_Pid.Kd = Uart_KD;
//	Speed_Left_Pid.Target_Value = Uart_Target;
	 
	Grey_Black_Line_PID_Out = (int32_t)PID_Calculate(&Grey_BlackLine_Pid, Grey_Current_Line_Data);//灰度循迹PID,外环
//	
//	sprintf(Str_Data, "%d, %d, %f\n",Grey_Current_Line_Data,Grey_Black_Line_PID_Out, Uart_Target);
//	 uart0_send_string(UART_0_TEST_INST , Str_Data);
	// Grey_Black_Line_PID_Out = (int32_t)FuzzyPID_Compute(&FZ_Grey_BlackLine_Pid, 0, (float)Grey_Current_Line_Data);
	// sprintf(Str_Data, "%f, %f, %f, %f\n", FZ_Grey_BlackLine_Pid.Kp, FZ_Grey_BlackLine_Pid.Ki, FZ_Grey_BlackLine_Pid.Kd, Uart_Target);
	// uart0_send_string(UART_0_TEST_INST , Str_Data);
	
	Speed_Left_Pid.Target_Value = Grey_Speed - Grey_Black_Line_PID_Out ;//读取串口发的速度，速度一般0.5m/s，1m/s
	Speed_Right_Pid.Target_Value = Grey_Speed + Grey_Black_Line_PID_Out ;//读取串口发的速度，速度一般0.5m/s，1m/s

 	Left_Speed_PID_Out = (int32_t)PID_Calculate(&Speed_Left_Pid, EncoderCnt_L);//计算左轮速度环PID
 	Right_Speed_PID_Out = (int32_t)PID_Calculate(&Speed_Right_Pid, EncoderCnt_R);//计算右轮速度环PI
	PWM_Output(MOTOR_LEFT, Left_Speed_PID_Out);//PWM作用到电机
	PWM_Output(MOTOR_RIGHT, Right_Speed_PID_Out);//PWM作用到电机
	sprintf((char *)Str_Data, "%.f,%.f\r \n",EncoderCnt_L, Uart_Target);
	 uart0_send_string(UART_0_TEST_INST , (char *)Str_Data);
}

int16_t NO_Speed_Turn_TarhetAngle=0;

int16_t Get_Angle_Turn_90(void)
{
	if(bno08x_data.yaw > 90)
	{
		return (bno08x_data.yaw - 270);
	}
	else 
	{
		return bno08x_data.yaw + 90;
	}
	
}
 /**固定角度转动PID **/
int32_t NO_Speed_Turn_PID_Value_Out=0;//外环输出
int32_t NO_Speed_Turn_PID_Value_In=0;//内环输出
void NO_Speed_Turn_PID(void)
{
//	 NO_Speed_Turn_Pid_Out.Kp = Uart_KP;
//	 NO_Speed_Turn_Pid_Out.Ki = Uart_KI;
//	 NO_Speed_Turn_Pid_Out.Kd = -Uart_KD;

	NO_Speed_Turn_Pid_Out.Target_Value = NO_Speed_Turn_TarhetAngle;
	
	// NO_Speed_Turn_Pid_In.Kp = -Uart_KP;
	// NO_Speed_Turn_Pid_In.Ki = -Uart_KI;
	// NO_Speed_Turn_Pid_In.Kd = Uart_KD;
	
	

	NO_Speed_Turn_PID_Value_Out = (int32_t)PID_Calculate_No_Speed(&NO_Speed_Turn_Pid_Out, bno08x_data.yaw, bno08x_data.az);//灰度循迹PID,外环
	NO_Speed_Turn_Pid_In.Target_Value = NO_Speed_Turn_PID_Value_Out;
	NO_Speed_Turn_PID_Value_In = (int32_t)PID_Calculate(&NO_Speed_Turn_Pid_In, bno08x_data.az);//灰度循迹PID,内环

	PWM_Output(MOTOR_LEFT, NO_Speed_Turn_PID_Value_In);//PWM作用到电机
	PWM_Output(MOTOR_RIGHT, -NO_Speed_Turn_PID_Value_In);//PWM作用到电机
}
//固定角度转向
void Yaw_Angle_Straight(float target_yaw)
{
    // 目标角度
    NO_Speed_Turn_Pid_Out.Target_Value = target_yaw;
    
    // 角度环PID（自带角度跨0°修正+陀螺仪角速度微分项）
    float angle_correct = PID_Calculate_No_Speed(&NO_Speed_Turn_Pid_Out, 
                                                 bno08x_data.yaw, 
                                                 bno08x_data.az);

    // 限制最大纠偏量，防止车身抖动、暴走
    if(angle_correct > 35)  angle_correct = 35;
    if(angle_correct < -35) angle_correct = -35;

    // 差速纠偏：同向速度+左右补偿
    Speed_Left_Pid.Target_Value  = Grey_Speed + angle_correct;
    Speed_Right_Pid.Target_Value = Grey_Speed - angle_correct;

    // 速度环计算+电机输出
    Left_Speed_PID_Out  = (int32_t)PID_Calculate(&Speed_Left_Pid, EncoderCnt_L);
    Right_Speed_PID_Out = (int32_t)PID_Calculate(&Speed_Right_Pid, EncoderCnt_R);

    PWM_Output(MOTOR_LEFT,  Left_Speed_PID_Out);
    PWM_Output(MOTOR_RIGHT, Right_Speed_PID_Out);
}

uint16_t Last_Data_X=0;
uint16_t Last_Data_Y=0;
uint8_t Q3_Stop_Flag=0;

uint8_t KI_Clear_Flag=0;
volatile int16_t x_mubiao=0;//小球离中心坐标目标值（允许负数）
static float Q3_Servo_Angle = 31.2; // 舵机中位角度
volatile float Q3_Kp_New = 0.06f;      // 比例系数 - 控制响应速度
volatile float Q3_Kd_New = 0.7f;       // 微分系数 - 抑制超调/振荡
volatile float Q3_Ki_New = 0.002f;     // 积分系数 - 消除稳态误差
volatile float Q3_Deadband_New = 5;    // 死区阈值 - 误差在此范围内不动作
// ============ 位置控制变量 ============
volatile int16_t Q3_Target_Pos = 0;     // 当前目标位置
volatile int16_t Q3_Target_Goal = 0;    // 最终目标位置
// ============ PID 内部状态 ============
static float Q3_Integral = 0.0f;       // 积分累加器
static float Q3_Ball_Vel = 0.0f;       // 球速度（微分计算用）
static float Q3_Last_Pos = 0.0f;       // 上一次位置（微分计算用）
// ============ 状态机与计数器 ============
volatile uint8_t Q3_State = 0;          // 当前状态（0:停止 1:运行等）
volatile uint16_t Q3_Stay_Cnt = 0;     // 保持计数（到位停留判断）
// ============ 小车运动控制 ============
volatile int16_t Q3_Car_Speed = 0;      // 当前小车速度
volatile int16_t Q3_Car_Last_Speed = 0; // 上一次小车速度
volatile float Q3_Car_Accel = 0.0f;    // 小车加速度
volatile uint16_t Q3_Feedforward_Cnt = 0;  // 前馈持续计数

// case3 舵机闭环控制思路：
// 1) K230 直接给出钢球相对中心的 x 坐标差值 x_site；
// 2) 以 x_site = 0 为目标，让 PID 输出舵机角度的增量；
// 4) 舵机角度每次只做小步调整，并限制在安全范围内，避免过冲。
void Q3_Servo_Init(void)
{
	Q3_Servo_Angle =31.20; // 舵机中位角度  31.2  //减小更低，增大抬高
	PID_Structure_Steer_X.Integral = 0;
	PID_Structure_Steer_X.Prev_Error = 0;
	Set_Servo_Angle(Q3_Servo_Angle);
	// 新PD控制参数
	Q3_Kp_New = 0.12f;
	Q3_Kd_New = 0.36f;
	Q3_Deadband_New = 5;
}

void Q3_Servo_Control(void)
{
	// x_site 已经是相对中心的偏差值；x_site > 0 表示偏右，x_site < 0 表示偏左
	// 死区内不再微调，避免舵机来回抖动
	if (abs(x_site) <= 3)
	{
		PID_Structure_Steer_X.Integral = 0;
		PID_Structure_Steer_X.Prev_Error = 0;
		Set_Servo_Angle(18.7);
		return;
	}

	// 以 x_error -> 0 为闭环目标，PID 输出的是“舵机角度修正量”
	PID_Structure_Steer_X.Target_Value = x_mubiao;
	float DJ_Out = PID_Calculate(&PID_Structure_Steer_X, x_site);

	// 根据 PID 输出累加舵机角度，并限制在机械允许范围内
	Q3_Servo_Angle += -DJ_Out;

	if (Q3_Servo_Angle < 10) 			//软件限位
	{
		Q3_Servo_Angle = 10;
	}
	else if (Q3_Servo_Angle > 40)
	{
		Q3_Servo_Angle = 40;
	}

	Set_Servo_Angle(Q3_Servo_Angle);
}

// 舵机PD控制（带目标位置跟踪）
void Q3_Servo_Control_New(void)
{
	float ball_pos = (float)x_site;
	float error = ball_pos - (float)Q3_Target_Pos;

	// 计算钢球速度
	Q3_Ball_Vel = 0.6f * Q3_Ball_Vel + 0.4f * (ball_pos - Q3_Last_Pos);
	Q3_Last_Pos = ball_pos;

	// 调试输出
	extern char Str_Data[50];
	sprintf((char *)Str_Data, "%.0f,%.0f,%.1f,%.1f\r\n", ball_pos, (float)Q3_Target_Pos, Q3_Servo_Angle, Q3_Ball_Vel);
	uart0_send_string(UART_0_TEST_INST, (char *)Str_Data);

	// 强制刹车
	if (fabsf(error) < 15.0f && fabsf(Q3_Ball_Vel) > 0.5f)
	{
		int need_brake = ((error > 0 && Q3_Ball_Vel < 0) || (error < 0 && Q3_Ball_Vel > 0));
		if (need_brake)
		{
			Q3_Servo_Angle = 31.2f;
			Set_Servo_Angle(Q3_Servo_Angle);
			return;
		}
	}

	// 死区
	if (fabsf(error) <= 5.0f && fabsf(Q3_Ball_Vel) < 1.0f)
	{
		Set_Servo_Angle(Q3_Servo_Angle);
		return;
	}

	// PID计算
	float p_out = Q3_Kp_New * error;
	float abs_vel = fabsf(Q3_Ball_Vel);
	float abs_error = fabsf(error);

	float speed_brake = 1.0f + abs_vel * 0.8f;
	float dist_brake = 1.0f;
	if (abs_error < 100) dist_brake = 1.0f + (100.0f - abs_error) / 25.0f;
	int approaching = ((error > 0 && Q3_Ball_Vel < 0) || (error < 0 && Q3_Ball_Vel > 0));
	float approach_brake = approaching ? 1.8f : 1.0f;
	float d_out = Q3_Kd_New * Q3_Ball_Vel * speed_brake * dist_brake * approach_brake;

	if (fabsf(error) < 30.0f)
		Q3_Integral += error * 0.3f;
	else
		Q3_Integral += error;
	if (Q3_Integral > 200.0f) Q3_Integral = 200.0f;
	if (Q3_Integral < -200.0f) Q3_Integral = -200.0f;
	float i_out = Q3_Ki_New * Q3_Integral;

	float correction = p_out + i_out + d_out;
	float limit = 20.0f;
	if (fabsf(error) > 100) limit = 25.0f;
	if (fabsf(error) > 150) limit = 30.0f;
	if (correction > limit) correction = limit;
	if (correction < -limit) correction = -limit;

	Q3_Servo_Angle = 31.2f - correction;
	if (Q3_Servo_Angle < 3.0f) Q3_Servo_Angle = 3.0f;
	if (Q3_Servo_Angle > 45.0f) Q3_Servo_Angle = 45.0f;

	Set_Servo_Angle(Q3_Servo_Angle);
}

void Clear_KI_ALL(void)//清除所有的PID积分
{
	/**无速度转向环**/
	NO_Speed_Turn_Pid_Out.Integral = 0;
	NO_Speed_Turn_Pid_In.Integral = 0;
	/**无速度转向环**/

	/**速度环**/
	Speed_Left_Pid.Integral = 0;
	Speed_Right_Pid.Integral = 0;

	/**速度环**/
	
	/**灰度循迹PID */ 
	Grey_BlackLine_Pid.Integral = 0;

}
volatile uint8_t Question_3_Flag=1;//题目圈速
volatile uint16_t Question_Circle_Num=1;//题目圈速
volatile uint8_t Question1_Stage=0;//0:循迹，1转弯
volatile uint16_t Question_Cnt=0;//计时
volatile uint16_t Question2_Stop_Flag=0;//计时
volatile uint8_t Question4_Start_Flag=0;//发挥1的小车启动标志
volatile uint16_t timer=0;   //第二题计时，单位10ms
volatile uint8_t flag_5cm=1;    //5cm标志位
volatile uint8_t Brake_Flag = 0;   // 0:正常巡线  1:制动中
volatile uint16_t sec;
volatile uint16_t cs;             // cs = centisecond (百分秒)
volatile uint8_t cs10;     // 百分秒十位
volatile uint8_t cs1 ;        // 百分秒个位
volatile uint8_t s10;		//十位
volatile uint8_t s1;     //个位
volatile uint8_t Q3_Completed = 0;   // 0:未完成, 1:已完成
volatile uint8_t still_cnt = 0;
volatile uint8_t Q3_Brake_Feedforward_Cnt = 0; // 前馈制动计数
void Car_PID_Calculate(void)
{
	switch(Question_Flag)
	{
		case 1://题目1
			Question2_Stop_Flag = 0;
			switch(Question_Circle_Num)
			{
				case 1:
					if((Distance_Left + Distance_Right) / 2 >= 100)
					{
						Stop_Flag = 1;
					}
					break;
				case 2:
					if((Distance_Left + Distance_Right) / 2 >= 360*Question_Circle_Num)
					{
						Stop_Flag = 1;
					}
					break;
				case 3:
					if((Distance_Left + Distance_Right) / 2 >= 360*Question_Circle_Num)
					{
						Stop_Flag = 1;
					}
					break;
				case 4:
					if((Distance_Left + Distance_Right) / 2 >= 360*Question_Circle_Num)
					{
						Stop_Flag = 1;
					}
					break;
				case 5:
					if((Distance_Left + Distance_Right) / 2 >= 360 *Question_Circle_Num)
					{
						Stop_Flag = 1;
					}
					break;
			}
		  
			if(Stop_Flag == 0)//未停止时
			{  
				Execute_PID_INTimer_Grey_Black();
			}
			else 
			{ 
				Motor_Stop();//关闭电机
			}
			break;

			case 2:			//题目2
			int16_t temp0[8] = {-45, -28, -18, -3, 3, 18, 28, 45};
for (int i = 0; i < 8; i++) {
    Weight_Grey[i] = temp0[i];
}
				if (Question2_Stop_Flag == 0)
				{
					timer = 0;
					Question2_Stop_Flag = 1;
				}
			Grey_Speed = 28;
				switch(Question_Circle_Num)
			{
				case 1:
					if(Grey_sum >=5 &&  ((Distance_Left + Distance_Right) / 2) > 100)
					{
						Grey_Speed = 0;
						Clear_KI_ALL();//清除所有的PID积分
						 Brake_Flag = 1;          // 进入制动模式，不直接停车
					}
					break;	
			}

			if(Stop_Flag == 0)//未停止时
			{  
				 if(Brake_Flag == 1)   // 制动模式：速度闭环拉到零
    		{
				PID_Init(&Speed_Left_Pid, 40, 1.5, 0, 4000, 0);//左轮PID初始化,0.8m/s*
				PID_Init(&Speed_Right_Pid,  40, 1.5, 0, 4000, 0);//右轮PID初始化,0.8m/s
      			  // 左右轮目标速度都设为 0，用速度 PID 产生反向 PWM
      		  Speed_Left_Pid.Target_Value  = 0;
      		  Speed_Right_Pid.Target_Value = 0;

     		   // 计算速度环输出（请确认 EncoderCnt_L/R 是速度值）
     		   Left_Speed_PID_Out  = (int32_t)PID_Calculate(&Speed_Left_Pid,  EncoderCnt_L);
     		   Right_Speed_PID_Out = (int32_t)PID_Calculate(&Speed_Right_Pid, EncoderCnt_R);

       		 // 限制制动电流，防止过流（根据你的驱动适当调整）
      		  if(Left_Speed_PID_Out  >  4000) Left_Speed_PID_Out  =  4000;
      		  if(Left_Speed_PID_Out  < -4000) Left_Speed_PID_Out  = -4000;
      		  if(Right_Speed_PID_Out >  4000) Right_Speed_PID_Out =  4000;
      		  if(Right_Speed_PID_Out < -4000) Right_Speed_PID_Out = -4000;

      		  PWM_Output(MOTOR_LEFT,  Left_Speed_PID_Out);
      		  PWM_Output(MOTOR_RIGHT, Right_Speed_PID_Out);
			}
				else if(Brake_Flag == 0)   // 正常巡线模式
				{
				if (timer < 6000)
				{
					timer++;
				}
				Execute_PID_INTimer_Grey_Black();
			}
			}
			else 
			{ 
				Motor_Stop();//关闭电机
			}

			/* 仅两位秒数显示（00~60），其余两位清零 */
			uint16_t sec = timer / 100;
			if (sec > 60)
			{
				sec = 60;
			}
			cs = timer;                  // cs = centisecond (百分秒)
			cs10  = (cs % 100) / 10;      // 百分秒十位
			cs1   = (cs % 100) % 10;      // 百分秒个位
			s10 = (sec / 10) % 10;
			s1 = sec % 10;
			TM1637_display(s10, s1, cs10, cs1, 1);  // 显示时间
			break;
    break;
			case 3:  //题目三
				Question2_Stop_Flag = 0;
				if (!Q3_Completed) {
        if (timer < 6000) timer++;
    }
				switch(Q3_State)
				{
					case 0:  // 移向-70
                timer++;
						if(Q3_Target_Pos > -78)
					{
						Q3_Target_Pos -= 3;
						if(Q3_Target_Pos < -78) Q3_Target_Pos = -78;
					}
					if(abs(x_site + 70) < 20 && fabsf(Q3_Ball_Vel) < 5.0f)
						{ Q3_Stay_Cnt++; if(Q3_Stay_Cnt > 30) { Q3_State = 1; Q3_Stay_Cnt = 0; } }
						else Q3_Stay_Cnt = 0;
						break;
					case 1:  // 渐变到100（从-75逐渐增加）
						if(Q3_Target_Pos < 140)
						{
                            if(Q3_Target_Pos < -30)
							Q3_Target_Pos += 2;  // 每次+2像素
                            else if(Q3_Target_Pos >= -30 && Q3_Target_Pos < 140)
                            Q3_Target_Pos += 1;  // 每次+1像素
							if(Q3_Target_Pos > 140)
							{Q3_Target_Pos = 140;} 
							
            			}
                        if (Q3_Target_Pos >= 10 && (Q3_Ball_Vel) < 1.0f)  {
                			still_cnt++;
                		if (still_cnt >= 5) Q3_Completed = 1;
           				 } else {
                		still_cnt = 0;
						}
						
						break;  
				}
				sec = timer / 100;
                if (sec > 60) sec = 60;
                cs = timer;
                cs10  = (cs % 100) / 10;
                cs1   = (cs % 100) % 10;
                s10 = (sec / 10) % 10;
                s1 = sec % 10;
                TM1637_display(s10, s1, cs10, cs1, 1);
				Q3_Servo_Control_New();
			break;
		case 4:  							// 第四题
			Q3_Kp_New = 0.12f;
			Q3_Kd_New = 0.4f;
			Q3_Target_Pos = 0;
    // 检测小车启动
      if (Grey_Speed > 0 && Q3_Car_Last_Speed == 0)
    {
        Q3_Feedforward_Cnt = 25;   // 原为 50
    }
    Q3_Car_Last_Speed = Grey_Speed;
    // 前馈期间：舵机持续前倾帮助钢球跟上
    if (Q3_Feedforward_Cnt > 0)
    {
        Q3_Feedforward_Cnt--;
        Q3_Servo_Angle = 31.2f +30.0f;  // 前倾35度
        Set_Servo_Angle(Q3_Servo_Angle);
    }
    else
    {
        Q3_Servo_Control_New();
    }
    if (Question2_Stop_Flag == 0)
    {
        timer = 0;
        Question2_Stop_Flag = 1;
    }
    if(Grey_Speed <= 25)
    {
        static uint8_t acc_cnt = 0;
        if (++acc_cnt >= 5) {          // 每3次循环加1，相当于1/3步长
            acc_cnt = 0;
            if (Grey_Speed < 25) 
                Grey_Speed++;
        }
        if(Grey_Speed > 25) Grey_Speed = 25;
    }
				switch(Question_Circle_Num)
			{
				case 1:
					if(Grey_sum >=10)
					{
						Grey_Speed = 0;
						Clear_KI_ALL();//清除所有的PID积分
						 Brake_Flag = 1;          // 进入制动模式，不直接停车
					}
					break;	
			}

			if(Stop_Flag == 0)//未停止时
			{  
				 if(Brake_Flag == 1)   // 制动模式：速度闭环拉到零
    		{
      			  // 左右轮目标速度都设为 0，用速度 PID 产生反向 PWM
      		  Speed_Left_Pid.Target_Value  = 0;
      		  Speed_Right_Pid.Target_Value = 0;

     		   // 计算速度环输出（请确认 EncoderCnt_L/R 是速度值）
     		   Left_Speed_PID_Out  = (int32_t)PID_Calculate(&Speed_Left_Pid,  EncoderCnt_L);
     		   Right_Speed_PID_Out = (int32_t)PID_Calculate(&Speed_Right_Pid, EncoderCnt_R);

       		 // 限制制动电流，防止过流（根据你的驱动适当调整）
      		  if(Left_Speed_PID_Out  >  2000) Left_Speed_PID_Out  =  2000;
      		  if(Left_Speed_PID_Out  < -2000) Left_Speed_PID_Out  = -2000;
      		  if(Right_Speed_PID_Out >  2000) Right_Speed_PID_Out =  2000;
      		  if(Right_Speed_PID_Out < -2000) Right_Speed_PID_Out = -2000;

      		  PWM_Output(MOTOR_LEFT,  Left_Speed_PID_Out);
      		  PWM_Output(MOTOR_RIGHT, Right_Speed_PID_Out);
			}
				else if(Brake_Flag == 0)   // 正常巡线模式
				{

                    if (timer < 6000)
                        timer++;
				Execute_PID_INTimer_Grey_Black();
			}
			}		
			else 
			{ 
				Motor_Stop();//关闭电机
			}
			sec = timer / 100;
                if (sec > 60) sec = 60;
                cs = timer;
                cs10  = (cs % 100) / 10;
                cs1   = (cs % 100) % 10;
                s10 = (sec / 10) % 10;
                s1 = sec % 10;
                TM1637_display(s10, s1, cs10, cs1, 1);
				break;
		case 5: 													 // 第五题
				Q3_Target_Pos = 0;
    // 检测小车启动
    if (Grey_Speed > 0 && Q3_Car_Last_Speed == 0)
    {
        Q3_Feedforward_Cnt = 25;   // 原为 50
    }
    Q3_Car_Last_Speed = Grey_Speed;
    // 前馈期间：舵机持续前倾帮助钢球跟上
    if (Q3_Feedforward_Cnt > 0)
    {
        Q3_Feedforward_Cnt--;
        Q3_Servo_Angle = 31.2f +30.0f;  // 前倾25度
        Set_Servo_Angle(Q3_Servo_Angle);
    }
    else
    {
        Q3_Servo_Control_New();
    }
    if (Question2_Stop_Flag == 0)
    {
        timer = 0;
        Question2_Stop_Flag = 1;
    }
    if(Grey_Speed <= 25)
    {
        Grey_Speed += 1;
        if(Grey_Speed > 25) Grey_Speed = 25;
    }
				switch(Question_Circle_Num)
			{
				case 1:
					if(Grey_sum >=10)
					{
						Grey_Speed = 0;
						Clear_KI_ALL();//清除所有的PID积分
						 Brake_Flag = 1;          // 进入制动模式，不直接停车
					}
					break;	
			}

			if(Stop_Flag == 0)//未停止时
			{  
				 if(Brake_Flag == 1)   // 制动模式：速度闭环拉到零
    		{
      			  // 左右轮目标速度都设为 0，用速度 PID 产生反向 PWM
      		  Speed_Left_Pid.Target_Value  = 0;
      		  Speed_Right_Pid.Target_Value = 0;

     		   // 计算速度环输出（请确认 EncoderCnt_L/R 是速度值）
     		   Left_Speed_PID_Out  = (int32_t)PID_Calculate(&Speed_Left_Pid,  EncoderCnt_L);
     		   Right_Speed_PID_Out = (int32_t)PID_Calculate(&Speed_Right_Pid, EncoderCnt_R);

       		 // 限制制动电流，防止过流（根据你的驱动适当调整）
      		  if(Left_Speed_PID_Out  >  2000) Left_Speed_PID_Out  =  2000;
      		  if(Left_Speed_PID_Out  < -2000) Left_Speed_PID_Out  = -2000;
      		  if(Right_Speed_PID_Out >  2000) Right_Speed_PID_Out =  2000;
      		  if(Right_Speed_PID_Out < -2000) Right_Speed_PID_Out = -2000;

      		  PWM_Output(MOTOR_LEFT,  Left_Speed_PID_Out);
      		  PWM_Output(MOTOR_RIGHT, Right_Speed_PID_Out);
			}
				else if(Brake_Flag == 0)   // 正常巡线模式
				{
					 if (timer < 6000)
                        timer++;
				Execute_PID_INTimer_Grey_Black();
			}
			}
			else 
			{ 
				Motor_Stop();//关闭电机
			}
			sec = timer / 100;
                if (sec > 60) sec = 60;
                cs = timer;
                cs10  = (cs % 100) / 10;
                cs1   = (cs % 100) % 10;
                s10 = (sec / 10) % 10;
                s1 = sec % 10;
                TM1637_display(s10, s1, cs10, cs1, 1);
			break;
			case 6:											//第六题
			int16_t temp[8] = {-3, -3, -3, -3, 3, 5, 8, 10};
for (int i = 0; i < 8; i++) {
    Weight_Grey[i] = temp[i];
}
    		switch(Question_Circle_Num)
    		{
       	 	case 1: Q3_Target_Pos = 240; break;
        	case 2: Q3_Target_Pos = 220; break;
        	case 3: Q3_Target_Pos = 190; break;
        	case 4: Q3_Target_Pos = 170; break;
        	case 5: Q3_Target_Pos = 150; break;
        	case 6: Q3_Target_Pos = 130; break;
        	case 7: Q3_Target_Pos = 105; break;
        	case 8: Q3_Target_Pos = 80;  break;
        	case 9: Q3_Target_Pos = 60;  break;
        	case 10: Q3_Target_Pos = 40; break;
        	case 11: Q3_Target_Pos = 12; break;
        	case 12: Q3_Target_Pos = -10; break;
        	case 13: Q3_Target_Pos = -30; break;
        	case 14: Q3_Target_Pos = -55; break;
        	case 15: Q3_Target_Pos = -80; break;
        	case 16: Q3_Target_Pos = -100; break;
        	case 17: Q3_Target_Pos = -125; break;
        	case 18: Q3_Target_Pos = -142; break;
        	case 19: Q3_Target_Pos = -160; break;
        	case 20: Q3_Target_Pos = -190; break;
        	case 21: Q3_Target_Pos = -210; break;
        	case 22: Q3_Target_Pos = -250; break;
        	default: break;
    }

    // ========== 提前启动制动前馈（车还在走时就开始后仰） ==========
    if(((Distance_Left + Distance_Right) / 2) > 545 && Q3_Brake_Feedforward_Cnt == 0 && Stop_Flag == 0)
    {
        Q3_Brake_Feedforward_Cnt = 20;   // 提前200ms制动前馈
    }

    // ========== 停车检测 ==========
    switch(Question_Circle_Num)
    {
        case 1:
            if(((Distance_Left + Distance_Right) / 2) > 550)
            {
                Grey_Speed = 0;
                Clear_KI_ALL();
                Brake_Flag = 1;
                Stop_Flag = 1;
                Q3_Feedforward_Cnt = 0;
            }
            break;
    }

    // ========== 检测小车启动 ==========
    if (Grey_Speed > 0 && Q3_Car_Last_Speed == 0 && Stop_Flag == 0)
    {
        Q3_Feedforward_Cnt = 25;
        Q3_Brake_Feedforward_Cnt = 0;
    }
    Q3_Car_Last_Speed = Grey_Speed;

    // ========== 电机控制 ==========
    if (Question2_Stop_Flag == 0)
    {
        timer = 0;
        Question2_Stop_Flag = 1;
    }
    if(Stop_Flag == 0)
    {
        if (timer < 6000)
            timer++;
        Execute_PID_INTimer_Grey_Black();
    }
    else
    {
        if(Q3_Brake_Feedforward_Cnt > 0)
        {
            Speed_Left_Pid.Target_Value  = 0;
            Speed_Right_Pid.Target_Value = 0;
            Left_Speed_PID_Out  = (int32_t)PID_Calculate(&Speed_Left_Pid,  EncoderCnt_L);
            Right_Speed_PID_Out = (int32_t)PID_Calculate(&Speed_Right_Pid, EncoderCnt_R);
            if(Left_Speed_PID_Out  >  2000) Left_Speed_PID_Out  =  2000;
            if(Left_Speed_PID_Out  < -2000) Left_Speed_PID_Out  = -2000;
            if(Right_Speed_PID_Out >  2000) Right_Speed_PID_Out =  2000;
            if(Right_Speed_PID_Out < -2000) Right_Speed_PID_Out = -2000;
            PWM_Output(MOTOR_LEFT,  Left_Speed_PID_Out);
            PWM_Output(MOTOR_RIGHT, Right_Speed_PID_Out);
        }
        else
        {
            Motor_Stop();
        }
    }

    // ========== 舵机控制（必须放在电机之后，确保最后写入舵机角度） ==========
    if (Q3_Feedforward_Cnt > 0)
    {
        Q3_Feedforward_Cnt--;
        Q3_Servo_Angle = 31.2f + 30.0f;
        Set_Servo_Angle(Q3_Servo_Angle);
    }
    else if (Q3_Brake_Feedforward_Cnt > 0)
    {
        Q3_Brake_Feedforward_Cnt--;
        Q3_Servo_Angle = 10.0f;
        Set_Servo_Angle(Q3_Servo_Angle);
		Stop_Flag = 1;
    }
    else
    {
        Q3_Servo_Control_New();
    }

    // ========== 显示计时 ==========
    sec = timer / 100;
    if (sec > 60) sec = 60;
    cs = timer;
    cs10  = (cs % 100) / 10;
    cs1   = (cs % 100) % 10;
    s10 = (sec / 10) % 10;
    s1 = sec % 10;
    TM1637_display(s10, s1, cs10, cs1, 1);
    break;
			case 7:  											//题目三   //预防位置
				Question2_Stop_Flag = 0;
				switch(Q3_State)
				{
					case 0:  // 移向-70
					if(Q3_Target_Pos > -73)
					{
						Q3_Target_Pos -= 3;
						if(Q3_Target_Pos < -73) Q3_Target_Pos = -73;
					}
						
						if(abs(x_site + 70) < 20 && fabsf(Q3_Ball_Vel) < 5.0f)
						{ Q3_Stay_Cnt++; if(Q3_Stay_Cnt > 30) { Q3_State = 1; Q3_Stay_Cnt = 0; } }
						else Q3_Stay_Cnt = 0;
						break;
					case 1:  // 渐变到100（从-75逐渐增加）
						if(Q3_Target_Pos < 130)
						{
							Q3_Target_Pos += 1;  // 每次+3像素
							if(Q3_Target_Pos > 130) Q3_Target_Pos = 130;
						}
						break;  
				}
				Q3_Servo_Control_New();
			break;
	case 8:       													//题目四 可停车
			Q3_Kp_New = 0.12f;
			Q3_Kd_New = 0.4f;
			Q3_Target_Pos = 0;

    // ========== 提前启动制动前馈（车还在走时就开始后仰） ==========
    if(((Distance_Left + Distance_Right) / 2) > 144 && Q3_Brake_Feedforward_Cnt == 0 && Stop_Flag == 0)
    {
        Q3_Brake_Feedforward_Cnt = 28;  // 距离90cm时提前启动，持续600ms
    }

    // ========== 停车检测 ==========
    switch(Question_Circle_Num)
    {
        case 1:
            if(((Distance_Left + Distance_Right) / 2) > 150)
            {
                Grey_Speed = 0;
                Clear_KI_ALL();
                Brake_Flag = 1;
                Stop_Flag = 1;
                Q3_Feedforward_Cnt = 0;
            }
            break;
    }

    // ========== 检测小车启动 ==========
    if (Grey_Speed > 0 && Q3_Car_Last_Speed == 0 && Stop_Flag == 0)
    {
        Q3_Feedforward_Cnt = 25;
        Q3_Brake_Feedforward_Cnt = 0;
    }
    Q3_Car_Last_Speed = Grey_Speed;

    // ========== 电机控制（先处理电机） ==========
    if (Question2_Stop_Flag == 0)
    {
        timer = 0;
        Question2_Stop_Flag = 1;
    }
    if(Stop_Flag == 0)
    {
        if (timer < 6000)
            timer++;
        Execute_PID_INTimer_Grey_Black();
    }
    else
    {
        if(Q3_Brake_Feedforward_Cnt > 0)
        {
            Speed_Left_Pid.Target_Value  = 0;
            Speed_Right_Pid.Target_Value = 0;
            Left_Speed_PID_Out  = (int32_t)PID_Calculate(&Speed_Left_Pid,  EncoderCnt_L);
            Right_Speed_PID_Out = (int32_t)PID_Calculate(&Speed_Right_Pid, EncoderCnt_R);
            if(Left_Speed_PID_Out  >  2000) Left_Speed_PID_Out  =  2000;
            if(Left_Speed_PID_Out  < -2000) Left_Speed_PID_Out  = -2000;
            if(Right_Speed_PID_Out >  2000) Right_Speed_PID_Out =  2000;
            if(Right_Speed_PID_Out < -2000) Right_Speed_PID_Out = -2000;
            PWM_Output(MOTOR_LEFT,  Left_Speed_PID_Out);
            PWM_Output(MOTOR_RIGHT, Right_Speed_PID_Out);
        }
        else
        {
            Motor_Stop();
        }
    }

    // ========== 舵机控制（放在电机之后，确保最后写入舵机角度） ==========
    if (Q3_Feedforward_Cnt > 0)
    {
        Q3_Feedforward_Cnt--;
        Q3_Servo_Angle = 31.2f + 30.0f;
        Set_Servo_Angle(Q3_Servo_Angle);
    }
    else if (Q3_Brake_Feedforward_Cnt > 0)
    {
        Q3_Brake_Feedforward_Cnt--;
        Q3_Servo_Angle = 7.0f;
        Set_Servo_Angle(Q3_Servo_Angle);
    }
    else
    {
        Q3_Servo_Control_New();
    }

    sec = timer / 100;
    if (sec > 60) sec = 60;
    cs = timer;
    cs10  = (cs % 100) / 10;
    cs1   = (cs % 100) % 10;
    s10 = (sec / 10) % 10;
    s1 = sec % 10;
    TM1637_display(s10, s1, cs10, cs1, 1);
    break;
	case 9:       													//题目五 可停车
			Q3_Kp_New = 0.12f;
			Q3_Kd_New = 0.4f;
			Q3_Target_Pos = 0;
			int16_t temp1[8] = {-3, -3, -3, -3, 3, 5, 8, 10};
    for (int i = 0; i < 8; i++) {
        Weight_Grey[i] = temp1[i];   // 修改了全局变量
    }
    // ========== 提前启动制动前馈（车还在走时就开始后仰） ==========
    if(((Distance_Left + Distance_Right) / 2) > 545 && Q3_Brake_Feedforward_Cnt == 0 && Stop_Flag == 0)
    {
        Q3_Brake_Feedforward_Cnt = 20; // 距离90cm时提前启动，持续600ms
    }

    // ========== 停车检测 ==========
    switch(Question_Circle_Num)
    {
        case 1:
            if(((Distance_Left + Distance_Right) / 2) > 550 )
            {
                Grey_Speed = 0;
                Clear_KI_ALL();
                Brake_Flag = 1;
                Stop_Flag = 1;
                Q3_Feedforward_Cnt = 0;
            }
            break;
    }

    // ========== 检测小车启动 ==========
    if (Grey_Speed > 0 && Q3_Car_Last_Speed == 0 && Stop_Flag == 0)
    {
        Q3_Feedforward_Cnt = 25;
        Q3_Brake_Feedforward_Cnt = 0;
    }
    Q3_Car_Last_Speed = Grey_Speed;

    // ========== 电机控制（先处理电机） ==========
    if (Question2_Stop_Flag == 0)
    {
        timer = 0;
        Question2_Stop_Flag = 1;
    }

    if(Grey_Speed <= 20 && Stop_Flag == 0)
    {
        static uint8_t acc_cnt = 0;
        if (++acc_cnt >= 5) {
            acc_cnt = 0;
            if (Grey_Speed < 20)
                Grey_Speed++;
        }
        if(Grey_Speed > 20) Grey_Speed = 20;
    }

    if(Stop_Flag == 0)
    {
        if (timer < 6000)
            timer++;
        Execute_PID_INTimer_Grey_Black();
    }
    else
    {
        if(Q3_Brake_Feedforward_Cnt > 0)
        {
            Speed_Left_Pid.Target_Value  = 0;
            Speed_Right_Pid.Target_Value = 0;
            Left_Speed_PID_Out  = (int32_t)PID_Calculate(&Speed_Left_Pid,  EncoderCnt_L);
            Right_Speed_PID_Out = (int32_t)PID_Calculate(&Speed_Right_Pid, EncoderCnt_R);
            if(Left_Speed_PID_Out  >  2000) Left_Speed_PID_Out  =  2000;
            if(Left_Speed_PID_Out  < -2000) Left_Speed_PID_Out  = -2000;
            if(Right_Speed_PID_Out >  2000) Right_Speed_PID_Out =  2000;
            if(Right_Speed_PID_Out < -2000) Right_Speed_PID_Out = -2000;
            PWM_Output(MOTOR_LEFT,  Left_Speed_PID_Out);
            PWM_Output(MOTOR_RIGHT, Right_Speed_PID_Out);
        }
        else
        {
            Motor_Stop();
        }
    }

    // ========== 舵机控制（放在电机之后，确保最后写入舵机角度） ==========
    if (Q3_Feedforward_Cnt > 0)
    {
        Q3_Feedforward_Cnt--;
        Q3_Servo_Angle = 31.2f + 30.0f;
        Set_Servo_Angle(Q3_Servo_Angle);
    }
    else if (Q3_Brake_Feedforward_Cnt > 0)
    {
        Q3_Brake_Feedforward_Cnt--;
        Q3_Servo_Angle = 10.0f;
        Set_Servo_Angle(Q3_Servo_Angle);
    }
    else
    {
        Q3_Servo_Control_New();
    }

    sec = timer / 100;
    if (sec > 60) sec = 60;
    cs = timer;
    cs10  = (cs % 100) / 10;
    cs1   = (cs % 100) % 10;
    s10 = (sec / 10) % 10;
    s1 = sec % 10;
    TM1637_display(s10, s1, cs10, cs1, 1);
    break;

    case 10:       													//题目六 不同目标值不同制动前馈（自适应）
        {
        int16_t temp3[8] = {-3, -3, -3, -3, 3, 5, 8, 10};
        for (int i = 0; i < 8; i++) {
            Weight_Grey[i] = temp3[i];
        }
        switch(Question_Circle_Num)
        {
            case 1: Q3_Target_Pos = 240; break;
            case 2: Q3_Target_Pos = 220; break;
            case 3: Q3_Target_Pos = 190; break;
            case 4: Q3_Target_Pos = 170; break;
            case 5: Q3_Target_Pos = 150; break;
            case 6: Q3_Target_Pos = 130; break;
            case 7: Q3_Target_Pos = 105; break;
            case 8: Q3_Target_Pos = 80;  break;
            case 9: Q3_Target_Pos = 60;  break;
            case 10: Q3_Target_Pos = 40; break;
            case 11: Q3_Target_Pos = 12; break;
            case 12: Q3_Target_Pos = -10; break;
            case 13: Q3_Target_Pos = -30; break;
            case 14: Q3_Target_Pos = -55; break;
            case 15: Q3_Target_Pos = -80; break;
            case 16: Q3_Target_Pos = -100; break;
            case 17: Q3_Target_Pos = -125; break;
            case 18: Q3_Target_Pos = -142; break;
            case 19: Q3_Target_Pos = -160; break;
            case 20: Q3_Target_Pos = -190; break;
            case 21: Q3_Target_Pos = -210; break;
            case 22: Q3_Target_Pos = -250; break;
            default: break;
        }

        // ========== 自适应制动前馈：根据目标位置绝对值调整参数 ==========
        // abs_val: 250→最远(车速快,需提前+大力制动), 10→最近(车速慢,可晚+轻制动)
        int16_t abs_val = Q3_Target_Pos >= 0 ? Q3_Target_Pos : -Q3_Target_Pos;
        if (abs_val > 300) abs_val = 300;

        // 制动触发距离: 540~550 cm（目标远→540提前触发, 目标近→550正常触发）
        float brake_dist = 550.0f - (abs_val * 0.04f);

        // 前馈持续时间: 12~25 ticks（目标远→25 ticks后仰久, 目标近→12 ticks短后仰）
        uint8_t brake_ff_cnt = 12 + (uint8_t)(abs_val * 0.052f);

        // 舵机后仰角度: 6~14度（目标远→14度大力后仰, 目标近→6度轻后仰）
        float brake_servo_angle = 6.0f + (abs_val * 0.032f);

        // ========== 提前启动制动前馈（车还在走时就开始后仰） ==========
        if(((Distance_Left + Distance_Right) / 2) > brake_dist && Q3_Brake_Feedforward_Cnt == 0 && Stop_Flag == 0)
        {
            Q3_Brake_Feedforward_Cnt = brake_ff_cnt;
        }

        // ========== 停车检测 ==========
        switch(Question_Circle_Num)
        {
            case 1:
                if(((Distance_Left + Distance_Right) / 2) > 550)
                {
                    Grey_Speed = 0;
                    Clear_KI_ALL();
                    Brake_Flag = 1;
                    Stop_Flag = 1;
                    Q3_Feedforward_Cnt = 0;
                }
                break;
        }

        // ========== 检测小车启动 ==========
        if (Grey_Speed > 0 && Q3_Car_Last_Speed == 0 && Stop_Flag == 0)
        {
            Q3_Feedforward_Cnt = 25;
            Q3_Brake_Feedforward_Cnt = 0;
        }
        Q3_Car_Last_Speed = Grey_Speed;

        // ========== 电机控制 ==========
        if (Question2_Stop_Flag == 0)
        {
            timer = 0;
            Question2_Stop_Flag = 1;
        }
        if(Stop_Flag == 0)
        {
            if (timer < 6000)
                timer++;
            Execute_PID_INTimer_Grey_Black();
        }
        else
        {
            if(Q3_Brake_Feedforward_Cnt > 0)
            {
                Speed_Left_Pid.Target_Value  = 0;
                Speed_Right_Pid.Target_Value = 0;
                Left_Speed_PID_Out  = (int32_t)PID_Calculate(&Speed_Left_Pid,  EncoderCnt_L);
                Right_Speed_PID_Out = (int32_t)PID_Calculate(&Speed_Right_Pid, EncoderCnt_R);
                if(Left_Speed_PID_Out  >  2000) Left_Speed_PID_Out  =  2000;
                if(Left_Speed_PID_Out  < -2000) Left_Speed_PID_Out  = -2000;
                if(Right_Speed_PID_Out >  2000) Right_Speed_PID_Out =  2000;
                if(Right_Speed_PID_Out < -2000) Right_Speed_PID_Out = -2000;
                PWM_Output(MOTOR_LEFT,  Left_Speed_PID_Out);
                PWM_Output(MOTOR_RIGHT, Right_Speed_PID_Out);
            }
            else
            {
                Motor_Stop();
            }
        }

        // ========== 舵机控制（必须放在电机之后，确保最后写入舵机角度） ==========
        if (Q3_Feedforward_Cnt > 0)
        {
            Q3_Feedforward_Cnt--;
            Q3_Servo_Angle = 31.2f + 30.0f;
            Set_Servo_Angle(Q3_Servo_Angle);
        }
        else if (Q3_Brake_Feedforward_Cnt > 0)
        {
            Q3_Brake_Feedforward_Cnt--;
            Q3_Servo_Angle = brake_servo_angle;
            Set_Servo_Angle(Q3_Servo_Angle);
            Stop_Flag = 1;
        }
        else
        {
            Q3_Servo_Control_New();
        }

        // ========== 显示计时 ==========
        sec = timer / 100;
        if (sec > 60) sec = 60;
        cs = timer;
        cs10  = (cs % 100) / 10;
        cs1   = (cs % 100) % 10;
        s10 = (sec / 10) % 10;
        s1 = sec % 10;
        TM1637_display(s10, s1, cs10, cs1, 1);
        }
        break;
		default:
			Question2_Stop_Flag = 0;
			break;
	}
}