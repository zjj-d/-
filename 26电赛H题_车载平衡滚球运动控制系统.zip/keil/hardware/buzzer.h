//#ifndef __BUZZER_H__
//#define __BUZZER_H__

//#include "ti_msp_dl_config.h"

////打开蜂鸣器，PA21
//void Buzzer_Open(void);

////关闭蜂鸣器，PA21
//void Buzzer_Close(void);

////打开电磁铁，PA0
//void ChiTie_Open(void);
////关闭电磁铁，PA0
//void ChiTie_Close(void); 
//#endif
