#include "bno08x_uart_rvc.h"
#include "pid.h"
#include "motor.h"
#include "encoder.h"
#include "uart.h"
#include "gw_grayscale_sensor.h"
#include "stdio.h"
#include "SR04.h"
#include "UART_host.h"
#include "Fuzzy_pid.h"
#include "cradle_head.h"
#include "stdlib.h"
#include "No_Mcu_Ganv_Grayscale_Sensor_Config.h"
#include <math.h>
volatile int32_t Steer_dx = 0;
volatile int32_t Steer_dy = 0;
volatile uint8_t Steer_Go = 0;   // 1 表示主循环需要执行一次移动

/* ========= 简单一维卡尔曼滤波器 (位置+速度模型) ========= */
typedef struct {
    float x;          // 位置状态
    float v;          // 速度状态
    float P[2][2];    // 协方差矩阵
    float Q[2];       // 过程噪声 {位置噪声, 速度噪声}
    float R;          // 测量噪声
} Kalman1D;

static void Kalman1D_Init(Kalman1D *kf, float init_pos, float Q_pos, float Q_vel, float R_meas) {
    kf->x = init_pos;
    kf->v = 0.0f;
    kf->P[0][0] = 1.0f; kf->P[0][1] = 0.0f;
    kf->P[1][0] = 0.0f; kf->P[1][1] = 1.0f;
    kf->Q[0] = Q_pos;
    kf->Q[1] = Q_vel;
    kf->R = R_meas;
}

static float Kalman1D_Update(Kalman1D *kf, float measurement) {
    // 预测 (dt = 1，即每次调用间隔视为1个时间单位)
    float x_pred = kf->x + kf->v;
    float v_pred = kf->v;
    float P00_pred = kf->P[0][0] + kf->P[0][1] + kf->P[1][0] + kf->P[1][1] + kf->Q[0];
    float P01_pred = kf->P[0][1] + kf->P[1][1];
    float P10_pred = kf->P[1][0] + kf->P[1][1];
    float P11_pred = kf->P[1][1] + kf->Q[1];

    // 更新
    float y = measurement - x_pred;
    float S = P00_pred + kf->R;
    float K0 = P00_pred / S;
    float K1 = P10_pred / S;

    kf->x = x_pred + K0 * y;
    kf->v = v_pred + K1 * y;

    kf->P[0][0] = (1.0f - K0) * P00_pred;
    kf->P[0][1] = (1.0f - K0) * P01_pred;
    kf->P[1][0] = P10_pred - K1 * P00_pred;
    kf->P[1][1] = P11_pred - K1 * P01_pred;

    return kf->x;
}
/* ======================================================== */


// 初始化PID控制器
void PID_Init(PID_Structure* pid, float Kp, float Ki, float Kd, float Output_Limit, float Target_Value) 
{
    pid->Kp = Kp;
    pid->Ki = Ki;
    pid->Kd = Kd;
    pid->Output_Limit = Output_Limit;
    pid->Prev_Error = 0.0f;
    pid->Integral = 0.0f;
	pid->Target_Value = Target_Value;
}
FuzzyPIDController FZ_Grey_BlackLine_Pid;
PID_Structure Speed_Left_Pid;//左轮PID初始化,0.5-·1m/s的PID
PID_Structure Speed_Right_Pid;//右轮PID初始化,0.5-1m/s的PID;


PID_Structure Grey_BlackLine_Pid;//灰度循迹PID
PID_Structure NO_Speed_Turn_Pid_Out;//无速度转向外环
PID_Structure NO_Speed_Turn_Pid_In;//无速度转向内环
PID_Structure Target_Tracking_X;
PID_Structure Target_Tracking_Y;


PID_Structure PID_Structure_Steer_X;//步进电机增量式PID结构体
PID_Structure PID_Structure_Steer_Y;//步进电机增量式PID结构体
// PID_Structure_Incremental PID_Structure_Steer_X;//步进电机增量式PID结构体
// PID_Structure_Incremental PID_Structure_Steer_Y;//步进电机增量式PID结构体

/*步进电机跟踪陀螺仪结构体*/
PID_Structure PID_Structure_Steer_BNO08X_X;//步进电机跟踪陀螺仪PID结构体
PID_Structure PID_Structure_Steer_BNO08X_Y;//步进电机
void Total_PID_Init(void) 
{
	/**无速度转向环**/
	PID_Init(&NO_Speed_Turn_Pid_Out,  5, 0, 0, 160, 0);
	PID_Init(&NO_Speed_Turn_Pid_In,  -16, -0.5, 6, 4000, 0);
	/**无速度转向环**/

	/**速度环**/
//	PID_Init(&Speed_Left_Pid, 15, 0.35, 0, 4000, 0);//左轮PID初始化,1m/s以内的PID**
//	PID_Init(&Speed_Right_Pid,  15, 0.35, 0, 4000, 0);//右轮PID初始化,1m/s以内的PID**
		PID_Init(&Speed_Left_Pid, 16, 0.3, 0, 4000, 0);//左轮PID初始化,0.7m/s以内的PID**
		PID_Init(&Speed_Right_Pid,  16, 0.3, 0, 4000, 0);//右轮PID初始化,0.7m/s以内的PID**
	/**速度环**/
	 
	/**灰度循迹PID */
//	PID_Init(&Grey_BlackLine_Pid,  0.8, -0, -0.55, 70, 0);//灰度循迹PID，0.3m/s
	PID_Init(&Grey_BlackLine_Pid,  0.95, -0, -0.35, 100, 0);//灰度循迹PID，0.4m/s 0.45
	/**灰度循迹PID */

	/**步进电机PID */

	// PID_Init(&PID_Structure_Steer_X, -0.061, -0.038, 0.051, 200, 0);//左轮PID初始化,1m/s以内的PID**
	// PID_Init(&PID_Structure_Steer_Y,  -0.061, -0.034, 0, 200, 0);//右轮PID初始化,1m/s以内的PID**
//	PID_Init(&PID_Structure_Steer_X, -0.088, -0.00, 0.009, 200, 0);//左轮PID初始化,1m/s以内的PID**0.1752
//	PID_Init(&PID_Structure_Steer_Y,  -0.08, -0.00, 0.008, 200, 0);//右轮PID初始化,1m/s以内的PID**0.08573
	
//		PID_Init(&PID_Structure_Steer_X, -0.1, 0.00, 0.0109, 200, 0);//云台X轴PID初始化，降低增益减少过冲
//	PID_Init(&PID_Structure_Steer_Y,  -0.15, 0.00, 0.0109, 200, 0);//云台Y轴PID初始化，降低增益减少过冲
	// PID_Incremental_Init(&PID_Structure_Steer_X, 0, 0, 0, 20, 0);
//	 PID_Incremental_Init(&PID_Structure_Steer_Y, 0, 0, 0, 20, 0);
PID_Init(&PID_Structure_Steer_X, -0.142, 0.00, -0.021, 200, 0);//云台X轴PID初始化，降低增益减少过冲
	PID_Init(&PID_Structure_Steer_Y,  -0.19, 0.0, -0.022, 200, 0);//云台Y轴PID初始化，降低增益减少过冲
//	PID_Init(&PID_Structure_Steer_X, -0.0142, 0.00, -0.021, 200, 0);//云台X轴PID初始化，降低增益减少过冲
//	PID_Init(&PID_Structure_Steer_Y,  -0.019, 0.0, -0.022, 200, 0);//云台Y轴PID初始化，降低增益减少过冲
	

}




// 单级PID计算函数（角度输入）
float PID_Calculate(PID_Structure* pid, float Current_Value) 
{
	// 1. 计算当前误差
	float Error = pid->Target_Value - Current_Value;

	// 2. 积分项计算（带抗饱和）
	pid->Integral += Error;
	// 积分限幅防止饱和
	if (pid->Integral > pid->Output_Limit) pid->Integral = pid->Output_Limit;
	else if (pid->Integral < -pid->Output_Limit) pid->Integral = -pid->Output_Limit;

	// 3. 微分项计算（使用两次误差差）
	float derivative = Error - pid->Prev_Error; // KD采用两次误差差

	// 4. 计算PID输出
	float Output = (pid->Kp * Error)           // 比例项
				+ (pid->Ki * pid->Integral)    // 积分项
				+ (pid->Kd * derivative);      // 微分项（重点）

	// 5. 输出限幅
	if (Output > pid->Output_Limit) Output = pid->Output_Limit;
	else if (Output < -pid->Output_Limit) Output = -pid->Output_Limit;

	// 6. 更新误差记录
	pid->Prev_Error = Error;

	return Output;
}
// 单级PID计算函数,微分项采用陀螺仪角速度
float PID_Calculate_2(PID_Structure* pid, float Current_Value, int16_t Angle_Speed) 
{
	// 1. 计算当前误差
	float Error = pid->Target_Value - Current_Value;

	// 2. 积分项计算（带抗饱和）
	pid->Integral += Error;
	// 积分限幅防止饱和
	if (pid->Integral > pid->Output_Limit) pid->Integral = pid->Output_Limit;
	else if (pid->Integral < -pid->Output_Limit) pid->Integral = -pid->Output_Limit;



	// 4. 计算PID输出
	float Output = (pid->Kp * Error)           // 比例项
				+ (pid->Ki * pid->Integral)    // 积分项
				+ (pid->Kd * Angle_Speed);      // 微分项（重点）

	// 5. 输出限幅
	if (Output > pid->Output_Limit) Output = pid->Output_Limit;
	else if (Output < -pid->Output_Limit) Output = -pid->Output_Limit;

	return Output;
}

// 角度环专用PID函数
float PID_Calculate_No_Speed(PID_Structure* pid, float Current_Value, int16_t Angle_Speed) 
{
	// 1. 计算当前误差
	float Error = pid->Target_Value - Current_Value;
    if (Error > 180) 
	Error -= 360;   // 误差>180°时顺时针修正
    else if(Error < -180) 
	Error += 360; // 误差<-180°时逆时针修正

	// 2. 积分项计算（带抗饱和）
	pid->Integral += Error;
	// 积分限幅防止饱和
	if (pid->Integral > pid->Output_Limit) pid->Integral = pid->Output_Limit;
	else if (pid->Integral < -pid->Output_Limit) pid->Integral = -pid->Output_Limit;



	// 4. 计算PID输出
	float Output = (pid->Kp * Error)           // 比例项
				+ (pid->Ki * pid->Integral)    // 积分项
				+ (pid->Kd * Angle_Speed);      // 微分项（重点）

	// 5. 输出限幅
	if (Output > pid->Output_Limit) Output = pid->Output_Limit;
	else if (Output < -pid->Output_Limit) Output = -pid->Output_Limit;

	return Output;
}

// 初始化增量式PID参数
void PID_Incremental_Init(PID_Structure_Incremental* pid, 
                          float Kp, float Ki, float Kd, 
                          float DeltaOutput_Limit, float Target_Value) 
{
    pid->Kp = Kp;
    pid->Ki = Ki;
    pid->Kd = Kd;
    pid->DeltaOutput_Limit = DeltaOutput_Limit;
    pid->Target_Value = Target_Value;
    pid->Prev_Error = 0.0f;
    pid->Prev_Error2 = 0.0f;
}

// 增量式PID计算函数（返回控制增量）
float PID_Incremental_Calculate(PID_Structure_Incremental* pid, float Current_Value) 
{
    // 1. 计算当前误差
    float Error = pid->Target_Value - Current_Value;

    // 2. 计算增量式PID三项
    float P = pid->Kp * (Error - pid->Prev_Error);           // 比例项：当前与上次误差差
    float I = pid->Ki * Error;                              // 积分项：当前误差
    float D = pid->Kd * (Error - 2*pid->Prev_Error + pid->Prev_Error2); // 微分项：误差变化率

    // 3. 计算控制增量
    float DeltaOutput = P + I + D;

    // 4. 增量限幅（防止突变）
    if (DeltaOutput > pid->DeltaOutput_Limit) 
        DeltaOutput = pid->DeltaOutput_Limit;
    else if (DeltaOutput < -pid->DeltaOutput_Limit) 
        DeltaOutput = -pid->DeltaOutput_Limit;

    // 5. 更新误差记录
    pid->Prev_Error2 = pid->Prev_Error;
    pid->Prev_Error = Error;

    return DeltaOutput;  // 返回控制增量
}

int16_t Left_Speed_PID_Out;
int16_t Right_Speed_PID_Out;
int16_t Angle_PID_Out=0;



/**状态机参数**/

/****************************无MCU灰度**************************************/
// 全局变量定义
extern unsigned short Anolog[8];
extern unsigned short black[8];
extern unsigned short white[8];
extern unsigned short Normal[8];
extern No_MCU_Sensor sensor;              // 传感器数据结构体
extern unsigned char Digtal;							 // 数字量

/**状态机参数**/
int16_t Grey_Current_Line_Data=0;
//int16_t Weight_Grey[5]={-40, -25, -0, 18, 40};//0.3-0.5m/s权重
// int16_t Weight_Grey[8]={-99, -73, -10, -0.2, 0.2, 10, 73, 99};//0.7m/s权重
int16_t Weight_Grey[8]={-65, -38, -18, -3, 3, 18, 38, 65};//0.8m/s权重
volatile uint8_t Road_Flag=1;//判断一次路口左转,0:左转中，1：直行中,2:直行起步阶段，不判断转弯
volatile uint8_t Road_Flag_Last=1;//判断一次路口左转,0:左转中，1：直行中
volatile uint8_t Stop_Flag=0;//停止标志位，1：停止
volatile int16_t Grey_Speed=30;//灰度循迹速度
volatile uint8_t clear_flag=0;
volatile uint8_t clear_cnt=0;	
volatile uint8_t Grey[8];//OLED显示用
void Calculate_Grey_Data(void)
{
	 static int16_t last_grey_data = 0;      // 上一次的偏差值（用于丢线保持）
    Grey_Data = 0;
    volatile uint8_t Weight_Tem[8] = {0};
		No_Mcu_Ganv_Sensor_Task_Without_tick(&sensor);
//			//获取传感器数字量结果(只有当有黑白值传入进去了之后才会有这个值！！)
		Digtal=Get_Digtal_For_User(&sensor);
		Weight_Tem[0] = !((Digtal>>0)&0x01);
		Weight_Tem[1] = !((Digtal>>1)&0x01);
		Weight_Tem[2] = !((Digtal>>2)&0x01);
		Weight_Tem[3] = !((Digtal>>3)&0x01);
		Weight_Tem[4] = !((Digtal>>4)&0x01);
		Weight_Tem[5] = !((Digtal>>5)&0x01);
		Weight_Tem[6] = !((Digtal>>6)&0x01);
		Weight_Tem[7] = !((Digtal>>7)&0x01);
		
	if(Road_Flag > 1)
	{
		
		Road_Flag--;
		 if(Road_Flag <= 10)  
    {
				Grey_Speed = 0;
				Clear_KI_ALL();
			
        Grey_Current_Line_Data = -24;   
    }
		else if(Weight_Tem[2]  == 1 &&  Road_Flag <= 15)
		{
			Road_Flag = 1;
			Grey_Speed = 30;
      Grey_Current_Line_Data = 0; 
	
		}
		else if(Road_Flag <= 5)   // 强制退出
	{
    Road_Flag = 1;
    Grey_Speed = 30;
    Grey_Current_Line_Data = 0;
	}
	}

	if(Weight_Tem[0] == 1 && Road_Flag == 1)
	{
				Grey_Speed = 30;
				Road_Flag = 25;//路口准备转弯
				Grey_Current_Line_Data = 0; 
	}
		
	else if(Road_Flag == 1)   //正常巡线跑
	{
		Grey_Speed = 30;
		for (uint8_t i = 4; i < 8; i++)
		{
			if(Weight_Tem[i] == 1)
			{
				Grey_Current_Line_Data = Weight_Grey[i];
			}
		}
		for (int8_t i = 3; i >= 0; i--)
		{
			if(Weight_Tem[i] == 1)
			{
				Grey_Current_Line_Data = Weight_Grey[i];
			}
		}
	}
}

int32_t Grey_Black_Line_PID_Out=0;
int32_t Distance_PID_Out=0;
 /**灰度循迹串级PID **/
void Execute_PID_INTimer_Grey_Black(void)
{

	Calculate_Grey_Data();//处理灰度传感器数据
 	Grey_BlackLine_Pid.Target_Value = 0;//设置循迹PID目标值
//	Distance_Structure.Target_Value = 0;//设定距离值
//	  Grey_BlackLine_Pid.Kp = Uart_KP;
//	  Grey_BlackLine_Pid.Ki = Uart_KI;
//	 Grey_BlackLine_Pid.Kd = -Uart_KD;
	
	 
	Grey_Black_Line_PID_Out = (int32_t)PID_Calculate(&Grey_BlackLine_Pid, Grey_Current_Line_Data);//灰度循迹PID,外环
	
//	
//	sprintf(Str_Data, "%d, %d, %f\n",Grey_Current_Line_Data,Grey_Black_Line_PID_Out, Uart_Target);
//	 uart0_send_string(UART_0_TEST_INST , Str_Data);
	// Grey_Black_Line_PID_Out = (int32_t)FuzzyPID_Compute(&FZ_Grey_BlackLine_Pid, 0, (float)Grey_Current_Line_Data);
	// sprintf(Str_Data, "%f, %f, %f, %f\n", FZ_Grey_BlackLine_Pid.Kp, FZ_Grey_BlackLine_Pid.Ki, FZ_Grey_BlackLine_Pid.Kd, Uart_Target);
	// uart0_send_string(UART_0_TEST_INST , Str_Data);
	Speed_Left_Pid.Target_Value = Grey_Speed - Grey_Black_Line_PID_Out ;//读取串口发的速度，速度一般0.5m/s，1m/s
	Speed_Right_Pid.Target_Value = Grey_Speed + Grey_Black_Line_PID_Out ;//读取串口发的速度，速度一般0.5m/s，1m/s

 	Left_Speed_PID_Out = (int32_t)PID_Calculate(&Speed_Left_Pid, EncoderCnt_L);//计算左轮速度环PID
 	Right_Speed_PID_Out = (int32_t)PID_Calculate(&Speed_Right_Pid, EncoderCnt_R);//计算右轮速度环PI
	PWM_Output(MOTOR_LEFT, Left_Speed_PID_Out);//PWM作用到电机
	PWM_Output(MOTOR_RIGHT, Right_Speed_PID_Out);//PWM作用到电机
}

int16_t NO_Speed_Turn_TarhetAngle=0;

int16_t Get_Angle_Turn_90(void)
{
	if(bno08x_data.yaw > 90)
	{
		return (bno08x_data.yaw - 270);
	}
	else 
	{
		return bno08x_data.yaw + 90;
	}
	
}
 /**固定角度转动PID **/
int32_t NO_Speed_Turn_PID_Value_Out=0;//外环输出
int32_t NO_Speed_Turn_PID_Value_In=0;//内环输出
void NO_Speed_Turn_PID(void)
{
//	 NO_Speed_Turn_Pid_Out.Kp = Uart_KP;
//	 NO_Speed_Turn_Pid_Out.Ki = Uart_KI;
//	 NO_Speed_Turn_Pid_Out.Kd = -Uart_KD;

	NO_Speed_Turn_Pid_Out.Target_Value = NO_Speed_Turn_TarhetAngle;
	
	// NO_Speed_Turn_Pid_In.Kp = -Uart_KP;
	// NO_Speed_Turn_Pid_In.Ki = -Uart_KI;
	// NO_Speed_Turn_Pid_In.Kd = Uart_KD;
	
	

	NO_Speed_Turn_PID_Value_Out = (int32_t)PID_Calculate_No_Speed(&NO_Speed_Turn_Pid_Out, bno08x_data.yaw, bno08x_data.az);//灰度循迹PID,外环
	NO_Speed_Turn_Pid_In.Target_Value = NO_Speed_Turn_PID_Value_Out;
	NO_Speed_Turn_PID_Value_In = (int32_t)PID_Calculate(&NO_Speed_Turn_Pid_In, bno08x_data.az);//灰度循迹PID,内环

	PWM_Output(MOTOR_LEFT, NO_Speed_Turn_PID_Value_In);//PWM作用到电机
	PWM_Output(MOTOR_RIGHT, -NO_Speed_Turn_PID_Value_In);//PWM作用到电机
}


uint16_t PID_Tartget_X=0;
uint16_t PID_Tartget_Y=0;
// uint16_t PID_Tartget_X_3=265;//第三问目标
// uint16_t PID_Tartget_Y_3=115;
int32_t PID_Target_Tracking_X_Out=0;
int32_t PID_Target_Tracking_Y_Out=0;

/* 卡尔曼滤波器实例 */
static Kalman1D kf_x, kf_y;
static uint8_t kf_inited = 0;
/*静态时云台仍有微颤	增大 KF_R（如 3.0、5.0）或减小 KF_Q_VEL（如 0.05） */
/*移动目标时云台跟不上	增大 KF_Q_VEL（如 0.2、0.3）并减小 KF_R（如 1.0） */
/*响应太慢，滞后明显	减小 KF_R 同时增大 KF_Q_VEL；也可适当增大 Kp    */
/* 卡尔曼参数（可调） */
#define KF_Q_POS    0.001f   // 位置过程噪声，越小静态越平滑
#define KF_Q_VEL    0.5f     // 速度过程噪声，越大对运动目标响应越快
#define KF_R        0.5f     // 测量噪声，越大滤波越平滑但滞后

volatile int16_t x_site,y_site;
volatile int16_t x_mubiao, y_mubiao;
void PID_Calculate_Target_Tracking(void)
{
//	PID_Structure_Steer_Y.Kp = -Uart_KP;
                                                                                                                                
//	PID_Structure_Steer_Y.Ki = Uart_KI;
//	PID_Structure_Steer_Y.Kd = -Uart_KD;
//	PID_Structure_Steer_Y.Target_Value = Uart_Target;
//    // 目标像素坐标（根据你的摄像头视野中心调整）


    // 初始化卡尔曼滤波器（仅第一次调用）
//    if (!kf_inited) {
//        Kalman1D_Init(&kf_x, (float)x_site, KF_Q_POS, KF_Q_VEL, KF_R);
//        Kalman1D_Init(&kf_y, (float)y_site, KF_Q_POS, KF_Q_VEL, KF_R);
//        kf_inited = 1;
//    }

    // 用卡尔曼滤波器更新滤波值
//    float filtered_x = Kalman1D_Update(&kf_x, (float)x_site);
//    float filtered_y = Kalman1D_Update(&kf_y, (float)y_site);
    // 目标值（您可以根据题目不同动态调整）
    PID_Structure_Steer_X.Target_Value = x_mubiao;   // X 目标
    PID_Structure_Steer_Y.Target_Value = y_mubiao;  // Y 目标

    // 积分分离：误差过大时清积分
//    if (abs((int16_t)filtered_x) > 50) PID_Structure_Steer_X.Integral = 0;
//    if (abs((int16_t)filtered_y) > 50) PID_Structure_Steer_Y.Integral = 0;

    // PID 计算
    float out_x = PID_Calculate(&PID_Structure_Steer_X, x_site);
    float out_y = PID_Calculate(&PID_Structure_Steer_Y, y_site);
		
    // 转换为步数并施加死区
    Steer_dx = (int32_t)out_x;
    Steer_dy = -(int32_t)out_y;
//    if (abs(Steer_dx) < 1) Steer_dx = 0;
//    if (abs(Steer_dy) < 1) Steer_dy = 0;

    // 如果不需要动作则直接返回
    if (Steer_dx == 0 && Steer_dy == 0) return;

	sprintf(Str_Data, "%d, %d, %f,%f\n",x_site,y_site, out_x,out_y);
	 uart0_send_string(UART_0_TEST_INST , Str_Data);
    // 控制云台
    Cradle_Head_Control(Steer_dx, Steer_dy);
}


uint16_t Last_Data_X=0;
uint16_t Last_Data_Y=0;
uint8_t Q3_Stop_Flag=0;

uint8_t KI_Clear_Flag=0;
void Clear_KI_ALL(void)//清除所有的PID积分
{
	/**无速度转向环**/
	NO_Speed_Turn_Pid_Out.Integral = 0;
	NO_Speed_Turn_Pid_In.Integral = 0;
	/**无速度转向环**/

	/**速度环**/
	Speed_Left_Pid.Integral = 0;
	Speed_Right_Pid.Integral = 0;

	/**速度环**/
	
	/**灰度循迹PID */ 
	Grey_BlackLine_Pid.Integral = 0;

}
volatile uint8_t Question_3_Flag=1;//题目圈速
volatile uint8_t Question_Circle_Num=1;//题目圈速
volatile uint8_t Steer_Init_Flag=1;//题目电机初始化标志
volatile uint8_t Question1_Stage=0;//0:循迹，1转弯
volatile uint16_t Question_Cnt=0;//计时
volatile uint16_t Question2_Stop_Flag=0;//计时
volatile uint8_t Question4_Start_Flag=0;//发挥1的小车启动标志
//volatile float yaw_last=0;//发挥12的上次偏航角
//volatile float yaw_now=0;//发挥12的此时偏航角
//volatile float yaw_dif=0;
// volatile float bno08x_data.yaw_Trans=0;//偏航角转为360

// 陀螺仪云台补偿 专用变量
static float last_yaw = 0.0f;    // 上一帧陀螺仪偏航角
static float delta_yaw = 0.0f;   // 车身旋转角度增量（核心！）


// 功能：计算车身旋转角度增量，处理-180°~180°跳变，无误差
void Calculate_Gyro_Delta(void)
{
    float current_yaw = bno08x_data.yaw;
    // 计算角度差（自动处理±180°跳变，比如179→-179，差值为-2°而非-358°）
    delta_yaw = current_yaw - last_yaw;
    if (delta_yaw > 180.0f)  delta_yaw -= 360.0f;
    if (delta_yaw < -180.0f) delta_yaw += 360.0f;
    // 更新上一帧角度
    last_yaw = current_yaw;
}

// 功能：获取陀螺仪补偿的云台X轴步数（反向抵消车身旋转）
int32_t Get_Gyro_Compensate_Steps(void)
{
    Calculate_Gyro_Delta();
    // 反向补偿：车身左转→云台右转，车身右转→云台左转
    return (int32_t)(-delta_yaw * 10.6);
}
#define LOST_THRESHOLD  3   // 连续相同帧数判定丢失
static int16_t last_x_site = 0, last_y_site = 0;
static uint8_t lost_counter = 0;

uint8_t is_visual_lost(void) {
    if (x_site == last_x_site && y_site == last_y_site && x_site != x_mubiao && y_site != y_mubiao) {
        lost_counter++;
        if (lost_counter >= LOST_THRESHOLD)
            return 1;
    } else {
        lost_counter = 0;
    }
    last_x_site = x_site;
    last_y_site = y_site;
    return 0;
}

void PID_Calculate_Target_Tracking_2(void)
{
//	PID_Structure_Steer_Y.Kp = -Uart_KP;
//	PID_Structure_Steer_Y.Ki = -Uart_KI;
//	PID_Structure_Steer_Y.Kd = Uart_KD;
//	PID_Structure_Steer_Y.Target_Value = -Uart_Target;
//    // 目标像素坐标（根据你的摄像头视野中心调整）
    if (is_visual_lost()) {
    // 丢失：只依赖陀螺仪补偿，冻结 PID 积分
    int32_t ff_x = Get_Gyro_Compensate_Steps();
			PID_Structure_Steer_Y.Integral = 0;   // 新增：清Y积分
    Cradle_Head_Control(-ff_x, 0); 
    return;
}

    // 初始化卡尔曼滤波器（仅第一次调用）
    if (!kf_inited) {		
        Kalman1D_Init(&kf_x, (float)x_site, KF_Q_POS, KF_Q_VEL, KF_R);
        Kalman1D_Init(&kf_y, (float)y_site, KF_Q_POS, KF_Q_VEL, KF_R);
        kf_inited = 1;
    }

    // 用卡尔曼滤波器更新滤波值
    float filtered_x = Kalman1D_Update(&kf_x, (float)x_site);
    float filtered_y = Kalman1D_Update(&kf_y, (float)y_site);
		int32_t x_out = Get_Gyro_Compensate_Steps();
    // 目标值（您可以根据题目不同动态调整）
    PID_Structure_Steer_X.Target_Value = x_mubiao;   // X 目标
    PID_Structure_Steer_Y.Target_Value = y_mubiao;  // Y 目标

    // 积分分离：误差过大时清积分
    if (abs((int16_t)filtered_x) > 50) PID_Structure_Steer_X.Integral = 0;
    if (abs((int16_t)filtered_y) > 50) PID_Structure_Steer_Y.Integral = 0;

    // PID 计算
    float out_x = PID_Calculate(&PID_Structure_Steer_X, filtered_x) - x_out;

    float out_y = PID_Calculate(&PID_Structure_Steer_Y, filtered_y);
		
    // 转换为步数并施加死区
    Steer_dx = (int32_t)out_x;
    Steer_dy = -(int32_t)out_y;
    if (abs(Steer_dx) < 1) Steer_dx = 0;
    if (abs(Steer_dy) < 1) Steer_dy = 0;

    // 如果不需要动作则直接返回
    if (Steer_dx == 0 && Steer_dy == 0) return;
		
//	sprintf(Str_Data, "%d, %d, %f,%f\n",x_site,y_site, filtered_x,filtered_y);
//	 uart0_send_string(UART_0_TEST_INST , Str_Data);
    // 控制云台
    Cradle_Head_Control(Steer_dx, Steer_dy);
}

volatile uint8_t shaomiao_flag = 1;  // 视觉扫描标志位1为不用视觉，0为视觉扫描


volatile float avg_dist;

void Car_PID_Calculate(void)
{
	switch(Question_Flag)
	{
		case 1://题目1
			switch(Question_Circle_Num)
			{
				case 1:
					if((Distance_Left + Distance_Right) / 2 >= 365)
					{
						Stop_Flag = 1;
					}
					break;
				case 2:
					if((Distance_Left + Distance_Right) / 2 >= 360*Question_Circle_Num)
					{
						Stop_Flag = 1;
					}
					break;
				case 3:
					if((Distance_Left + Distance_Right) / 2 >= 360*Question_Circle_Num)
					{
						Stop_Flag = 1;
					}
					break;
				case 4:
					if((Distance_Left + Distance_Right) / 2 >= 360*Question_Circle_Num)
					{
						Stop_Flag = 1;
					}
					break;
				case 5:
					if((Distance_Left + Distance_Right) / 2 >= 360 *Question_Circle_Num)
					{
						Stop_Flag = 1;
					}
					break;
			}
		  
			if(Stop_Flag == 0)//未停止时
			{  
				Execute_PID_INTimer_Grey_Black();
			}
			else 
			{ 
				Motor_Stop();//关闭电机
			}
			break;
		case 2:     //题目2
		Question_Cnt++;
    if(shaomiao_flag == 1)
    {
        static uint8_t y_move_started = 0;   // 防止重复启动移动

        if (!y_move_started) {
            // 只启动一次Y轴移动1550步
            Cradle_Head_Control(0, 1550);
            y_move_started = 1;
        }

        // 等待Y轴移动完成
        if (Cradle_Y_Is_Done()) {
					x_site = y_site =0; 
            shaomiao_flag = 0;               // 移动完成，切换到视觉追踪
            y_move_started = 0;              // 复位启动标志（若需要再次移动可重新使用）
            x_mubiao = 5;                  // 设定追踪目标（也可放在前面，这里再次确保）
            y_mubiao = -10;
        }
    }
    else
    {
      // 视觉追踪
        PID_Calculate_Target_Tracking();     
//		sprintf(Str_Data, "%d, %d, %f,%f\n",x_site,y_site);
//		uart0_send_string(UART_0_TEST_INST , Str_Data);
        // 判断是否击中目标：位置误差小于3像素时打开激光
        if (abs(x_site - x_mubiao) < 3 && abs(y_site - y_mubiao) < 3 || Question_Cnt >=150)
					{
            Laser_Open();
					} 
					else
				{
            Laser_Close();
        }
    }
    break;
	 case 3:   
        {
            Question_Cnt++;
            static uint8_t  last_circle        = 0;
            static uint8_t  y_move_done        = 0;
            static uint8_t  vision_confirm_cnt = 0;   // 视觉连续确认帧数
            static int8_t   scan_dir           = 1;   // 扫描方向：1=正向，-1=反向
            static uint8_t  scan_hold          = 0;   // 扫描间隔计数
            static uint8_t  limit_stuck_cnt    = 0;   // 限位卡死检测

            // 圈数切换，重置所有状态
            if (Question_Circle_Num != last_circle) {
                last_circle        = Question_Circle_Num;
                shaomiao_flag      = 1;
                y_move_done        = 0;
                vision_confirm_cnt = 0;
                scan_dir           = (Question_Circle_Num == 1) ? 1 : -1; // 圈1向右，圈2向左
                scan_hold          = 0;
                limit_stuck_cnt    = 0;
                Laser_Close();
            }

            if (shaomiao_flag == 1) {
                // 第一步：Y轴下降
                if (!y_move_done) {
                    Cradle_Head_Control(0, 1500);
                    y_move_done = 1;
                    x_site = y_site = 0;
                }

                if (Cradle_Y_Is_Done()) {
                    // ---- 视觉防抖确认（避免噪声触发） ----
                    if (x_site > -300 && x_site < 300 && y_site > -300 && y_site < 300 &&
                        x_site != 0 && y_site != 0) {
                        vision_confirm_cnt++;
                        if (vision_confirm_cnt >= 1) {   // 连续5帧有效才确认目标
                            shaomiao_flag = 0;            // 退出扫描，进入跟踪
                            x_mubiao = 5;
                            y_mubiao = -10;
                            // 退出前停止电机，避免残余运动干扰
                            Cradle_Stop_X();
                        }
                    } else {
                        vision_confirm_cnt = 0;
                    }

                    // ---- 自动往复扫描（核心修改） ----
                    // 只有 X 轴完全空闲时才发送新指令
                    if (motorX.steps_to_go == 0 && motorX.running == 0) {
                        scan_hold++;
                        if (scan_hold >= 10) {   // 每10个循环周期（约100ms）发送一次扫描步
                            scan_hold = 0;

                            // 检测是否卡在限位（连续两次发指令步数被清零）
                            int32_t before_pos = Credle_X_P;
                            Cradle_Head_Control(scan_dir * 600, 0);   // 发送扫描步
                            // 如果坐标没有变化，说明触碰到软限位，立即反向
                            if (Credle_X_P == before_pos) {
                                limit_stuck_cnt++;
                                if (limit_stuck_cnt >= 2) {   // 连续两次无法移动，反转方向
                                    scan_dir = -scan_dir;
                                    limit_stuck_cnt = 0;
                                    // 再发一次反向指令，确保脱离限位
                                    Cradle_Head_Control(scan_dir * 600, 0);
                                }
                            } else {
                                limit_stuck_cnt = 0;          // 移动成功则清零
                            }
                        }
                    }
                }
            } else {
                // 视觉跟踪模式（原逻辑保留）
                PID_Calculate_Target_Tracking();
                if (Cradle_All_Done()) {
                    if (abs(x_site - x_mubiao) < 3 && abs(y_site - y_mubiao) < 3 || Question_Cnt >= 300)
                        Laser_Open();
                    else
                        Laser_Close();
                } else {
                    Laser_Close();
                }
            }
        }
        break;

		case 5 :
			x_mubiao = 5;
		y_mubiao = -10;
			PID_Calculate_Target_Tracking();
			break;
		case 4:
			PID_Init(&PID_Structure_Steer_X, -0.192, 0.00, -0.021, 200, 0);//云台X轴PID初始化，降低增益减少过冲
			switch(Question_Circle_Num)
			{
				case 1:
					if((Distance_Left + Distance_Right) / 2 >= 360)
					{
						Stop_Flag = 1;
					}
					break;
				case 2:
					if((Distance_Left + Distance_Right) / 2 >= 360*Question_Circle_Num)
					{
						Stop_Flag = 1;
					}
					break;
			}
		  
			if(Stop_Flag == 0)//未停止时
			{  
				x_mubiao = 5;
				y_mubiao = -5;
			PID_Calculate_Target_Tracking_2();
				Execute_PID_INTimer_Grey_Black();
			}
			else 
			{ 
				Motor_Stop();//关闭电机
			}
			break;
				case 6:   // 正方形循迹 + 动态画圆（基于距离修改视觉目标点）
    if (avg_dist < 370.0f)   // 一圈总距离
    {
			   avg_dist = (Distance_Left + Distance_Right) / 2.0f;
        Execute_PID_INTimer_Grey_Black();   // 继续循迹

        // 距离 → 角度（进度0~1映射到0~2π）
        float ratio = avg_dist / 370.0f;
        if (ratio > 1.0f) ratio = 1.0f;
        float angle = ratio * 2.0f * 3.1415926f;

        // 设定动态目标点：圆心 (5, -10)，半径25像素（可根据靶面大小调整）
        #define CIRCLE_R_PIXEL  25.0f
        x_mubiao = 5  + (int16_t)(CIRCLE_R_PIXEL * cosf(angle));
        y_mubiao = -10 + (int16_t)(CIRCLE_R_PIXEL * sinf(angle));

        // 调用视觉追踪函数控制云台
        PID_Calculate_Target_Tracking();
    }
    else
    {
        Motor_Stop();   // 停车
        // 确保最后目标点到位
        PID_Calculate_Target_Tracking();
    }
    break;
		default:
			break;
	}
}