#include "key.h"
#include "pid.h"
#include "No_Mcu_Ganv_Grayscale_Sensor_Config.h"
#include "OLED.h"
#include "ti_msp_dl_config.h"
#include "DataScope_DP.h"
static uint16_t key_press_counter[3] = {0};   // 记录每个按键按下的持续时间（10ms单位）
#define LONG_PRESS_THRESHOLD  100              // 1秒 = 100 * 10ms

KEY_t Key_Number[3];
volatile uint8_t Gimbal_Home_Flag = 0;

extern No_MCU_Sensor sensor; 
 volatile uint8_t Calibration_Mode;
extern unsigned short white[8];
extern unsigned short black[8];
extern const unsigned short default_white[8]; // 如果需要恢复默认
extern const unsigned short default_black[8];

void Key_Init(void)
{
	for(uint8_t i=0; i<3; i++)
	{
		Key_Number[i].State = KEY_IDLE_STATE;
	}
}

void Key_Check_State(void)
{
	for(uint8_t i=0; i<3; i++)
	{

			switch(i)
			{
				case 0:
					if( DL_GPIO_readPins(K0_PORT, K0_PIN) > 0 )
					{
						if(Key_Number[i].State == KEY_IDLE_STATE)
						{
							Key_Number[i].State = KEY_DITHERING_STATE;
						}
						else if(Key_Number[i].State == KEY_DITHERING_STATE)
						{
							Key_Number[i].State = KEY_PRESSED_STATE;
						}
						else if(Key_Number[i].State == KEY_PRESSED_STATE)
						{
							Key_Number[i].State = KEY_STABLE_STATE;
						}
					}
					else
					{
						Key_Number[i].State = KEY_IDLE_STATE;
					}
					break;
				case 1:
					if( DL_GPIO_readPins(K1_PORT, K1_PIN) == 0 )
					{
						if(Key_Number[i].State == KEY_IDLE_STATE)
						{
							Key_Number[i].State = KEY_DITHERING_STATE;
						}
						else if(Key_Number[i].State == KEY_DITHERING_STATE)
						{
							Key_Number[i].State = KEY_PRESSED_STATE;
						}
						else if(Key_Number[i].State == KEY_PRESSED_STATE)
						{
							Key_Number[i].State = KEY_STABLE_STATE;
						}
					}
					else
					{
						Key_Number[i].State = KEY_IDLE_STATE;
					}
					break;
				case 2:
					if( DL_GPIO_readPins(K2_PORT, K2_PIN) == 0 )
					{
						if(Key_Number[i].State == KEY_IDLE_STATE)
						{
							Key_Number[i].State = KEY_DITHERING_STATE;
						}
						else if(Key_Number[i].State == KEY_DITHERING_STATE)
						{
							Key_Number[i].State = KEY_PRESSED_STATE;
						}
						else if(Key_Number[i].State == KEY_PRESSED_STATE)
						{
							Key_Number[i].State = KEY_STABLE_STATE;
						}
					}
					else
					{
						Key_Number[i].State = KEY_IDLE_STATE;
					}
					break;

				
				
		}
	}
}

uint8_t Key_Get_State(uint8_t Key_x)
{
	return Key_Number[Key_x].State;
}


void Key_Handle(void)
{
    static uint8_t last_state[3] = {KEY_IDLE_STATE, KEY_IDLE_STATE, KEY_IDLE_STATE};
    Key_Check_State();

    for(uint8_t i=0; i<3; i++)
    {
        uint8_t current_state = Key_Get_State(i);
        
        // 检测按键是否处于按下状态（稳定或抖动过渡都可算作按下）
        if(current_state == KEY_PRESSED_STATE || current_state == KEY_STABLE_STATE)
        {
            key_press_counter[i]++;
        }
        else
        {
            key_press_counter[i] = 0;
        }

        // ---------- 长按事件处理 ----------
        if(key_press_counter[i] == LONG_PRESS_THRESHOLD)
        {
            switch(i)
            {
                case 2:  // K2 长按：切换校准模式
                    Calibration_Mode = !Calibration_Mode;
                    if(Calibration_Mode)
                    {
                        OLED_ShowString(0, 60, "Calib Mode ON ", OLED_6X8);
                    }
                    else
                    {
                        OLED_ShowString(0, 60, "Normal Mode    ", OLED_6X8);
                    }
                    OLED_Update();
                    break;
                // 其他按键长按在此模式下不做特殊处理，防止误触
            }
            key_press_counter[i] = 0; // 重置，防止重复触发
        }

        // ---------- 短按事件处理（仅在按下瞬间触发一次） ----------
        if(current_state == KEY_PRESSED_STATE && last_state[i] != KEY_PRESSED_STATE)
        {
            if(Calibration_Mode)  // 校准模式下的短按
            {
                switch(i)
                {
                    case 0:  // K0 短按 -> 校准白色
                        // 注意：sensor.Anolog_value 必须是最新的，主循环不断更新
                        Get_Anolog_Value(&sensor, white);
                        No_MCU_Ganv_Sensor_Init(&sensor, white, black);
                        OLED_ShowString(0, 50, "White Calib OK ", OLED_6X8);
                        OLED_Update();
                        break;
                    case 1:  // K1 短按 -> 校准黑色
                        Get_Anolog_Value(&sensor, black);
                        No_MCU_Ganv_Sensor_Init(&sensor, white, black);
                        OLED_ShowString(0, 50, "Black Calib OK ", OLED_6X8);
                        OLED_Update();
                        break;
                    case 2:  // K2 短按：可预留为恢复默认阈值（可选）
                        // 若需要恢复出厂，可添加：
                        // memcpy(white, default_white, sizeof(white));
                        // memcpy(black, default_black, sizeof(black));
                        // No_MCU_Ganv_Sensor_Init(&sensor, white, black);
                        // OLED_ShowString(0, 60, "Default Restore", OLED_6X8);
                        // OLED_Update();
                        break;
                }
            }
            else  // 正常模式下的短按（保持原有功能）
            {
                switch(i)
                {
                    case 0:
                        if(Question_Flag == 0) Question_3_Flag++;
                        else if(Question_Flag == 1 || Question_Flag == 3 || Question_Flag == 4)
                            Question_Circle_Num++;
                        break;
                    case 1:
                        Start_Flag = 1;
                        Clear_KI_ALL();
                        break;
                    case 2:
                        Question_Flag++;
                        break;
                }
            }
        }
        last_state[i] = current_state;
    }
}
