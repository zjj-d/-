#ifndef __KEY_H__
#define __KEY_H__
#include "ti_msp_dl_config.h"             
#include "encoder.h"
#include "pid.h"
#define K0_PORT KEY_PORT
#define K0_PIN  KEY_PIN_18_PIN

#define K1_PORT KEY_PORT
#define K1_PIN  KEY_PIN_Change_PIN

#define K2_PORT KEY_PORT
#define K2_PIN  KEY_PIN_Change_2_PIN


typedef enum
{
	KEY_IDLE_STATE, //
	KEY_DITHERING_STATE,//
	KEY_PRESSED_STATE,//
	KEY_STABLE_STATE,//
	KEY_LONG_PRESSED_STATE,//
}KEY_STATE;

typedef struct
{
	KEY_STATE State;//
}KEY_t;


void Key_Init(void);
void Key_Check_State(void);
uint8_t Key_Get_State(uint8_t Key_x);
void Key_Handle(void);

extern volatile uint8_t Gimbal_Home_Flag;
extern volatile uint8_t Gimbal_Home_Done;
#endif