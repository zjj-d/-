#ifndef _UART_CALLBACK_H_
#define _UART_CALLBACK_H_
#include "delay.h"
/* ---- base types (must precede module includes that use u8/u16) ---- */
#define ABS(a)      (a>0 ? a:(-a))
typedef int32_t  s32;
typedef int16_t s16;
typedef int8_t  s8;

typedef const int32_t sc32;  /*!< Read Only */
typedef const int16_t sc16;  /*!< Read Only */
typedef const int8_t sc8;   /*!< Read Only */

typedef __IO int32_t  vs32;
typedef __IO int16_t  vs16;
typedef __IO int8_t   vs8;

typedef __I int32_t vsc32;  /*!< Read Only */
typedef __I int16_t vsc16;  /*!< Read Only */
typedef __I int8_t vsc8;   /*!< Read Only */

typedef uint32_t  u32;
typedef uint16_t u16;
typedef uint8_t  u8;

typedef const uint32_t uc32;  /*!< Read Only */
typedef const uint16_t uc16;  /*!< Read Only */
typedef const uint8_t uc8;   /*!< Read Only */

typedef __IO uint32_t  vu32;
typedef __IO uint16_t vu16;
typedef __IO uint8_t  vu8;

typedef __I uint32_t vuc32;  /*!< Read Only */
typedef __I uint16_t vuc16;  /*!< Read Only */
typedef __I uint8_t vuc8;   /*!< Read Only */

/* ---- module headers ---- */

extern int Motor1_Speed, Motor2_Speed;
extern int motor1_Current_Speed, motor2_Current_Speed;
extern int Motor1_T_Position, Motor2_T_Position;
extern int Motor1_Current_Position, Motor2_Current_Position;

void usart3_send(u8 data);
void USART3_SEND(u8 *data, u8 len);
void uart3_send_data(uint8_t data);
void uart3_send_SendArray(uint8_t *data, uint8_t len);
u8 BCC_Sum1(u8 *usart_data, unsigned char Count_Number);

#endif