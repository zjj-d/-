#include "cradle_head.h"
#include "stdlib.h"

// 全局位置（32细分，X/Y轴软限位）
volatile int32_t Credle_Y_P = 0;   // 修正为有符号int32_t
volatile int32_t Credle_X_P = 0;

StepMotor_Axis motorX = {0};
StepMotor_Axis motorY = {0};

// 电机初始化
void Step_Motor_Init(void) {
    // X轴初始化
    motorX.steps_to_go = 0;
    motorX.phase = 0;
    motorX.dir = 0;
    motorX.running = 0;
    motorX.pulse_delay = START_PULSE_DELAY;
    motorX.counter = 0;
    motorX.start_delay = START_PULSE_DELAY;
    motorX.min_delay = MIN_PULSE_DELAY;
    motorX.accel_steps = ACCEL_STEPS_FIX;
    motorX.decel_steps = ACCEL_STEPS_FIX;

    // Y轴初始化
    motorY.steps_to_go = 0;
    motorY.phase = 0;
    motorY.dir = 0;
    motorY.running = 0;
    motorY.pulse_delay = START_PULSE_DELAY;
    motorY.counter = 0;
    motorY.start_delay = START_PULSE_DELAY;
    motorY.min_delay = MIN_PULSE_DELAY;
    motorY.accel_steps = ACCEL_STEPS_FIX;
    motorY.decel_steps = ACCEL_STEPS_FIX;

    // 脉冲引脚初始低电平
    DL_GPIO_clearPins(Credle_Head_PWM_X_PORT, Credle_Head_PWM_X_PIN);
    DL_GPIO_clearPins(Credle_Head_PWM_Y_PORT, Credle_Head_PWM_Y_PIN);
}

// 软限幅函数
int32_t Cradle_Limit_Value(int32_t Value, int32_t min, int32_t max) {
    if (Value < min) return min;
    if (Value > max) return max;
    return Value;
}

// 计算梯形加减速参数（核心修复）
static void Calculate_Trapezoid_Params(StepMotor_Axis *motor, uint32_t total_steps) {
    if (total_steps == 0) return;

    uint16_t accel = ACCEL_STEPS_FIX;
    uint16_t decel = ACCEL_STEPS_FIX;

    // 短行程：加减速各占一半
    if (total_steps < (accel + decel)) {
        accel = total_steps / 2;
        decel = total_steps - accel;
        accel = (accel == 0) ? 1 : accel;
        decel = (decel == 0) ? 1 : decel;
    }

    // 关键修复：将计算后的加减速步数写入结构体
    motor->accel_steps = accel;
    motor->decel_steps = decel;

    // 小数精度计算（避免速度抖动）
    uint16_t start_val = motor->start_delay << 8;
    uint16_t min_val   = motor->min_delay   << 8;

    motor->accel_step = (start_val - min_val) / motor->accel_steps;
    motor->decel_step = (start_val - min_val) / motor->decel_steps;
    motor->delay_accum = start_val;
    motor->pulse_delay = motor->start_delay;
}

// 非阻塞电机控制（主循环调用）
void Cradle_Head_Control(int32_t steps_x, int32_t steps_y) {
    // X轴控制
    if (steps_x != 0) {   // 去掉 “&& motorX.steps_to_go == 0”
    // 如果正在运行，先强制终止当前运动
    if (motorX.running) {
        motorX.steps_to_go = 0;
        motorX.running = 0;
    }
        Credle_X_P += steps_x;
        Credle_X_P = Cradle_Limit_Value(Credle_X_P, -12800, 12800);
        
        if (Credle_X_P == -12800 || Credle_X_P == 12800) {
            steps_x = 0;
        }

        if (steps_x != 0) {
            uint32_t abs_steps = abs(steps_x);
            motorX.total_steps = abs_steps;  // 关键修复：赋值总步数
            Calculate_Trapezoid_Params(&motorX, abs_steps);

            motorX.dir = (steps_x > 0) ? 0 : 1;
            motorX.steps_to_go = abs_steps;
            motorX.phase = 0;
            motorX.counter = 0;
            motorX.running = 1;

            // 设置方向引脚
            (motorX.dir == 0) ? 
                DL_GPIO_setPins(Credle_Head_X_Control_PORT, Credle_Head_X_Control_PIN) :
                DL_GPIO_clearPins(Credle_Head_X_Control_PORT, Credle_Head_X_Control_PIN);
        }
    }

    // Y轴控制
    if (steps_y != 0 && motorY.steps_to_go == 0) {
        Credle_Y_P += steps_y;
        Credle_Y_P = Cradle_Limit_Value(Credle_Y_P, -1600, 1700);
        
        if (Credle_Y_P == -1600 || Credle_Y_P == 1600) {
            steps_y = 0;
        }

        if (steps_y != 0) {
            uint32_t abs_steps = abs(steps_y);
            motorY.total_steps = abs_steps;  // 关键修复：赋值总步数
            Calculate_Trapezoid_Params(&motorY, abs_steps);

            motorY.dir = (steps_y > 0) ? 0 : 1;
            motorY.steps_to_go = abs_steps;
            motorY.phase = 0;
            motorY.counter = 0;
            motorY.running = 1;

            // 设置方向引脚
            (motorY.dir == 0) ? 
                DL_GPIO_setPins(Credle_Head_Y_Control_PORT, Credle_Head_Y_Control_PIN) :
                DL_GPIO_clearPins(Credle_Head_Y_Control_PORT, Credle_Head_Y_Control_PIN);
        }
    }
}

// 动态更新脉冲延时（梯形加减速核心）
static void Update_Pulse_Delay(StepMotor_Axis *motor) {
    if (!motor->running || motor->total_steps == 0) return;

    uint32_t steps_done = motor->total_steps - motor->steps_to_go;

    if (steps_done < motor->accel_steps) {
        // 加速：减小延时（提高速度）
        motor->delay_accum -= motor->accel_step;
    } else if (motor->steps_to_go <= motor->decel_steps) {
        // 减速：增大延时（降低速度）
        motor->delay_accum += motor->decel_step;
    } else {
        // 匀速：保持最高速
        motor->delay_accum = motor->min_delay << 8;
    }

    // 四舍五入转整数
    motor->pulse_delay = (motor->delay_accum + 128) >> 8;

    // 安全限幅
    if (motor->pulse_delay < motor->min_delay) motor->pulse_delay = motor->min_delay;
    if (motor->pulse_delay > motor->start_delay) motor->pulse_delay = motor->start_delay;
}

// 定时中断服务函数（100us中断一次）
void Motor_IRQ_Handler(void) {
    // X轴脉冲生成
    if (motorX.running && motorX.steps_to_go > 0) {
        motorX.counter++;
        if (motorX.counter >= motorX.pulse_delay) {
            motorX.counter = 0;
            // 输出脉冲
            DL_GPIO_setPins(Credle_Head_PWM_X_PORT, Credle_Head_PWM_X_PIN);
            delay_cycles(DELAY_CNT);
            DL_GPIO_clearPins(Credle_Head_PWM_X_PORT, Credle_Head_PWM_X_PIN);
            delay_cycles(DELAY_CNT);

            motorX.steps_to_go--;
            Update_Pulse_Delay(&motorX);

            if (motorX.steps_to_go == 0) motorX.running = 0;
        }
    }

    // Y轴脉冲生成
    if (motorY.running && motorY.steps_to_go > 0) {
        motorY.counter++;
        if (motorY.counter >= motorY.pulse_delay) {
            motorY.counter = 0;
            // 输出脉冲
            DL_GPIO_setPins(Credle_Head_PWM_Y_PORT, Credle_Head_PWM_Y_PIN);
            delay_cycles(DELAY_CNT);
            DL_GPIO_clearPins(Credle_Head_PWM_Y_PORT, Credle_Head_PWM_Y_PIN);
            delay_cycles(DELAY_CNT);

            motorY.steps_to_go--;
            Update_Pulse_Delay(&motorY);

            if (motorY.steps_to_go == 0) motorY.running = 0;
        }
    }
}
// 查询Y轴是否完成移动（空闲）
uint8_t Cradle_Y_Is_Done(void) {
    return (motorY.steps_to_go == 0 && motorY.running == 0);
}
uint8_t Cradle_All_Done(void) {
    return (motorX.steps_to_go == 0 && motorX.running == 0 &&
            motorY.steps_to_go == 0 && motorY.running == 0);
}
// 紧急停止 X 轴电机
void Cradle_Stop_X(void) {
    motorX.steps_to_go = 0;
    motorX.running = 0;
}
// 激光控制
void Laser_Open(void) {
    DL_GPIO_setPins(Credle_Head_Laser_Control_PORT, Credle_Head_Laser_Control_PIN);
}

void Laser_Close(void) {
    DL_GPIO_clearPins(Credle_Head_Laser_Control_PORT, Credle_Head_Laser_Control_PIN);
}