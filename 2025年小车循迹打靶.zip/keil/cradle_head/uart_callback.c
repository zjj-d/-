#include "ti_msp_dl_config.h"
#include "delay.h"
#include "uart_callback.h"
#include "uart.h"
#include "DataScope_DP.h"
#include <stdio.h>

uint8_t uart3_data;

void usart3_send(u8 data)
{
    while (DL_UART_isTXFIFOFull(UART_YUNTAI_INST) == true);
    DL_UART_Main_transmitData(UART_YUNTAI_INST, data);
}

void USART3_SEND(u8 *data, u8 len)
{
    u8 i = 0;
    for (i = 0; i < len; i++)
    {
        usart3_send(data[i]);
    }
}

// uart send single char
void uart3_send_data(uint8_t data)
{
    usart3_send(data);
}

// send array
void uart3_send_SendArray(uint8_t *data, uint8_t len)
{
    for (uint8_t i = 0; i < len; i++)
    {
        uart3_send_data(data[i]);
    }
}
/* UART3 �����жϣ����ֽ�ƴ�� 9 �ֽڷ���֡��У��ͨ�������ʵʱλ�á� */
void UART_YUNTAI_INST_IRQHandler(void)
{
    if (DL_UART_Main_getPendingInterrupt(UART_YUNTAI_INST) == DL_UART_MAIN_IIDX_RX)
    {
        uart3_data = DL_UART_Main_receiveData(UART_YUNTAI_INST);
        BLDC_ParseRxData(uart3_data);
    }
}