./objects/cradle_head.o: cradle_head\cradle_head.c
