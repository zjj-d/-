#include "uart.h"
#include "encoder.h"
#include "move_average.h"
#include "delay.h"
#include "pid.h"
#include "buzzer.h"
#include "SR04.h"

float EncoderCnt_L = 0;//左编码器计数值
float EncoderCnt_R = 0;//右编码器计数值
float Distance_Left = 0;//左轮路程
float Distance_Right = 0;//右轮路程
int32_t EncoderCnt_Left = 0;//编码器计数值
int32_t EncoderCnt_Right = 0;//编码器计数值

MovingAverageFilter  MovingAverage_Structure_L;//左轮滑动平均滤波结构体
MovingAverageFilter  MovingAverage_Structure_R;//右轮滑动平均滤波结构体
void Encoder_Init(void)
{
	
	/**中断初始化顺序不要改**/
	DL_GPIO_clearInterruptStatus(GPIO_Encoder_PORT, GPIO_Encoder_PIN_A_LEFT_PIN | GPIO_Encoder_PIN_B_LEFT_PIN | GPIO_Encoder_PIN_A_RIGHT_PIN | GPIO_Encoder_PIN_B_RIGHT_PIN); // 清除残留标志
	NVIC_SetPriority(GPIOA_INT_IRQn, 0);
	NVIC_EnableIRQ(GPIOA_INT_IRQn);//使能GPIOA中断
	
	/**中断初始化顺序不要改**/
    Move_Avergae_Filter(&MovingAverage_Structure_L, 10);//左轮滑动平均滤波初始化
    Move_Avergae_Filter(&MovingAverage_Structure_R, 13);//右轮滑动平均滤波初始化
}

/**转化测量的编码器为实际速度，根据不同电机调试**/
float Encoder_Get_Speed(uint8_t Encoder_x)
{
	
	float EncoderCnt_Temp=0;
	
	
	if(Encoder_x == ENCODER_LEFT)
	{

		EncoderCnt_Temp = (float)EncoderCnt_Left * 11.56;
    EncoderCnt_Temp = Update_Avergae_Filter(&MovingAverage_Structure_L, EncoderCnt_Temp);
		EncoderCnt_Left = 0;
		return EncoderCnt_Temp;
	}
	else if(Encoder_x == ENCODER_RIGHT)
	{
		EncoderCnt_Temp = (float)EncoderCnt_Right * 11.56;
    EncoderCnt_Temp = Update_Avergae_Filter(&MovingAverage_Structure_R, EncoderCnt_Temp);

		EncoderCnt_Right = 0;
		return EncoderCnt_Temp;
	}
		
	return 0;
}
/**外部中断的处理函数**/
void GROUP1_IRQHandler(void)//编码器四倍频
{ 
	// DL_GPIO_togglePins(LED_PORT, LED_PIN_14_PIN);
//	delay_us(10);
    uint32_t gpioA = DL_GPIO_getEnabledInterruptStatus(GPIO_Encoder_PORT, GPIO_Encoder_PIN_A_LEFT_PIN | GPIO_Encoder_PIN_B_LEFT_PIN | GPIO_Encoder_PIN_A_RIGHT_PIN | GPIO_Encoder_PIN_B_RIGHT_PIN);
    if ((gpioA & GPIO_Encoder_PIN_A_LEFT_PIN) == GPIO_Encoder_PIN_A_LEFT_PIN) {//其他写法(gpioA & GPIO_Encoder_PIN_A_LEFT_PIN) != 0 或 gpioA & GPIO_Encoder_PIN_A_LEFT_PIN
        if(DL_GPIO_readPins(GPIO_Encoder_PORT, GPIO_Encoder_PIN_B_LEFT_PIN))
				{
           EncoderCnt_Left--;
        }
				else
				{
					EncoderCnt_Left++;
				}
        DL_GPIO_clearInterruptStatus(GPIO_Encoder_PORT, GPIO_Encoder_PIN_A_LEFT_PIN);
    }

	/**以下为右电机**/
		if ((gpioA & GPIO_Encoder_PIN_A_RIGHT_PIN) == GPIO_Encoder_PIN_A_RIGHT_PIN) 
		{//其他写法(gpioA & GPIO_Encoder_PIN_A_RIGHT_PIN) != 0 或 gpioA & GPIO_Encoder_PIN_A_RIGHT_PIN
			if(DL_GPIO_readPins(GPIO_Encoder_PORT, GPIO_Encoder_PIN_B_RIGHT_PIN))
			{
					EncoderCnt_Right--;
			}else
			{
					EncoderCnt_Right++;
			}
			DL_GPIO_clearInterruptStatus(GPIO_Encoder_PORT, GPIO_Encoder_PIN_A_RIGHT_PIN);
    }

    

//	switch( DL_Interrupt_getPendingGroup(DL_INTERRUPT_GROUP_1) )
//    {
//        //检查是否是KEY的GPIOA端口中断，注意是INT_IIDX，不是PIN_18_IIDX
//        case GPIOA_INT_IRQn:
//			
//            //如果按键按下变为高电平
//            if( DL_GPIO_readPins(KEY_PORT, KEY_PIN_18_PIN) > 0 )
//            {
//				delay_ms(10);//按键消抖
//				if( DL_GPIO_readPins(KEY_PORT, KEY_PIN_18_PIN) > 0 )
//				{
//					Page_Flag = !Page_Flag;
//					Clear_Flag = 0;
//				}
//            }
//			 if( DL_GPIO_readPins(KEY_PORT, KEY_PIN_Change_PIN) == 0 )
//            {
////				delay_ms(10);//按键消抖
//				if( DL_GPIO_readPins(KEY_PORT, KEY_PIN_Change_PIN) == 0 )
//				{
//					Start_Flag = 1;
////					Buzzer_Close();
////					Car_Phase_Flag++;
//				}
//				
//            }
			
//			break;
//		
//			
//    }
}
