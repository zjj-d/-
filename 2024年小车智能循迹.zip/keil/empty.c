#include "ti_msp_dl_config.h"
#include "OLED.h"
#include "delay.h"
#include "uart.h"
#include "bno08x_uart_rvc.h"
#include "encoder.h"
#include "pid.h"
#include "motor.h"
#include "software_iic.h"
#include "IIC.h"
#include "stdio.h"
#include "buzzer.h"
#include "cradle_head.h"
#include "UART_host.h"
#include "SR04.h"
#include "key.h"
#include "stdio.h"
extern volatile int32_t Steer_dx ;
extern volatile int32_t Steer_dy ;
extern volatile uint8_t Steer_Go ;   // 1 表示主循环需要执行一次移动

//uint8_t Test_Buffer[4]={0x02, 0x89, 0x11, 0x55};
volatile uint8_t Send_BlueData_Flag=0;//
volatile float SR04_Distance=0;
volatile uint8_t Grey_Data=0;//存放灰度传感器的数据
volatile uint8_t Page_Flag=1;//OLED页面
volatile uint8_t Clear_Flag=0;//OLED清屏标志
volatile uint8_t Str_Data[50];//串口发送数据的数组
uint8_t Start_Flag=0;//程序开始标志位
volatile uint8_t Question_Flag=0;//题目标志位
extern uint8_t Grey[8];//OLED显示用

extern volatile int16_t x_site,y_site;

extern volatile int flag;
//串口初始化放在后面低电平上电会无法进入中断, 串口引脚尽量不要悬空，串口2RX引脚禁止悬空，PA18口尽量不要用
int main(void)
{
	
	SYSCFG_DL_init();
	Buzzer_Close();
	UART_Init();
	// Delay_ms(2500);

	BNO08X_Init();// 陀螺仪初始化，上电位置为初始0值
//	 UART_Init_Bluetooth();
	Encoder_Init();
	OLED_Init();
	Key_Init();


//	SR04_Init();
	Total_PID_Init();	
	//清除定时器中断标志
	NVIC_ClearPendingIRQ(TIMER_0_INST_INT_IRQN);
	// //使能定时器中断
	NVIC_EnableIRQ(TIMER_0_INST_INT_IRQN);
	//清除定时器中断标志
	NVIC_ClearPendingIRQ(TIMER_1_INST_INT_IRQN);
	//使能定时器中断
	NVIC_EnableIRQ(TIMER_1_INST_INT_IRQN);
	
	Motor_Start();//打开电机
//	PWM_Output(MOTOR_LEFT, 0);
//	PWM_Output(MOTOR_RIGHT, 0);
//	DL_TimerG_setCaptureCompareValue(PWM_TURN_INST,500,GPIO_PWM_TURN_C0_IDX);
	// Cardle_Head_Control(-0,1600);
	// Cardle_Head_Control(0, -200);
//Cardle_Head_Control(100,0);

    while (1)
       { 
				 Buzzer_Close();
	
		if(Page_Flag == 1)
		{
			OLED_ShowString(0, 0, "Y:", OLED_6X8);
			OLED_ShowSignedNum(13, 0, bno08x_data.yaw, 3, OLED_6X8);
			OLED_ShowString(0, 10, "P:", OLED_6X8);
			OLED_ShowSignedNum(13, 10, bno08x_data.pitch, 3, OLED_6X8);
			OLED_ShowString(0, 20, " Q3:", OLED_6X8);
			OLED_ShowSignedNum(13, 20, Question_3_Flag, 2, OLED_6X8);

			OLED_ShowString(46, 0, "Gx:", OLED_6X8);
			OLED_ShowSignedNum(70, 0, bno08x_data.ax, 4, OLED_6X8);
			OLED_ShowString(46, 10, "Gy:", OLED_6X8);
			OLED_ShowSignedNum(70, 10, bno08x_data.ay, 4, OLED_6X8);
			OLED_ShowString(46, 20, "Gz:", OLED_6X8);
			OLED_ShowSignedNum(70, 20, bno08x_data.az , 4, OLED_6X8);

			OLED_ShowString(0, 30, "L_S:", OLED_6X8);
			OLED_ShowSignedNum(26, 30, EncoderCnt_L, 4, OLED_6X8);
			OLED_ShowString(0, 40, "R_S:", OLED_6X8);
			OLED_ShowSignedNum(26, 40, EncoderCnt_R, 4, OLED_6X8);

			OLED_ShowString(58, 30, "L_D:", OLED_6X8);
			OLED_ShowSignedNum(84, 30, Distance_Left, 4, OLED_6X8);

			OLED_ShowString(58, 40, "R_D:", OLED_6X8);
			OLED_ShowSignedNum(84, 40, Distance_Right, 4, OLED_6X8);
			//OLED_ShowString(0, 50, "Grey:", OLED_6X8);
			//OLED_ShowSignedNum(32, 50, Grey_Data, 3,  OLED_6X8);
			OLED_ShowString(62, 50, "Q:", OLED_6X8);

			// OLED_ShowSignedNum(34, 50, Black_Line_Data, 3,  OLED_6X8);
			OLED_ShowNum(76, 50, Question_Flag, 1, OLED_6X8);
			OLED_ShowString(85, 50, "C:", OLED_6X8);
			OLED_ShowNum(98, 50, Question_Circle_Num, 1, OLED_6X8);

		  OLED_Update();
		}
		else if(Page_Flag == 0)
		{
			OLED_ShowString(0, 20, "T:", OLED_6X8);
			OLED_ShowFloatNum(10, 20, Uart_Target, 4, 4, OLED_6X8);
			OLED_ShowString(0, 30, "P:", OLED_6X8);
			OLED_ShowFloatNum(10, 30, Uart_KP, 4, 4, OLED_6X8);
			OLED_ShowString(0, 40, "I:", OLED_6X8);
			OLED_ShowFloatNum(10, 40, Uart_KI, 4 , 4, OLED_6X8);
			OLED_ShowString(0, 50, "D:", OLED_6X8);
			OLED_ShowFloatNum(10, 50, Uart_KD, 4, 4, OLED_6X8);


			OLED_ShowString(0, 10, "MV:", OLED_6X8);
			OLED_ShowSignedNum(20, 10, Black_Line_Data, 3,  OLED_6X8);
			
			
			OLED_Update();
		}
		else if (Page_Flag == 2)
		{
			
			OLED_Update();
		}
		
		if(Clear_Flag == 0)
		{
			Cardle_Head_Control(0, 5);
			OLED_Clear();
			Clear_Flag = 1;
			
		}      
		
    }
}

uint8_t UART0_Reset_Flag=0;
uint8_t UART2_Reset_Flag=0;
uint8_t UART3_Reset_Flag=0;


void Timer_DataHandle(void);
//10ms控制一次
void TIMER_0_INST_IRQHandler(void)
{
//		 DL_GPIO_togglePins(LED_PORT, LED_PIN_14_PIN);
    //如果产生了定时器中断
//	 DL_GPIO_togglePins(LED_PORT, LED_PIN_14_PIN);
		/**串口DMA发送到蓝牙**/
    switch( DL_TimerG_getPendingInterrupt(TIMER_0_INST) )
    {
        case DL_TIMER_IIDX_ZERO://如果是0溢出中断
					
					Timer_DataHandle();//处理传感器数据
				uart_work();
					//PWM_Output(MOTOR_LEFT, Uart_Target);//PWM作用到电机
					//PWM_Output(MOTOR_RIGHT, Uart_Target);//PWM作用到电机
					if(Start_Flag == 1)
					{
						
						Car_PID_Calculate();
//						PWM_Output(MOTOR_LEFT, Uart_Target);
//						PWM_Output(MOTOR_RIGHT, Uart_Target);
					}
						
					break;
        default://其他的定时器中断
            break;    
    }
//	DL_GPIO_togglePins(LED_PORT, LED_PIN_14_PIN);
}

//5ms运算一次距离
void TIMER_1_INST_IRQHandler(void)
{

    //如果产生了定时器中断
    switch( DL_TimerG_getPendingInterrupt(TIMER_1_INST) )
    {
      case DL_TIMER_IIDX_ZERO://如果是0溢出中断
			// DL_GPIO_togglePins(LED_PORT, LED_PIN_14_PIN);
			EncoderCnt_L = Encoder_Get_Speed(ENCODER_LEFT);//获取左轮实际速度cm/s
			EncoderCnt_R = Encoder_Get_Speed(ENCODER_RIGHT);//获取右轮实际速度cm/s
			Distance_Left += EncoderCnt_L * 0.005;//计算左轮路程
			Distance_Right += EncoderCnt_R * 0.005;//计算右轮路程
			break;

        default://其他的定时器中断
            break; 
    }

}

void Timer_DataHandle(void)
{
	/**按键检测**/
	Key_Handle();
	/**按键检测**/

		UART2_Reset_Flag = 0;

	/**解算摄像头数据**/
	
}