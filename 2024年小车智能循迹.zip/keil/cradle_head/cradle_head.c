#include "cradle_head.h"

//顺时针为正，从上向下转为正，32细分,1左边X，2左边控制Y
volatile uint32_t Credle_Y_P=200;
volatile uint32_t Credle_X_P=3200;

void Cardle_Head_Control(int32_t Value_X, int32_t Value_Y)
{

		Credle_Y_P += Value_Y;
		Credle_X_P += Value_X;
    if (Credle_X_P <= 0 || Credle_X_P >= 6400)
    {
        Credle_X_P = Cradle_Limit_Value(Credle_X_P, 0, 6400);
        Value_X = 0;   // 停止该轴本次移动
    }

		if(Credle_Y_P <= 0  || Credle_Y_P >= 400)
		{
			Credle_Y_P = Cradle_Limit_Value(Credle_Y_P, 0, 400);
			Value_Y = 0;
		}
		
		if(Value_X >= 0 && Value_Y >=0)
		{
			DL_GPIO_setPins(Credle_Head_X_Control_PORT, Credle_Head_X_Control_PIN);
			DL_GPIO_setPins(Credle_Head_Y_Control_PORT, Credle_Head_Y_Control_PIN);
			uint32_t Temp_Value=(Value_Y + Value_X);
			for(uint32_t i=0; i<Temp_Value; i++)
			{
				if(Value_X > 0)
				{
					DL_GPIO_setPins(Credle_Head_PWM_X_PORT, Credle_Head_PWM_X_PIN);
					delay_cycles(DELAY_CNT);//持续时间超过5us
					DL_GPIO_clearPins(Credle_Head_PWM_X_PORT, Credle_Head_PWM_X_PIN);
					delay_cycles(DELAY_CNT);//持续时间超过5us
					Value_X--;
				}
				if(Value_Y > 0)
				{
					DL_GPIO_setPins(Credle_Head_PWM_Y_PORT, Credle_Head_PWM_Y_PIN);
					delay_cycles(DELAY_CNT);//持续时间超过5us
					DL_GPIO_clearPins(Credle_Head_PWM_Y_PORT, Credle_Head_PWM_Y_PIN);
					delay_cycles(DELAY_CNT);//持续时间超过5us
					Value_Y--;
				}
				if(Value_X == 0 && Value_Y == 0)
				{
					break;
				}
			}
		}
		else if(Value_X >= 0 && Value_Y <= 0)
		{
			DL_GPIO_setPins(Credle_Head_X_Control_PORT, Credle_Head_X_Control_PIN);
			DL_GPIO_clearPins(Credle_Head_Y_Control_PORT, Credle_Head_Y_Control_PIN);
			uint32_t Temp_Value=( Value_X - Value_Y);
			
			for(uint32_t i=0; i<Temp_Value; i++)
			{
				if(Value_X > 0)
				{
					DL_GPIO_setPins(Credle_Head_PWM_X_PORT, Credle_Head_PWM_X_PIN);
					delay_cycles(DELAY_CNT);//持续时间超过5us
					DL_GPIO_clearPins(Credle_Head_PWM_X_PORT, Credle_Head_PWM_X_PIN);
					delay_cycles(DELAY_CNT);//持续时间超过5us
					Value_X--;
				}
				if(Value_Y < 0)
				{
					DL_GPIO_setPins(Credle_Head_PWM_Y_PORT, Credle_Head_PWM_Y_PIN);
					delay_cycles(DELAY_CNT);//持续时间超过5us
					DL_GPIO_clearPins(Credle_Head_PWM_Y_PORT, Credle_Head_PWM_Y_PIN);
					delay_cycles(DELAY_CNT);//持续时间超过5us
					Value_Y++;
				}
				if(Value_X == 0 && Value_Y == 0)
				{
					break;
				}
			}
		}
		else if(Value_X <= 0 && Value_Y <= 0)
		{
			DL_GPIO_clearPins(Credle_Head_X_Control_PORT, Credle_Head_X_Control_PIN);
			DL_GPIO_clearPins(Credle_Head_Y_Control_PORT, Credle_Head_Y_Control_PIN);
			uint32_t Temp_Value=( (-Value_X) - Value_Y);
			
			for(uint32_t i=0; i<Temp_Value; i++)
			{
				if(Value_X < 0)
				{
					DL_GPIO_setPins(Credle_Head_PWM_X_PORT, Credle_Head_PWM_X_PIN);
					delay_cycles(DELAY_CNT);//持续时间超过5us
					DL_GPIO_clearPins(Credle_Head_PWM_X_PORT, Credle_Head_PWM_X_PIN);
					delay_cycles(DELAY_CNT);//持续时间超过5us
					Value_X++;
				}
				if(Value_Y < 0)
				{
					DL_GPIO_setPins(Credle_Head_PWM_Y_PORT, Credle_Head_PWM_Y_PIN);
					delay_cycles(DELAY_CNT);//持续时间超过5us
					DL_GPIO_clearPins(Credle_Head_PWM_Y_PORT, Credle_Head_PWM_Y_PIN);
					delay_cycles(DELAY_CNT);//持续时间超过5us
					Value_Y++;
				}
				if(Value_X == 0 && Value_Y == 0)
				{
					break;
				}
			}
		}
		else if(Value_X <= 0 && Value_Y >= 0)
		{
			DL_GPIO_clearPins(Credle_Head_X_Control_PORT, Credle_Head_X_Control_PIN);
			DL_GPIO_setPins(Credle_Head_Y_Control_PORT, Credle_Head_Y_Control_PIN);
			uint32_t Temp_Value=( Value_Y - Value_X);
			
			for(uint32_t i=0; i<Temp_Value; i++)
			{
				if(Value_X < 0)
				{
					DL_GPIO_setPins(Credle_Head_PWM_X_PORT, Credle_Head_PWM_X_PIN);
					delay_cycles(DELAY_CNT);//持续时间超过5us
					DL_GPIO_clearPins(Credle_Head_PWM_X_PORT, Credle_Head_PWM_X_PIN);
					delay_cycles(DELAY_CNT);//持续时间超过5us
					Value_X++;
				}
				if(Value_Y > 0)
				{
					DL_GPIO_setPins(Credle_Head_PWM_Y_PORT, Credle_Head_PWM_Y_PIN);
					delay_cycles(DELAY_CNT);//持续时间超过5us
					DL_GPIO_clearPins(Credle_Head_PWM_Y_PORT, Credle_Head_PWM_Y_PIN);
					delay_cycles(DELAY_CNT);//持续时间超过5us
					Value_Y--;
				}
				if(Value_X == 0 && Value_Y == 0)
				{
					break;
				}
			}
		}
			
}

int32_t Cradle_Limit_Value(int32_t Value, int32_t Limit_Value_Min , int32_t Limit_Value_Max)
{
	if(Value >= Limit_Value_Max)
	{
		Value = Limit_Value_Max;
	}
	else if(Value <= Limit_Value_Min)
	{
		Value = Limit_Value_Min;
	}
	return Value;
}

void Laser_Open(void)
{
	DL_GPIO_setPins(Credle_Head_Laser_Control_PORT, Credle_Head_Laser_Control_PIN);
}

void Laser_Close(void)
{
	DL_GPIO_clearPins(Credle_Head_Laser_Control_PORT, Credle_Head_Laser_Control_PIN);
}