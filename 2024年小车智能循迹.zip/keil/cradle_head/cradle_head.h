#ifndef __CRADLE_HEAD_H__
#define __CRADLE_HEAD_H__

#include "ti_msp_dl_config.h"
#define PWM_X 0
#define PWM_Y 1
#define DELAY_CNT 640
extern volatile uint32_t Credle_Y_P;
extern volatile uint32_t Credle_X_P;
void Cardle_Head_Control(int32_t Value_X, int32_t Value_Y);
int32_t Cradle_Limit_Value(int32_t Value, int32_t Limit_Value_Min , int32_t Limit_Value_Max);

void Laser_Open(void);

void Laser_Close(void);
#endif
