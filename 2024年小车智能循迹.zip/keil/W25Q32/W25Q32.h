#ifndef __W25Q32_H__
#define __W25Q32_H__

#include "ti_msp_dl_config.h"



#endif
