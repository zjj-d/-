#include "ti_msp_dl_config.h"
#include "gw_color_sensor.h"
#include "Time.h"

#define GREY_SENSOR 0  //0:感为灰度， 1：亚博灰度

#define YW_GRAY_ADDR_DEF 0x12

#define SDA_PIN Grey_Sensor_Grey_SDA_PIN
#define SDA_PORT Grey_Sensor_PORT
#define SCL_PIN Grey_Sensor_Grey_SCL_PIN
#define SCL_PORT Grey_Sensor_PORT

/* 基本I2C操作宏 */
#define SDA_HIGH() DL_GPIO_setPins(SDA_PORT, SDA_PIN)
#define SDA_LOW()  DL_GPIO_clearPins(SDA_PORT, SDA_PIN)
#define SCL_HIGH() DL_GPIO_setPins(SCL_PORT, SCL_PIN)
#define SCL_LOW()  DL_GPIO_clearPins(SCL_PORT, SCL_PIN)
#define READ_SDA() DL_GPIO_readPins(SDA_PORT, SDA_PIN)

unsigned char Ping(void);
uint8_t IIC_WriteBytes(uint8_t Salve_Address, uint8_t Reg_Address,
                           uint8_t *data, uint8_t len);
uint8_t IIC_WriteByte(uint8_t Salve_Address, uint8_t Reg_Address, 
                          uint8_t data);
uint8_t IIC_ReadBytes(uint8_t Salve_Address, uint8_t Reg_Address, 
                          uint8_t *Result, uint8_t len);
uint8_t IIC_ReadByte(uint8_t Salve_Address);
void IIC_Stop(void);