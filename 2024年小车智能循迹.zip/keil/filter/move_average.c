#include "move_average.h"
#include <stdio.h>
#include <stdlib.h>



// 初始化滤波器
void Move_Avergae_Filter(MovingAverageFilter *filter, int window_size)
{
    filter->window_size = window_size;
    filter->buffer = (float *)malloc(window_size * sizeof(float));
    for (int i = 0; i < window_size; i++) {
        filter->buffer[i] = 0.0f; // 初始化为0
    }
    filter->index = 0;
    filter->count = 0;
    filter->sum = 0.0f;
}

// 更新滤波器并返回滤波后的值
float Update_Avergae_Filter(MovingAverageFilter *filter, float new_sample) 
{
    // 若窗口未填满，只增加计数
    if (filter->count < filter->window_size) {
        filter->count++;
    } 
    // 窗口已满时，先移除最旧数据
    else {
        filter->sum -= filter->buffer[filter->index]; // 移除旧数据
    }

    // 添加新数据到缓冲区
    filter->buffer[filter->index] = new_sample;
    filter->sum += new_sample;

    // 更新环形缓冲区索引
    filter->index = (filter->index + 1) % filter->window_size;

    // 计算当前平均值（避免除零错误）
    return (filter->count > 0) ? (filter->sum / filter->count) : 0;
}

// 释放滤波器内存
void freeFilter(MovingAverageFilter *filter) 
{
    free(filter->buffer);
}
