#ifndef __MOVE_AVERAGE_H__
#define __MOVE_AVERAGE_H__

#include "ti_msp_dl_config.h"

// 滑动平均滤波器结构体
typedef struct {
    float *buffer;      // 数据缓冲区（动态内存）
    int window_size;    // 窗口大小（N）
    int index;          // 当前写入位置
    int count;          // 当前有效数据计数（初始化阶段用）
    float sum;          // 窗口内数据的运行总和
} MovingAverageFilter;


// 初始化滤波器
void Move_Avergae_Filter(MovingAverageFilter *filter, int window_size);
// 更新滤波器并返回滤波后的值
float Update_Avergae_Filter(MovingAverageFilter *filter, float new_sample);
void freeFilter(MovingAverageFilter *filter);

#endif
