#ifndef __CIRCULAR_QUEUE_H__
#define __CIRCULAR_QUEUE_H__

#include "ti_msp_dl_config.h"

typedef struct 
{
    volatile uint8_t *Head;                 // 读指针
    volatile uint8_t *Tail;                 // 写指针
	volatile uint8_t Flag1;  
	volatile uint8_t Flag2;
} CircularBuffer;

typedef struct 
{
    CircularBuffer Front;    // 前台缓冲区（CPU处理）
    CircularBuffer Back;     // 后台缓冲区（DMA写入）
    volatile bool Ready;     // 后台数据就绪标志
} DoubleBuffer;

#endif


