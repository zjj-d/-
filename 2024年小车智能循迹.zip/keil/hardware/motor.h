#ifndef __MOTOR_H__
#define __MOTOR_H__

#include "ti_msp_dl_config.h"

#define MOTOR_LEFT     0
#define MOTOR_RIGHT    1

extern uint8_t Motor_Left_Front;
extern uint8_t Motor_Right_Front;

void PWM_Output(uint8_t Motor_x, int32_t PWM_Value);
void Motor_Start(void);
void Motor_Stop(void);
void PWM_Output_NOSpeed(uint8_t Motor_x, int16_t PWM_Value);//专用于无速度固定角度的PID

#endif