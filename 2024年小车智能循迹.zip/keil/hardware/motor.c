#include "motor.h"

uint8_t Motor_Left_Front = 0;//0：正转，1：反转
uint8_t Motor_Right_Front = 0;//0：正转，1：反转

//输出PWM作用到电机
void PWM_Output(uint8_t Motor_x, int32_t PWM_Value)
{
	if(Motor_x == MOTOR_LEFT)
	{
		if(PWM_Value > 0)
		{
			DL_GPIO_clearPins(GPIO_Motor_PORT, GPIO_Motor_PIN_A_1_PIN);
			DL_GPIO_setPins(GPIO_Motor_PORT, GPIO_Motor_PIN_A_2_PIN);
			
			if(PWM_Value > 10)//320为电机死区
			{
				DL_TimerG_setCaptureCompareValue(PWM_LEFT_INST,PWM_Value,GPIO_PWM_LEFT_C0_IDX);
			}
			else
			{
				DL_TimerG_setCaptureCompareValue(PWM_LEFT_INST,10,GPIO_PWM_LEFT_C0_IDX);
			}
		}
		else if(PWM_Value < 0)
		{
			DL_TimerG_setCaptureCompareValue(PWM_LEFT_INST, 0, GPIO_PWM_LEFT_C0_IDX);
		}
	}
	else if(Motor_x == MOTOR_RIGHT)
	{
		if(PWM_Value > 0)//60为电机死区
		{
			DL_GPIO_clearPins(GPIO_Motor_PORT, GPIO_Motor_PIN_B_1_PIN);
			DL_GPIO_setPins(GPIO_Motor_PORT, GPIO_Motor_PIN_B_2_PIN);
			
			
			if(PWM_Value > 10)//320为电机死区
			{
				DL_TimerG_setCaptureCompareValue(PWM_RIGHT_INST, PWM_Value, GPIO_PWM_RIGHT_C0_IDX);
			}
			else
			{
				DL_TimerG_setCaptureCompareValue(PWM_RIGHT_INST, 10, GPIO_PWM_RIGHT_C0_IDX);
			}
			
		}
		else if(PWM_Value < 0)
		{

			DL_TimerG_setCaptureCompareValue(PWM_RIGHT_INST, 0, GPIO_PWM_RIGHT_C0_IDX);

			
		}
	}
	
	
}

void PWM_Output_NOSpeed(uint8_t Motor_x, int16_t PWM_Value)//专用于无速度固定角度的PID
{
	if(Motor_x == MOTOR_LEFT)
	{
		if(PWM_Value > 0)//40为电机死区
		{
			if(PWM_Value > 60)
			{
				DL_TimerG_setCaptureCompareValue(PWM_LEFT_INST,PWM_Value,GPIO_PWM_LEFT_C0_IDX);
			}
			else
			{
				DL_TimerG_setCaptureCompareValue(PWM_LEFT_INST,60,GPIO_PWM_LEFT_C0_IDX);
			}
			DL_GPIO_setPins(GPIO_Motor_PORT, GPIO_Motor_PIN_A_1_PIN);
			DL_GPIO_clearPins(GPIO_Motor_PORT, GPIO_Motor_PIN_A_2_PIN);
			
			
		}
		else
		{
			DL_GPIO_clearPins(GPIO_Motor_PORT, GPIO_Motor_PIN_A_1_PIN);
			DL_GPIO_setPins(GPIO_Motor_PORT, GPIO_Motor_PIN_A_2_PIN);
			//由于外部中断测速可能会意外输出负值，为了让车辆稳定，故不让电机反转
			// DL_GPIO_setPins(GPIO_Motor_PORT, GPIO_Motor_PIN_A_1_PIN);
			// DL_GPIO_clearPins(GPIO_Motor_PORT, GPIO_Motor_PIN_A_2_PIN);
			if(PWM_Value < -60)
			{
				DL_TimerG_setCaptureCompareValue(PWM_LEFT_INST, -PWM_Value, GPIO_PWM_LEFT_C0_IDX);
			}
			else
			{
				DL_TimerG_setCaptureCompareValue(PWM_LEFT_INST,60,GPIO_PWM_LEFT_C0_IDX);
			}
			
		}
	}
	else if(Motor_x == MOTOR_RIGHT)
	{
		if(PWM_Value > 0)//60为电机死区
		{
			if(PWM_Value > 60)
			{
				DL_TimerG_setCaptureCompareValue(PWM_RIGHT_INST,PWM_Value,GPIO_PWM_RIGHT_C0_IDX);
			}
			else
			{
				DL_TimerG_setCaptureCompareValue(PWM_RIGHT_INST,60,GPIO_PWM_RIGHT_C0_IDX);
			}
			DL_GPIO_setPins(GPIO_Motor_PORT, GPIO_Motor_PIN_B_1_PIN);
			DL_GPIO_clearPins(GPIO_Motor_PORT, GPIO_Motor_PIN_B_2_PIN);

			
		}
		else
		{
			DL_GPIO_clearPins(GPIO_Motor_PORT, GPIO_Motor_PIN_B_1_PIN);
			DL_GPIO_setPins(GPIO_Motor_PORT, GPIO_Motor_PIN_B_2_PIN);
			if(PWM_Value > 60)
			{
				DL_TimerG_setCaptureCompareValue(PWM_RIGHT_INST, -PWM_Value, GPIO_PWM_RIGHT_C0_IDX);
			}
			else
			{
				DL_TimerG_setCaptureCompareValue(PWM_RIGHT_INST, 60, GPIO_PWM_RIGHT_C0_IDX);
			}
			//由于外部中断测速可能会输出负值，为了让车辆稳定，故不让电机反转
			// DL_GPIO_setPins(GPIO_Motor_PORT, GPIO_Motor_PIN_A_1_PIN);
			// DL_GPIO_clearPins(GPIO_Motor_PORT, GPIO_Motor_PIN_A_2_PIN);
			DL_TimerG_setCaptureCompareValue(PWM_RIGHT_INST, -PWM_Value, GPIO_PWM_RIGHT_C0_IDX);
		}
	}
	
	
}
//打开电机
void Motor_Start(void)
{
	DL_GPIO_setPins(GPIO_Motor_PORT, GPIO_Motor_PIN_STBY_PIN);
}
//关闭电机
void Motor_Stop(void)
{
	DL_GPIO_clearPins(GPIO_Motor_PORT, GPIO_Motor_PIN_STBY_PIN);
}