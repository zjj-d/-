#include "delay.h"

volatile unsigned int delay_times = 0;



//搭配滴答定时器实现的精确us延时
void Delay_us( uint32_t us)
{
    delay_times = us;
    while( delay_times != 0 );
}
//搭配滴答定时器实现的精确ms延时
void Delay_ms(unsigned int ms)
{
    Delay_us(ms * 1000);
}

//软件的微秒延时,不精准
void __attribute__((optnone)) delay_us(uint32_t us) 
{
    uint32_t cycles = us * 1;  // 经验值：80MHz下≈13周期/μs
    while (cycles--) {
        __NOP();                // 插入空指令（消耗1周期）
    }
}

//软件的毫秒延时,不精准
void delay_ms(uint32_t ms) 
{
    delay_us(ms*3333);
}
//滴答定时器中断服务函数
void SysTick_Handler(void)
{
    if( delay_times != 0 )
    {
        delay_times--;
    }
}