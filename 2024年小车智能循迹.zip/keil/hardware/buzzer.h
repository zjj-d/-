#ifndef __BUZZER_H__
#define __BUZZER_H__

#include "ti_msp_dl_config.h"

//打开蜂鸣器，PA21
void Buzzer_Open(void);

//关闭蜂鸣器，PA21
void Buzzer_Close(void);

#endif
