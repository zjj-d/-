#include "uart.h"
#include "bno08x_uart_rvc.h"
#include "stdlib.h"
#include "pid.h"
#include "circular_queue.h"
#include "UART_host.h"
#include <stdio.h>
#include "string.h"
/**此函数解算来自VOFA的串口16进制数据，转为Speed_Data**/
volatile unsigned char uart_data = 0;
uint16_t Speed_Data=0;
uint8_t Uart_ReceiveData[5];//包头：0x66, 速度高8位， 速度低8位，包尾0x77
uint8_t Speed_ReceiveData_Flag=0;
volatile uint8_t VOFA_Flag = 0;
void Speed_ReceiveData(uint8_t RxData)
{
	
	if(Speed_ReceiveData_Flag == 0)
	{
		if(RxData == 0x66)
		{
			Speed_ReceiveData_Flag = 1;
			Uart_ReceiveData[0] = RxData;
		}
	}
	else if(Speed_ReceiveData_Flag >= 1 && Speed_ReceiveData_Flag <= 2)
	{
		Uart_ReceiveData[Speed_ReceiveData_Flag] = RxData;
		Speed_ReceiveData_Flag++;
	}
	else if(Speed_ReceiveData_Flag > 2 && RxData == 0x77)
	{
		Speed_Data = 0;
		Speed_Data = Speed_Data | (Uart_ReceiveData[1] << 8);
		Speed_Data = Speed_Data | Uart_ReceiveData[2];
		Speed_ReceiveData_Flag = 0;
	}
	
}

/**此函数解算来自K230的串口数据**/
//AA 1 2  3 4  5  6  7 8  9 10 11 AA+1+2 0A 0D
volatile uint16_t Black_Line_Data=0;//接收黑线坐标
uint8_t Uart_Black_Line_Data[15];//包头：0xAA, 速度高8位， 速度低8位，包尾校验和
volatile uint8_t Uart_Camera_Data[14];//接收的数据

uint8_t Black_Line_Receive_Flag=0;
uint8_t Black_Line_ReceiveData(uint8_t RxData)
{
	uint8_t Success_Flag=0;
	if(Black_Line_Receive_Flag == 0)
	{
		if(RxData == 0xAA)
		{
			Black_Line_Receive_Flag = 1;
			Uart_Black_Line_Data[0] = RxData;
		}
	}
	else if(Black_Line_Receive_Flag >= 1 && Black_Line_Receive_Flag <= 11)
	{
		Uart_Black_Line_Data[Black_Line_Receive_Flag] = RxData;
		Black_Line_Receive_Flag++;
	}
	else if(Black_Line_Receive_Flag == 12 && RxData == ((0xAA + Uart_Black_Line_Data[1] + Uart_Black_Line_Data[2]) & 0xFF))
	{
		for (uint8_t i = 0; i < 11; i++)
		{
			Uart_Camera_Data[i] = Uart_Black_Line_Data[i+1];
		}
		Black_Line_Receive_Flag = 0;
		Success_Flag = 1;
	}
	else
	{
		Black_Line_Receive_Flag = 0;
	}
	 return Success_Flag;
}


/**串口的初始化**/
volatile uint8_t gRxPacket_K210[UART_PACKET_SIZE_K210];//串口DMA接收K210数据的数组
volatile uint8_t gRxPacket_K210_2[UART_PACKET_SIZE_K210];//串口DMA接收K210数据的数组2
volatile uint8_t gRxPacket_Blue[UART_PACKET_SIZE_BLUE];//串口DMA接收蓝牙数据的数组
volatile uint8_t gRxPacket_Blue_2[UART_PACKET_SIZE_BLUE];//串口DMA接收蓝牙数据的数组2
volatile uint8_t gTxPacket_Blue[UART_PACKET_SIZE_BLUE] = {0xCC,0x77, 0x88, 0x11, 0x99,0xDD};//串口DMA发送蓝牙数据的数组
volatile uint8_t gTXCheckUART_Blue=true;
volatile uint8_t gTXDMADone_Blue=true;
void UART_Init(void)
{		
	/**串口DMA初始化**/
	
	/**中断初始化顺序不要改**/
//   	//清除串口中断标志
  NVIC_ClearPendingIRQ(UART_0_TEST_INST_INT_IRQN);
	//使能串口中断  
    NVIC_EnableIRQ(UART_0_TEST_INST_INT_IRQN);
// 	//清除串口中断标志 K230
//	  NVIC_ClearPendingIRQ(UART_2_K210_INST_INT_IRQN);
//	//使能串口中断  
//    NVIC_EnableIRQ(UART_2_K210_INST_INT_IRQN);
    DL_SYSCTL_disableSleepOnExit();
	//    DL_SYSCTL_enableSleepOnExit();
	
}


void UART_Init_K210(void);
void UART_Init_Bluetooth(void);
void UART_Reset(uint8_t Uart_X)
{
	uint8_t Error_Data;
	if(Uart_X == 0)//VOFA
	{
		/**VOFA**/

		//清除串口中断标志
		NVIC_ClearPendingIRQ(UART_0_TEST_INST_INT_IRQN);
		
	}
	else if (Uart_X == 1)
	{
		DL_DMA_disableChannel(DMA, DMA_CH0_CHAN_ID);//关闭DMA
		while(!DL_UART_isRXFIFOEmpty(UART_1_BNO08X_INST))
		{
			Error_Data = DL_UART_receiveData(UART_1_BNO08X_INST);//清空FIFO防止对后续数据产生干扰
		}
		BNO08X_Init();
	}


//	else if (Uart_X == 3)
//	{
//		DL_DMA_disableChannel(DMA, DMA_CH2_CHAN_ID);//关闭DMA
//		while(!DL_UART_isRXFIFOEmpty(UART_3_BLUE_INST))
//		{
//			Error_Data = DL_UART_receiveData(UART_3_BLUE_INST);//清空FIFO防止对后续数据产生干扰
//		}
//		UART_Init_Bluetooth();
//	}
	
}



void UART_Init_Bluetooth(void)
{
	/**bluetooth**/
	/**DMA接收**/
//	DL_DMA_setSrcAddr(DMA, DMA_CH2_CHAN_ID, (uint32_t)(&UART_3_BLUE_INST->RXDATA));
//    DL_DMA_setDestAddr(DMA, DMA_CH2_CHAN_ID, (uint32_t) &gRxPacket_Blue[0]);
//    DL_DMA_setTransferSize(DMA, DMA_CH2_CHAN_ID, UART_PACKET_SIZE_BLUE);
//	// DL_DMA_enableChannel(DMA, DMA_CH2_CHAN_ID);
//	/**DMA接收**/
//	/**bluetooth**/

//	/**中断初始化顺序不要改,串口引脚尽量不要悬空**/
//	//使能串口中断
//    NVIC_EnableIRQ(UART_3_BLUE_INST_INT_IRQN);
//	//清除串口中断标志
//    NVIC_ClearPendingIRQ(UART_3_BLUE_INST_INT_IRQN);
    /**中断初始化顺序不要改,串口引脚尽量不要悬空**/
}




CircularBuffer Uart_K210_P =//K210缓冲区指针
{
	.Head = gRxPacket_K210,//指向缓冲区1
	.Tail = gRxPacket_K210_2,//指向缓冲区2
};

CircularBuffer Uart_Blue_P =//蓝牙缓冲区指针
{
	.Head = gRxPacket_Blue,//指向缓冲区1
	.Tail = gRxPacket_Blue_2,//指向缓冲区2
};



//解算串口接收的来自Blue数据，方便外部调用
uint8_t Uart_Calculate_Blue_Data(void)
{
	uint8_t Success_Flag=0;
	for(uint8_t i=0; i<9; i++)
	{
		if(Blue_ReceiveData(*(Uart_Blue_P.Tail+i)) == 1)
		{
			Success_Flag = 1;
			for(uint8_t j=0; j<9; j++)
			{
				*(Uart_Blue_P.Tail+j) = 0;
			}
		}//解算数据
	}
	return Success_Flag;
}



/*
VOFA上位机调PID
上位机实时调参
Uart_KI，Uart_KP，Uart_KD,Uart_Target.
需要将参数传入各个pid
P1=%f\rn -->Uart_KP
I1=%f\rn -->Uart_KI
D1=%f\rn -->Uart_KD
T1=%f\rn -->Uart_Target
不能边传PID参数，边传回PID参数，会卡死
如果需要查看调参现象去主循 环调用printf单独发回vofa，不要在中断里改变
*/

//串口发送单个字符
void uart0_send_char(UART_Regs *UARTX, char ch)
{
    //当串口忙的时候等待，不忙的时候再发送传进来的字符
    while( DL_UART_isBusy(UARTX) == true );
    //发送单个字符
    DL_UART_Main_transmitData(UARTX, ch);
}
//串口发送字符串
void uart0_send_string(UART_Regs *UARTX,  char* str)
{
    //当前字符串地址不在结尾 并且 字符串首地址不为空
    while(*str!=0&&str!=0)
    {
        //发送字符串首地址中的字符，并且在发送完成之后首地址自增
        uart0_send_char(UARTX, *str++);
    }
}


//此函数解析由VOFA发送的PID数据并解算，方便PID调试
volatile float Uart_KP=0, Uart_KI=0, Uart_KD=0;  // VOFA+发送PID值
volatile float Uart_Target=0;                   // VOFA+发送的目标值
uint8_t Uart_ReceivePID_Flag=0;                 // 状态机标志
char    Uart_ReceivePID_Buf[16];                // 存数字字符串
uint8_t Uart_ReceivePID_Len=0;                   // 数字长度

void Uart_ReceivePID_Data(uint8_t RxData)
{
    if(Uart_ReceivePID_Flag == 0)
    {
        // 等待帧头 K
        if(RxData == 'K')
        {
            Uart_ReceivePID_Flag = 1;
        }
    }
    else if(Uart_ReceivePID_Flag == 1)
    {
        // 接收 P/I/D/T
        if(RxData == 'P' || RxData == 'I' || RxData == 'D' || RxData == 'T')
        {
            Uart_ReceivePID_Flag = 2;
            Uart_ReceivePID_Buf[0] = RxData;  // 存类型 P/I/D/T
            Uart_ReceivePID_Len = 1;
        }
        else
        {
            Uart_ReceivePID_Flag = 0;  // 错误，重置
        }
    }
    else if(Uart_ReceivePID_Flag == 2)
    {
        // 接收数字，直到 Z 结束
        if(RxData == 'Z')
        {
            // 结束符，添加字符串结束标志 \0
            Uart_ReceivePID_Buf[Uart_ReceivePID_Len] = '\0';
            
            // 解析数据
            if(Uart_ReceivePID_Buf[0] == 'P')
            {
                Uart_KP = atof(&Uart_ReceivePID_Buf[1]);
            }
            else if(Uart_ReceivePID_Buf[0] == 'I')
            {
                Uart_KI = atof(&Uart_ReceivePID_Buf[1]);
            }
            else if(Uart_ReceivePID_Buf[0] == 'D')
            {
                Uart_KD = atof(&Uart_ReceivePID_Buf[1]);
            }
            else if(Uart_ReceivePID_Buf[0] == 'T')
            {
                Uart_Target = atof(&Uart_ReceivePID_Buf[1]);
            }
            
            // 重置
            Uart_ReceivePID_Flag = 0;
            Uart_ReceivePID_Len = 0;
        }
        // 只接收 0-9 . 这些有效字符
        else if((RxData >= '0' && RxData <= '9') || RxData == '.')
        {
            if(Uart_ReceivePID_Len < 14)
            {
                Uart_ReceivePID_Buf[Uart_ReceivePID_Len++] = RxData;
            }
        }
        // 非法字符，重置
        else
        {
            Uart_ReceivePID_Flag = 0;
            Uart_ReceivePID_Len = 0;
        }
    }
}

/*此中断用于vofa调参pid*/
void UART_0_TEST_INST_IRQHandler(void)
{
    //如果产生了串口中断
    switch( DL_UART_getPendingInterrupt(UART_0_TEST_INST) )
    {
        case DL_UART_IIDX_RX://如果是接收中断
            //接发送过来的数据保存在变量中
            uart_data = DL_UART_Main_receiveData(UART_0_TEST_INST);

							//Speed_ReceiveData(uart_data);
				Uart_ReceivePID_Data(uart_data);
            //将保存的数据再发送出去
//            uart0_send_char(UART_0_TEST_INST, uart_data);
            break;

        default://其他的串口中断
            break;
    }
}


/*此中断读取陀螺仪值*/

void UART_1_BNO08X_INST_IRQHandler(void)
{
    uint8_t checkSum = 0;
    extern uint8_t bno08x_dmaBuffer[19];

    DL_DMA_disableChannel(DMA, DMA_CH0_CHAN_ID);
    uint8_t rxSize = 18 - DL_DMA_getTransferSize(DMA, DMA_CH0_CHAN_ID);

    if(DL_UART_isRXFIFOEmpty(UART_1_BNO08X_INST) == false)
        bno08x_dmaBuffer[rxSize++] = DL_UART_receiveData(UART_1_BNO08X_INST);

    for(int i=2; i<=14; i++)
        checkSum += bno08x_dmaBuffer[i];

    if((rxSize == 19) && (bno08x_dmaBuffer[0] == 0xAA) && (bno08x_dmaBuffer[1] == 0xAA) && (checkSum == bno08x_dmaBuffer[18]))
    {
        bno08x_data.index = bno08x_dmaBuffer[2];
        bno08x_data.yaw = (int16_t)((bno08x_dmaBuffer[4]<<8)|bno08x_dmaBuffer[3]) / 100.0;
        bno08x_data.pitch = (int16_t)((bno08x_dmaBuffer[6]<<8)|bno08x_dmaBuffer[5]) / 100.0;
        bno08x_data.roll = (int16_t)((bno08x_dmaBuffer[8]<<8)|bno08x_dmaBuffer[7]) / 100.0;
        bno08x_data.ax = (bno08x_dmaBuffer[10]<<8)|bno08x_dmaBuffer[9];
        bno08x_data.ay = (bno08x_dmaBuffer[12]<<8)|bno08x_dmaBuffer[11];
        bno08x_data.az = (bno08x_dmaBuffer[14]<<8)|bno08x_dmaBuffer[13];
    }
    
    uint8_t dummy[4];
    DL_UART_drainRXFIFO(UART_1_BNO08X_INST, dummy, 4);

    DL_DMA_setDestAddr(DMA, DMA_CH0_CHAN_ID, (uint32_t) &bno08x_dmaBuffer[0]);
    DL_DMA_setTransferSize(DMA, DMA_CH0_CHAN_ID, 18);
    DL_DMA_enableChannel(DMA, DMA_CH0_CHAN_ID);
}

//注意串口接收中断名字，串口2-RX引脚不能为空，否则判断是否忙碌会卡死

char Serial_RxPacket[100]; 		
uint8_t Serial_RxFlag;
//void UART_2_K210_INST_IRQHandler(void)
//{
//	static uint8_t RxState = 0;
//	static uint8_t pRxPacket = 0;
//	uint8_t RxData;
//	
//    switch (DL_UART_Main_getPendingInterrupt(UART_2_K210_INST)) {
//        case DL_UART_MAIN_IIDX_RX:
//            RxData = DL_UART_Main_receiveData(UART_2_K210_INST);

//			if (RxState == 0)
//			{
//				if (RxData == '[' && Serial_RxFlag == 0)
//				{
//					RxState = 1;
//					pRxPacket = 0;
//				}
//			}
//			else if (RxState == 1)
//			{
//				if (RxData == '*')
//				{
//					RxState = 2;
//				}
//				else
//				{
//					Serial_RxPacket[pRxPacket] = RxData;
//					pRxPacket ++;
//				}
//			}
//			else if (RxState == 2)
//			{
//				if (RxData == ']')
//				{
//					RxState = 0;
//					Serial_RxPacket[pRxPacket] = '\0';
//					Serial_RxFlag = 1;
//				}
//				else
//				{
//        Serial_RxPacket[pRxPacket] = RxData;   // 存 y 坐标
//        pRxPacket++;
//				}
//			}
//		
//            break;
//        default:
//            break;
//    }
//}

extern volatile int16_t x_site,y_site;
int uart_work(void) //串口函数
{
    if (Serial_RxFlag == 1) {
        // 处理接收到的数据
        if (strlen(Serial_RxPacket) != 8) 
        {
//            printf("数据长度错误！\n");
            Serial_RxFlag = 0;
            return -1;
        }
        else
        {
            // 提取前4位（x坐标）
            char x_str[5] = {0};
            strncpy(x_str, Serial_RxPacket, 4);
    
            // 提取后4位（y坐标）
            char y_str[5] = {0};
            strncpy(y_str, Serial_RxPacket + 4, 4);
    
            // 转换为整数
            x_site = atoi(x_str);
            y_site = atoi(y_str);
            //LED1_ON();LED2_ON();
            // 重置标志位以接收下一个包
//							sprintf(Str_Data, "%d, %d\r\n", x_site, y_site);
//						uart0_send_string(UART_0_TEST_INST , Str_Data);
            Serial_RxFlag = 0;
            return 0;
        }       
    }
	return -1;
}
