#include "bno08x_uart_rvc.h"
#include "pid.h"
#include "motor.h"
#include "encoder.h"
#include "uart.h"
#include "gw_grayscale_sensor.h"
#include "stdio.h"
#include "SR04.h"
#include "UART_host.h"
#include "Fuzzy_pid.h"
#include "cradle_head.h"
#include "stdlib.h"
#include "buzzer.h"
#include "delay.h"
volatile int32_t Steer_dx = 0;
volatile int32_t Steer_dy = 0;
volatile uint8_t Steer_Go = 0;   // 1 表示主循环需要执行一次移动



// 初始化PID控制器
void PID_Init(PID_Structure* pid, float Kp, float Ki, float Kd, float Output_Limit, float Target_Value) 
{
    pid->Kp = Kp;
    pid->Ki = Ki;
    pid->Kd = Kd;
    pid->Output_Limit = Output_Limit;
    pid->Prev_Error = 0.0f;
    pid->Integral = 0.0f;
	pid->Target_Value = Target_Value;
}
FuzzyPIDController FZ_Grey_BlackLine_Pid;
PID_Structure Speed_Left_Pid;//左轮PID初始化,0.5-·1m/s的PID
PID_Structure Speed_Right_Pid;//右轮PID初始化,0.5-1m/s的PID;


PID_Structure Grey_BlackLine_Pid;//灰度循迹PID
PID_Structure NO_Speed_Turn_Pid_Out;//无速度转向外环
PID_Structure NO_Speed_Turn_Pid_In;//无速度转向内环
PID_Structure Target_Tracking_X;
PID_Structure Target_Tracking_Y;


PID_Structure PID_Structure_Steer_X;//步进电机增量式PID结构体
PID_Structure PID_Structure_Steer_Y;//步进电机增量式PID结构体
// PID_Structure_Incremental PID_Structure_Steer_X;//步进电机增量式PID结构体
// PID_Structure_Incremental PID_Structure_Steer_Y;//步进电机增量式PID结构体

/*步进电机跟踪陀螺仪结构体*/
PID_Structure PID_Structure_Steer_BNO08X_X;//步进电机跟踪陀螺仪PID结构体
PID_Structure PID_Structure_Steer_BNO08X_Y;//步进电机
void Total_PID_Init(void) 
{
	/**无速度转向环**/
	PID_Init(&NO_Speed_Turn_Pid_Out,  5, -0.1, 0, 160, 0);
	PID_Init(&NO_Speed_Turn_Pid_In,  -16, -0.5, 6, 4000, 0);
	/**无速度转向环**/

	/**速度环**/
	PID_Init(&Speed_Left_Pid, 15, 0.35, 0, 4000, 0);//左轮PID初始化,1m/s以内的PID**
	PID_Init(&Speed_Right_Pid,  15, 0.35, 0, 4000, 0);//右轮PID初始化,1m/s以内的PID**
	/**速度环**/
	
	/**灰度循迹PID */
	PID_Init(&Grey_BlackLine_Pid,  0.90, -0, -0.45, 70, 0);//灰度循迹PID，0.3m/s
	/**灰度循迹PID */

	/**步进电机PID */

	// PID_Init(&PID_Structure_Steer_X, -0.061, -0.038, 0.051, 200, 0);//左轮PID初始化,1m/s以内的PID**
	// PID_Init(&PID_Structure_Steer_Y,  -0.061, -0.034, 0, 200, 0);//右轮PID初始化,1m/s以内的PID**
	PID_Init(&PID_Structure_Steer_X, -0.098, -0.002, 0.055, 200, 0);//左轮PID初始化,1m/s以内的PID**
	PID_Init(&PID_Structure_Steer_Y,  -0.079, -0.002, 0.003, 200, 0);//右轮PID初始化,1m/s以内的PID**
	// PID_Incremental_Init(&PID_Structure_Steer_X, 0, 0, 0, 20, 0);
	// PID_Incremental_Init(&PID_Structure_Steer_Y, 0, 0, 0, 20, 0);
	
	
	
	/**步进电机PID 跟踪陀螺仪*/
	PID_Init(&PID_Structure_Steer_BNO08X_X,-0.098, -0.002, 0.055, 200, 0);
	PID_Init(&PID_Structure_Steer_BNO08X_Y, 0, 0, 0.0, 200, 0);
}




// 单级PID计算函数（角度输入）
float PID_Calculate(PID_Structure* pid, float Current_Value) 
{
	// 1. 计算当前误差
	float Error = pid->Target_Value - Current_Value;

	// 2. 积分项计算（带抗饱和）
	pid->Integral += Error;
	// 积分限幅防止饱和
	if (pid->Integral > pid->Output_Limit) pid->Integral = pid->Output_Limit;
	else if (pid->Integral < -pid->Output_Limit) pid->Integral = -pid->Output_Limit;

	// 3. 微分项计算（使用两次误差差）
	float derivative = Error - pid->Prev_Error; // KD采用两次误差差

	// 4. 计算PID输出
	float Output = (pid->Kp * Error)           // 比例项
				+ (pid->Ki * pid->Integral)    // 积分项
				+ (pid->Kd * derivative);      // 微分项（重点）

	// 5. 输出限幅
	if (Output > pid->Output_Limit) Output = pid->Output_Limit;
	else if (Output < -pid->Output_Limit) Output = -pid->Output_Limit;

	// 6. 更新误差记录
	pid->Prev_Error = Error;

	return Output;
}
// 单级PID计算函数,微分项采用陀螺仪角速度
float PID_Calculate_2(PID_Structure* pid, float Current_Value, int16_t Angle_Speed) 
{
	// 1. 计算当前误差
	float Error = pid->Target_Value - Current_Value;

	// 2. 积分项计算（带抗饱和）
	pid->Integral += Error;
	// 积分限幅防止饱和
	if (pid->Integral > pid->Output_Limit) pid->Integral = pid->Output_Limit;
	else if (pid->Integral < -pid->Output_Limit) pid->Integral = -pid->Output_Limit;



	// 4. 计算PID输出
	float Output = (pid->Kp * Error)           // 比例项
				+ (pid->Ki * pid->Integral)    // 积分项
				+ (pid->Kd * Angle_Speed);      // 微分项（重点）

	// 5. 输出限幅
	if (Output > pid->Output_Limit) Output = pid->Output_Limit;
	else if (Output < -pid->Output_Limit) Output = -pid->Output_Limit;

	return Output;
}

// 角度环专用PID函数
float PID_Calculate_No_Speed(PID_Structure* pid, float Current_Value, int16_t Angle_Speed) 
{
	// 1. 计算当前误差
	float Error = pid->Target_Value - Current_Value;
    if (Error > 180) 
	Error -= 360;   // 误差>180°时顺时针修正
    else if(Error < -180) 
	Error += 360; // 误差<-180°时逆时针修正

	// 2. 积分项计算（带抗饱和）
	pid->Integral += Error;
	// 积分限幅防止饱和
	if (pid->Integral > pid->Output_Limit) pid->Integral = pid->Output_Limit;
	else if (pid->Integral < -pid->Output_Limit) pid->Integral = -pid->Output_Limit;



	// 4. 计算PID输出
	float Output = (pid->Kp * Error)           // 比例项
				+ (pid->Ki * pid->Integral)    // 积分项
				+ (pid->Kd * Angle_Speed);      // 微分项（重点）

	// 5. 输出限幅
	if (Output > pid->Output_Limit) Output = pid->Output_Limit;
	else if (Output < -pid->Output_Limit) Output = -pid->Output_Limit;

	return Output;
}

// 初始化增量式PID参数
void PID_Incremental_Init(PID_Structure_Incremental* pid, 
                          float Kp, float Ki, float Kd, 
                          float DeltaOutput_Limit, float Target_Value) 
{
    pid->Kp = Kp;
    pid->Ki = Ki;
    pid->Kd = Kd;
    pid->DeltaOutput_Limit = DeltaOutput_Limit;
    pid->Target_Value = Target_Value;
    pid->Prev_Error = 0.0f;
    pid->Prev_Error2 = 0.0f;
}

// 增量式PID计算函数（返回控制增量）
float PID_Incremental_Calculate(PID_Structure_Incremental* pid, float Current_Value) 
{
    // 1. 计算当前误差
    float Error = pid->Target_Value - Current_Value;

    // 2. 计算增量式PID三项
    float P = pid->Kp * (Error - pid->Prev_Error);           // 比例项：当前与上次误差差
    float I = pid->Ki * Error;                              // 积分项：当前误差
    float D = pid->Kd * (Error - 2*pid->Prev_Error + pid->Prev_Error2); // 微分项：误差变化率

    // 3. 计算控制增量
    float DeltaOutput = P + I + D;

    // 4. 增量限幅（防止突变）
    if (DeltaOutput > pid->DeltaOutput_Limit) 
        DeltaOutput = pid->DeltaOutput_Limit;
    else if (DeltaOutput < -pid->DeltaOutput_Limit) 
        DeltaOutput = -pid->DeltaOutput_Limit;

    // 5. 更新误差记录
    pid->Prev_Error2 = pid->Prev_Error;
    pid->Prev_Error = Error;

    return DeltaOutput;  // 返回控制增量
}

int16_t Left_Speed_PID_Out;
int16_t Right_Speed_PID_Out;
int16_t Angle_PID_Out=0;



/**状态机参数**/


/**状态机参数**/
int16_t Grey_Current_Line_Data=0;
int16_t Weight_Grey[5]={-65, -38, -0, 38, 65};//0.3-0.5m/s权重
// int16_t Weight_Grey[8]={-99, -73, -10, -0.2, 0.2, 10, 73, 99};//0.7m/s权重
volatile uint8_t Road_Flag=1;//判断一次路口左转,0:左转中，1：直行中,2:直行起步阶段，不判断转弯
volatile uint8_t Road_Flag_Last=1;//判断一次路口左转,0:左转中，1：直行中
volatile uint8_t Stop_Flag=0;//停止标志位，1：停止
volatile int16_t Grey_Speed=26;//灰度循迹速度
volatile uint8_t Weight_sum = 0;//灰度巡线个数
volatile uint8_t sum_cnt =0;
void Calculate_Grey_Data(void)
{
	Grey_Data = 0;
	volatile uint8_t Weight_Tem[5] = {0}, Grey_Num=0;
	Weight_sum = 0;
	for (uint8_t i = 0; i < 5; i++)
	{
		switch(i)
		{
			case 0:
				if(DL_GPIO_readPins(Grey_Sensor_Grey_0_PORT, Grey_Sensor_Grey_0_PIN) > 0)
				{
					Weight_Tem[0] = 1;
					Grey_Data = Grey_Data | (0x01<<i);
				}
				break;
			case 1:
				if(DL_GPIO_readPins(Grey_Sensor_Grey_1_PORT, Grey_Sensor_Grey_1_PIN) > 0)
				{
					Weight_Tem[1] = 1;
					Grey_Data = Grey_Data | (0x01<<i);
				}
				break;
			case 2:
				if(DL_GPIO_readPins(Grey_Sensor_Grey_2_PORT, Grey_Sensor_Grey_2_PIN) > 0)
				{
					Weight_Tem[2] = 1;
					Grey_Data = Grey_Data | (0x01<<i);
				}
				break;
			case 3:
				if(DL_GPIO_readPins(Grey_Sensor_Grey_3_PORT, Grey_Sensor_Grey_3_PIN) > 0)
				{
					Weight_Tem[3] = 1;
					Grey_Data = Grey_Data | (0x01<<i);
				}
				break;
			case 4:
				if(DL_GPIO_readPins(Grey_Sensor_Grey_4_PORT, Grey_Sensor_Grey_4_PIN) > 0)
				{
					Weight_Tem[4] = 1;
					Grey_Data = Grey_Data | (0x01<<i);
				}
				break;
		}
	}
	for (uint8_t i = 0 ;i <5;i++)
	{
		if(Weight_Tem[i] == 1)
		{
			Weight_sum +=1; 
		}
		if(Weight_sum ==0)
		{Grey_Speed = 26;
		Grey_Current_Line_Data = 0;}
	}
	if(Road_Flag == 1)
	{
		Grey_Speed = 26;
		for (uint8_t i = 3; i < 5; i++)
		{
			if(Weight_Tem[i] == 1)
			{
				Grey_Current_Line_Data = Weight_Grey[i];
			}
		}
		for (int8_t i = 2; i >= 0; i--)
		{
			if(Weight_Tem[i] == 1)
			{
				Grey_Current_Line_Data = Weight_Grey[i];
			}
		}
	}
	
}

int32_t Grey_Black_Line_PID_Out=0;
int32_t Distance_PID_Out=0;
 /**灰度循迹串级PID **/
void Execute_PID_INTimer_Grey_Black(void)
{

	Calculate_Grey_Data();//处理灰度传感器数据
 	Grey_BlackLine_Pid.Target_Value = 0;//设置循迹PID目标值
//	Distance_Structure.Target_Value = 0;//设定距离值
	//  Speed_Left_Pid.Kp = Uart_KP;
	//  Speed_Left_Pid.Ki = Uart_KI;
	// Speed_Left_Pid.Kd = -Uart_KD;
	

	Grey_Black_Line_PID_Out = PID_Calculate(&Grey_BlackLine_Pid, Grey_Current_Line_Data);//灰度循迹PID,外环
	if (Grey_Black_Line_PID_Out > Grey_Speed - 1)
    Grey_Black_Line_PID_Out = Grey_Speed - 1;
if (Grey_Black_Line_PID_Out < -(Grey_Speed - 1))
    Grey_Black_Line_PID_Out = -(Grey_Speed - 1);
	// Grey_Black_Line_PID_Out = (int32_t)FuzzyPID_Compute(&FZ_Grey_BlackLine_Pid, 0, (float)Grey_Current_Line_Data);
	// sprintf(Str_Data, "%f, %f, %f, %f\n", FZ_Grey_BlackLine_Pid.Kp, FZ_Grey_BlackLine_Pid.Ki, FZ_Grey_BlackLine_Pid.Kd, Uart_Target);
	// uart0_send_string(UART_0_TEST_INST , Str_Data);
	Speed_Left_Pid.Target_Value = Grey_Speed - Grey_Black_Line_PID_Out ;//读取串口发的速度，速度一般0.5m/s，1m/s
	Speed_Right_Pid.Target_Value = Grey_Speed + Grey_Black_Line_PID_Out ;//读取串口发的速度，速度一般0.5m/s，1m/s

 	Left_Speed_PID_Out = (int32_t)PID_Calculate(&Speed_Left_Pid, EncoderCnt_L);//计算左轮速度环PID
 	Right_Speed_PID_Out = (int32_t)PID_Calculate(&Speed_Right_Pid, EncoderCnt_R);//计算右轮速度环PI
	PWM_Output(MOTOR_LEFT, Left_Speed_PID_Out);//PWM作用到电机
	PWM_Output(MOTOR_RIGHT, Right_Speed_PID_Out);//PWM作用到电机

}

int16_t NO_Speed_Turn_TarhetAngle=0;

int16_t Get_Angle_Turn_90(void)
{
	if(bno08x_data.yaw > 90)
	{
		return (bno08x_data.yaw - 270);
	}
	else 
	{
		return bno08x_data.yaw + 90;
	}
	
}
 /**固定角度转动PID **/
int32_t NO_Speed_Turn_PID_Value_Out=0;//外环输出
int32_t NO_Speed_Turn_PID_Value_In=0;//内环输出
void NO_Speed_Turn_PID(void)
{
//	 NO_Speed_Turn_Pid_Out.Kp = Uart_KP;
//	 NO_Speed_Turn_Pid_Out.Ki = Uart_KI;
//	 NO_Speed_Turn_Pid_Out.Kd = -Uart_KD;

	NO_Speed_Turn_Pid_Out.Target_Value = NO_Speed_Turn_TarhetAngle;
	
	// NO_Speed_Turn_Pid_In.Kp = -Uart_KP;
	// NO_Speed_Turn_Pid_In.Ki = -Uart_KI;
	// NO_Speed_Turn_Pid_In.Kd = Uart_KD;
	
	

	NO_Speed_Turn_PID_Value_Out = (int32_t)PID_Calculate_No_Speed(&NO_Speed_Turn_Pid_Out, bno08x_data.yaw, bno08x_data.az);//灰度循迹PID,外环
	NO_Speed_Turn_Pid_In.Target_Value = NO_Speed_Turn_PID_Value_Out;
	NO_Speed_Turn_PID_Value_In = (int32_t)PID_Calculate(&NO_Speed_Turn_Pid_In, bno08x_data.az);//灰度循迹PID,内环

	PWM_Output(MOTOR_LEFT, NO_Speed_Turn_PID_Value_In);//PWM作用到电机
	PWM_Output(MOTOR_RIGHT, -NO_Speed_Turn_PID_Value_In);//PWM作用到电机
}


uint16_t PID_Tartget_X=270;
uint16_t PID_Tartget_Y=110;
// uint16_t PID_Tartget_X_3=265;//第三问目标
// uint16_t PID_Tartget_Y_3=115;
int32_t PID_Target_Tracking_X_Out=0;
int32_t PID_Target_Tracking_Y_Out=0;
volatile uint16_t Red_X = 0;
volatile uint16_t Red_Y = 0;

volatile int16_t x_site,y_site;
void PID_Calculate_Target_Tracking(void)
{
    // 目标像素坐标（根据你的摄像头视野中心调整）
    PID_Structure_Steer_X.Target_Value = 0;   // X 目标
    PID_Structure_Steer_Y.Target_Value = 18;  // Y 目标
// 积分分离：误差大于50像素时清空积分
    if (abs(x_site - 0) > 50) PID_Structure_Steer_X.Integral = 0;
    if (abs(y_site - 18) > 50) PID_Structure_Steer_Y.Integral = 0;
    // 输入当前实际坐标
    float out_x = PID_Calculate(&PID_Structure_Steer_X, x_site);
    float out_y = PID_Calculate(&PID_Structure_Steer_Y, y_site);

    // ===== 限幅：单帧最大移动步数 =====
    const int32_t MAX_STEP_PER_FRAME = 20;   // 可调（10~30）
    if (out_x >  MAX_STEP_PER_FRAME) out_x =  MAX_STEP_PER_FRAME;
    if (out_x < -MAX_STEP_PER_FRAME) out_x = -MAX_STEP_PER_FRAME;
    if (out_y >  MAX_STEP_PER_FRAME) out_y =  MAX_STEP_PER_FRAME;
    if (out_y < -MAX_STEP_PER_FRAME) out_y = -MAX_STEP_PER_FRAME;

    // 传递给主循环
    Steer_dx = (int32_t)out_x;
    Steer_dy = (int32_t)out_y;
    Steer_Go = 1;   // 通知主循环执行一次移动
}

uint16_t Last_Data_X=0;
uint16_t Last_Data_Y=0;
uint8_t Q3_Stop_Flag=0;

uint8_t KI_Clear_Flag=0;
void Clear_KI_ALL(void)//清除所有的PID积分
{
	/**无速度转向环**/
	NO_Speed_Turn_Pid_Out.Integral = 0;
	NO_Speed_Turn_Pid_In.Integral = 0;
	/**无速度转向环**/

	/**速度环**/
	Speed_Left_Pid.Integral = 0;
	Speed_Right_Pid.Integral = 0;

	/**速度环**/
	
	/**灰度循迹PID */
	Grey_BlackLine_Pid.Integral = 0;

}
volatile uint8_t Question_3_Flag=1;//题目圈速
volatile uint8_t Question_Circle_Num=1;//题目圈速
volatile uint8_t Steer_Init_Flag=10;//题目电机初始化标志
volatile uint8_t Question1_Stage=0;//0:循迹，1转弯
volatile uint16_t Question_Cnt=0;//计时
volatile uint16_t Question2_Stop_Flag=0;//计时
volatile uint8_t Question4_Start_Flag=0;//发挥1的小车启动标志
volatile float yaw_last=0;//发挥12的上次偏航角
// volatile float bno08x_data.yaw_Trans=0;//偏航角转为360
volatile uint16_t Stop_cnt=0;//丢线计时

void Yaw_Angle_Straight(float target_yaw)
{
    // 目标角度
    NO_Speed_Turn_Pid_Out.Target_Value = target_yaw;
    
    // 角度环PID（自带角度跨0°修正+陀螺仪角速度微分项）
    float angle_correct = PID_Calculate_No_Speed(&NO_Speed_Turn_Pid_Out, 
                                                 bno08x_data.yaw, 
                                                 bno08x_data.az);

    // 限制最大纠偏量，防止车身抖动、暴走
    if(angle_correct > 35)  angle_correct = 35;
    if(angle_correct < -35) angle_correct = -35;

    // 差速纠偏：同向速度+左右补偿
    Speed_Left_Pid.Target_Value  = Grey_Speed + angle_correct;
    Speed_Right_Pid.Target_Value = Grey_Speed - angle_correct;

    // 速度环计算+电机输出
    Left_Speed_PID_Out  = (int32_t)PID_Calculate(&Speed_Left_Pid, EncoderCnt_L);
    Right_Speed_PID_Out = (int32_t)PID_Calculate(&Speed_Right_Pid, EncoderCnt_R);

    PWM_Output(MOTOR_LEFT,  Left_Speed_PID_Out);
    PWM_Output(MOTOR_RIGHT, Right_Speed_PID_Out);
}

volatile uint8_t flag =0;
volatile uint8_t Distance=0;
volatile uint8_t Distance_3=0; //三题直线距离
volatile uint8_t timer_cnt;//巡线计时
volatile uint8_t timer_cnt_2;//巡线摆头计时
void Car_PID_Calculate(void)
{
	switch(Question_Flag)
	{
		case 1://题目1 
			
			if(Start_Flag == 1)//未停止时
				{
					Calculate_Grey_Data();	
					if(Weight_sum == 0)
					{
					Grey_Speed = 26;
					Yaw_Angle_Straight(0);
					}	
					else if(Weight_sum >=1)
					{
						Motor_Stop();//关闭电机
						if(Question_Cnt == 0)
						{
							Buzzer_Open();
							DL_GPIO_setPins(LED_PORT, LED_PIN_14_PIN);
						}
							Question_Cnt += 1;
					}
					if( Question_Cnt>= 10)
					{
						Question_Cnt = 1;
						DL_GPIO_clearPins(LED_PORT, LED_PIN_14_PIN);
						Buzzer_Close();
					}
				
				}

			break;
		case 2: //题目2
			Calculate_Grey_Data();	
					if(Stop_Flag == 0)
					{
						Yaw_Angle_Straight(0);
						Distance = (Distance_Left + Distance_Right)/2;
						if (Distance >= 85)
						{
							if (Weight_sum == 0)
							{
								sum_cnt =0;
								timer_cnt +=1;
								if ((timer_cnt / 10 % 2) == 1)
								{
									Grey_Speed = 0;
									Yaw_Angle_Straight(-8);
								}
								else if((timer_cnt /10 % 2) == 0)
								{
									Grey_Speed = 0;
									Yaw_Angle_Straight(8);
								}
								if(Weight_sum > 0)
								{
									sum_cnt +=1;
									if (sum_cnt > 5)
									{
										flag = 1;
										timer_cnt = 0;
										
									}
								}

							}
							else if(Weight_sum > 0)
							{
								sum_cnt +=1;
								if (sum_cnt > 5)
								{
									flag = 1;
								}
							}
							if(flag == 1)
							{
								Clear_KI_ALL();
								flag = 0;
								if(Question_Cnt == 0)
									{
										Buzzer_Open();
										DL_GPIO_setPins(LED_PORT, LED_PIN_14_PIN);
									}
								Question_Cnt += 1;
								if(Question_Cnt >= 10)
								{
									Question_Cnt = 1;
									DL_GPIO_clearPins(LED_PORT, LED_PIN_14_PIN);
									Buzzer_Close();					
								}
								Distance = 0;
								Stop_Flag = 1;	
							}															
						}
						
					}	
						
					else if(Stop_Flag == 1)
					{
						Execute_PID_INTimer_Grey_Black();
						if(Weight_sum == 0)
						{
							sum_cnt+=1;
							if(sum_cnt > 20)
							{
								flag = 1;
								if(flag == 1)
								{
									flag = 0;
									
									if(Question_Cnt == 1)
									{
										Buzzer_Open();
										DL_GPIO_setPins(LED_PORT, LED_PIN_14_PIN);
									}
									Question_Cnt += 1;
									if(Question_Cnt >= 10)
									{
										Question_Cnt = 2;
										DL_GPIO_clearPins(LED_PORT, LED_PIN_14_PIN);
										Buzzer_Close();					
									}
									Stop_Flag = 2;
									Distance_Left = 0;
									Distance_Right	= 0;
								}
							}
						}
						else if(Weight_sum > 0)
						{
							sum_cnt =0;
						}
					}
					else if(Stop_Flag == 2)
					{					
							if(bno08x_data.yaw > 0)
							{
								Yaw_Angle_Straight(180);
							}
							else if(bno08x_data.yaw < 0)
							{
								Yaw_Angle_Straight(-180);
							}
							Distance = (Distance_Left + Distance_Right)/2;
							if(Distance >= 80)
							{
								if (Weight_sum == 0)
								{
									sum_cnt =0;
									timer_cnt +=1;
									if ((timer_cnt  % 2) == 1)
									{
										Grey_Speed = 0;
										if(bno08x_data.yaw > 0)
										{
											Yaw_Angle_Straight(170);
										}
										else if(bno08x_data.yaw < 0)
										{
										Yaw_Angle_Straight(-180);
										}
									}
									else if ((timer_cnt  % 2) == 0)
									{
										Grey_Speed = 0;
										if(bno08x_data.yaw > 0)
										{
											Yaw_Angle_Straight(180);
										}
										else if(bno08x_data.yaw < 0)
										{
											Yaw_Angle_Straight(-170);
										}
									}
									if(Weight_sum > 0)
									{
										sum_cnt +=1;
										if (sum_cnt > 5)
										{
											timer_cnt = 0;
											flag = 1;
										}
									}

								}
								else if(Weight_sum > 0)
								{
									sum_cnt +=1;
									if (sum_cnt > 5)
									{
										flag = 1;
									}
								}
							}
							if(flag == 1)
							{
								Clear_KI_ALL();
								flag = 0;
								if(Question_Cnt == 2)
									{
										Buzzer_Open();
										DL_GPIO_setPins(LED_PORT, LED_PIN_14_PIN);
									}
								Question_Cnt += 1;
								if(Question_Cnt >= 10)
								{
									Question_Cnt = 3;
									DL_GPIO_clearPins(LED_PORT, LED_PIN_14_PIN);
									Buzzer_Close();					
								}
								Stop_Flag = 3;	
							}																				
					}	
					else if(Stop_Flag == 3)
					{
							Execute_PID_INTimer_Grey_Black();
							if(Weight_sum == 0)
							{
								sum_cnt+=1;
								if(sum_cnt > 20)
								{
									flag = 1;
									if(flag == 1)
										{
											flag = 0;
										
											if(Question_Cnt == 3)
											{
												Buzzer_Open();
												DL_GPIO_setPins(LED_PORT, LED_PIN_14_PIN);
											}
												Question_Cnt += 1;
											if(Question_Cnt >= 10)
											{
												Question_Cnt = 4;
												DL_GPIO_clearPins(LED_PORT, LED_PIN_14_PIN);
												Buzzer_Close();					
											}
											Stop_Flag = 4;	
										}
									}
								}
								else if(Weight_sum > 0)
								{
									sum_cnt =0;
								}
					}
					else if(Stop_Flag == 4)
					{	
								if(Weight_sum == 0)
								{
									sum_cnt+=1;
									if(sum_cnt > 20)
									{
										flag = 1;
										if(flag == 1)
										{
											flag = 0;
											if(Question_Cnt == 4)
											{
												Buzzer_Open();
												DL_GPIO_setPins(LED_PORT, LED_PIN_14_PIN);
											}
												Question_Cnt += 1;
											if(Question_Cnt >= 10)
											{
												Question_Cnt = 7;
												DL_GPIO_clearPins(LED_PORT, LED_PIN_14_PIN);
												Buzzer_Close();					
											}
										}
									}
								}
								else if(Weight_sum > 0)
								{
									sum_cnt =0;
								}
								Motor_Stop();
					}
				break;
						
		case 3: //题目3
			Calculate_Grey_Data();	
			switch (Stop_Flag)
			{
				case 0:
					
					Yaw_Angle_Straight(53.7);
					Distance = (Distance_Left + Distance_Right)/2;
					if(Distance >= 85)
					{
						Distance_3 = (Distance_Left + Distance_Right)/2 - 85;
						Yaw_Angle_Straight(0);
						if(Distance_3 >= 30)
						{					
							if (Weight_sum == 0)
							{
								sum_cnt =0;
								timer_cnt +=1;
								if ((timer_cnt / 10 % 2) == 1)
								{
									Grey_Speed = 0;
									Yaw_Angle_Straight(-8);
								}
								else if((timer_cnt /10 % 2) == 0)
								{
									Grey_Speed = 0;
									Yaw_Angle_Straight(8);
								}
								if(Weight_sum > 0)
								{
									sum_cnt +=1;
									if (sum_cnt > 5)
									{
										flag = 1;
										timer_cnt = 0;
										
									}
								}

							}
							else if(Weight_sum > 0)
							{
								sum_cnt +=1;
								if (sum_cnt > 5)
								{
									flag = 1;
								}
							}
							if(flag == 1)
							{
								Clear_KI_ALL();
								flag = 0;
								if(Question_Cnt == 0)
									{
										Buzzer_Open();
										DL_GPIO_setPins(LED_PORT, LED_PIN_14_PIN);
									}
								Question_Cnt += 1;
								if(Question_Cnt >= 10)
								{
									Question_Cnt = 1;
									DL_GPIO_clearPins(LED_PORT, LED_PIN_14_PIN);
									Buzzer_Close();					
								}
								Distance = 0;
								Distance_3 = 0;
								Stop_Flag = 1;	
							}
						}
					}
				break;	
				case 1:
						Execute_PID_INTimer_Grey_Black();
							if(Weight_sum == 0)
							{
								sum_cnt+=1;
								if(sum_cnt > 20)
								{
									flag = 1;
									if(flag == 1)
									{	
										flag = 0;							
										if(Question_Cnt == 1)
										{
											Buzzer_Open();
											DL_GPIO_setPins(LED_PORT, LED_PIN_14_PIN);
										}
											Question_Cnt += 1;
										if(Question_Cnt >= 10)
										{
											Question_Cnt = 2;
											DL_GPIO_clearPins(LED_PORT, LED_PIN_14_PIN);
											Buzzer_Close();					
										}
										Stop_Flag = 2;
										Distance = 0;
										Distance_3 = 0;	
									}
								}
							}
							else if(Weight_sum > 0)
							{
								sum_cnt =0;
							}				
						break;
				case 2:
				
				Yaw_Angle_Straight(126.3);
				Distance= (Distance_Left + Distance_Right)/2;
				if(Distance > 85)
				{
					Distance_3 = (Distance_Left + Distance_Right)/2 - 85;
					if(bno08x_data.yaw > 0)
					{
						Yaw_Angle_Straight(180);
					}
					else if(bno08x_data.yaw < 0)
					{
					Yaw_Angle_Straight(-180);
					}
					if(Distance_3 >=30)	
					{
						if (Weight_sum == 0)
								{
									sum_cnt =0;
									timer_cnt +=1;
									if ((timer_cnt  % 2) == 1)
									{
										Grey_Speed = 0;
										if(bno08x_data.yaw > 0)
										{
											Yaw_Angle_Straight(170);
										}
										else if(bno08x_data.yaw < 0)
										{
										Yaw_Angle_Straight(-180);
										}
									}
									else if ((timer_cnt  % 2) == 0)
									{
										Grey_Speed = 0;
										if(bno08x_data.yaw > 0)
										{
											Yaw_Angle_Straight(180);
										}
										else if(bno08x_data.yaw < 0)
										{
											Yaw_Angle_Straight(-170);
										}
									}
									if(Weight_sum > 0)
									{
										sum_cnt +=1;
										if (sum_cnt > 20)
										{
											timer_cnt = 0;
											flag = 1;
										}
									}
									else if(Weight_sum == 0)
									{
										sum_cnt =0;
									}

								}
								else if(Weight_sum > 0)
								{
									sum_cnt +=1;
									if (sum_cnt > 20)
									{
										flag = 1;
									}
								}
							}
							if(flag == 1)
							{
								Clear_KI_ALL();
								flag = 0;
								if(Question_Cnt == 2)
									{
										Buzzer_Open();
										DL_GPIO_setPins(LED_PORT, LED_PIN_14_PIN);
									}
								Question_Cnt += 1;
								if(Question_Cnt >= 10)
								{
									Question_Cnt = 3;
									DL_GPIO_clearPins(LED_PORT, LED_PIN_14_PIN);
									Buzzer_Close();					
								}
								Stop_Flag = 3;
								Distance = 0;
								Distance_3 = 0;
						}	
					}				
				
					break;
				case 3:
					Execute_PID_INTimer_Grey_Black();
					if(Weight_sum == 0)
					{
						sum_cnt+=1;
						if(sum_cnt > 20)
						{
							flag = 1;
							if(flag == 1)
							{
								flag = 0;			
								if(Question_Cnt == 3)
								{
									Buzzer_Open();
									DL_GPIO_setPins(LED_PORT, LED_PIN_14_PIN);
								}
								Question_Cnt += 1;
								if(Question_Cnt >= 10)
								{
									Question_Cnt = 4;
									DL_GPIO_clearPins(LED_PORT, LED_PIN_14_PIN);
									Buzzer_Close();					
								}
								Stop_Flag = 4;	
								}
							}								
						}
						else if(Weight_sum > 0)
						{
							sum_cnt =0;
						}
						break;
				case 4:
					Calculate_Grey_Data();
					if(Weight_sum == 0)
					{
						sum_cnt+=1;
						if(sum_cnt > 20)
						{
							flag = 1;
							if(flag == 1)
							{
								flag = 0;		
								if(Question_Cnt == 4)
								{
									Buzzer_Open();
									DL_GPIO_setPins(LED_PORT, LED_PIN_14_PIN);
								}
								Question_Cnt += 1;
								if(Question_Cnt >= 10)
								{
									Question_Cnt = 5;
									DL_GPIO_clearPins(LED_PORT, LED_PIN_14_PIN);
									Buzzer_Close();					
								}
							}
						}
					}
					else if(Weight_sum > 0)
					{
						sum_cnt =0;
					}
					Motor_Stop();
					break;
			
				default:
					break;
			}	
			break;
		case 4: //题目4
		switch (Question_Circle_Num)
		{
		case 1:
			Calculate_Grey_Data();	
			switch (Stop_Flag)
			{
				case 0:
					
					Yaw_Angle_Straight(53.7);
					Distance = (Distance_Left + Distance_Right)/2;
					if(Distance >= 85)
					{
						Distance_3 = (Distance_Left + Distance_Right)/2 - 85;
						Yaw_Angle_Straight(0);
						if(Distance_3 >= 30)
						{					
							if (Weight_sum == 0)
							{
								sum_cnt =0;
								timer_cnt +=1;
								if ((timer_cnt / 10 % 2) == 1)
								{
									Grey_Speed = 0;
									Yaw_Angle_Straight(-8);
								}
								else if((timer_cnt /10 % 2) == 0)
								{
									Grey_Speed = 0;
									Yaw_Angle_Straight(8);
								}
								if(Weight_sum > 0)
								{
									sum_cnt +=1;
									if (sum_cnt > 5)
									{
										flag = 1;
										timer_cnt = 0;
										
									}
								}

							}
							else if(Weight_sum > 0)
							{
								sum_cnt +=1;
								if (sum_cnt > 5)
								{
									flag = 1;
								}
							}
							if(flag == 1)
							{
								Clear_KI_ALL();
								flag = 0;
								if(Question_Cnt == 0)
									{
										Buzzer_Open();
										DL_GPIO_setPins(LED_PORT, LED_PIN_14_PIN);
									}
								Question_Cnt += 1;
								if(Question_Cnt >= 10)
								{
									Question_Cnt = 1;
									DL_GPIO_clearPins(LED_PORT, LED_PIN_14_PIN);
									Buzzer_Close();					
								}
								Distance = 0;
								Distance_3 = 0;
								Stop_Flag = 1;	
							}
						}
					}
				break;	
				case 1:
						Execute_PID_INTimer_Grey_Black();
							if(Weight_sum == 0)
							{
								sum_cnt+=1;
								if(sum_cnt > 20)
								{
									flag = 1;
									if(flag == 1)
									{	
										flag = 0;							
										if(Question_Cnt == 1)
										{
											Buzzer_Open();
											DL_GPIO_setPins(LED_PORT, LED_PIN_14_PIN);
										}
											Question_Cnt += 1;
										if(Question_Cnt >= 10)
										{
											Question_Cnt = 2;
											DL_GPIO_clearPins(LED_PORT, LED_PIN_14_PIN);
											Buzzer_Close();					
										}
										Stop_Flag = 2;
										Distance = 0;
										Distance_3 = 0;	
									}
								}
							}
							else if(Weight_sum > 0)
							{
								sum_cnt =0;
							}				
						break;
				case 2:
				
				Yaw_Angle_Straight(126.3);
				Distance= (Distance_Left + Distance_Right)/2;
				if(Distance > 83)
				{
					Distance_3 = (Distance_Left + Distance_Right)/2 - 83;
					if(bno08x_data.yaw > 0)
					{
						Yaw_Angle_Straight(180);
					}
					else if(bno08x_data.yaw < 0)
					{
					Yaw_Angle_Straight(-180);
					}
					if(Distance_3 >=30)	
					{
						if (Weight_sum == 0)
								{
									sum_cnt =0;
									timer_cnt +=1;
									if ((timer_cnt  % 2) == 1)
									{
										Grey_Speed = 0;
										if(bno08x_data.yaw > 0)
										{
											Yaw_Angle_Straight(170);
										}
										else if(bno08x_data.yaw < 0)
										{
										Yaw_Angle_Straight(-180);
										}
									}
									else if ((timer_cnt  % 2) == 0)
									{
										Grey_Speed = 0;
										if(bno08x_data.yaw > 0)
										{
											Yaw_Angle_Straight(180);
										}
										else if(bno08x_data.yaw < 0)
										{
											Yaw_Angle_Straight(-170);
										}
									}
									if(Weight_sum > 0)
									{
										sum_cnt +=1;
										if (sum_cnt > 5)
										{
											timer_cnt = 0;
											flag = 1;
										}
									}

								}
								else if(Weight_sum > 0)
								{
									sum_cnt +=1;
									if (sum_cnt > 5)
									{
										flag = 1;
									}
								}
							}
							if(flag == 1)
							{
								Clear_KI_ALL();
								flag = 0;
								if(Question_Cnt == 2)
									{
										Buzzer_Open();
										DL_GPIO_setPins(LED_PORT, LED_PIN_14_PIN);
									}
								Question_Cnt += 1;
								if(Question_Cnt >= 10)
								{
									Question_Cnt = 3;
									DL_GPIO_clearPins(LED_PORT, LED_PIN_14_PIN);
									Buzzer_Close();					
								}
								Stop_Flag = 3;
								Distance = 0;
								Distance_3 = 0;
						}	
					}				
				
					break;
				case 3:
					Execute_PID_INTimer_Grey_Black();
					if(Weight_sum == 0)
					{
						sum_cnt+=1;
						if(sum_cnt > 20)
						{
							flag = 1;
							if(flag == 1)
							{
								flag = 0;			
								if(Question_Cnt == 3)
								{
									Buzzer_Open();
									DL_GPIO_setPins(LED_PORT, LED_PIN_14_PIN);
								}
								Question_Cnt += 1;
								if(Question_Cnt >= 10)
								{
									Question_Cnt = 4;
									DL_GPIO_clearPins(LED_PORT, LED_PIN_14_PIN);
									Buzzer_Close();					
								}
								Stop_Flag = 4;	
								}
							}								
						}
						else if(Weight_sum > 0)
						{
							sum_cnt =0;
						}
						break;
				case 4:
					Calculate_Grey_Data();
					if(Weight_sum == 0)
					{
						sum_cnt+=1;
						if(sum_cnt > 20)
						{
							flag = 1;
							if(flag == 1)
							{
								flag = 0;		
								if(Question_Cnt == 4)
								{
									Buzzer_Open();
									DL_GPIO_setPins(LED_PORT, LED_PIN_14_PIN);
								}
								Question_Cnt += 1;
								if(Question_Cnt >= 10)
								{
									Question_Cnt = 5;
									DL_GPIO_clearPins(LED_PORT, LED_PIN_14_PIN);
									Buzzer_Close();					
								}
							}
						}
					}
					else if(Weight_sum > 0)
					{
						sum_cnt =0;
					}
					Question_Circle_Num = 2;
					Stop_Flag = 0;
					Distance = 0;
					Distance_3 = 0;
					Question_Cnt = 0;
					break;
				}
				break;
			case 2:
					Calculate_Grey_Data();	
			switch (Stop_Flag)
			{
				case 0:
					
					Yaw_Angle_Straight(53.7);
					Distance = (Distance_Left + Distance_Right)/2;
					if(Distance >= 80)
					{
						Distance_3 = (Distance_Left + Distance_Right)/2 - 80;
						Yaw_Angle_Straight(0);
						if(Distance_3 >= 30)
						{					
							if (Weight_sum == 0)
							{
								sum_cnt =0;
								timer_cnt +=1;
								if ((timer_cnt / 10 % 2) == 1)
								{
									Grey_Speed = 0;
									Yaw_Angle_Straight(-8);
								}
								else if((timer_cnt /10 % 2) == 0)
								{
									Grey_Speed = 0;
									Yaw_Angle_Straight(8);
								}
								if(Weight_sum > 0)
								{
									sum_cnt +=1;
									if (sum_cnt > 5)
									{
										flag = 1;
										timer_cnt = 0;
										
									}
								}

							}
							else if(Weight_sum > 0)
							{
								sum_cnt +=1;
								if (sum_cnt > 5)
								{
									flag = 1;
								}
							}
							if(flag == 1)
							{
								Clear_KI_ALL();
								flag = 0;
								if(Question_Cnt == 0)
									{
										Buzzer_Open();
										DL_GPIO_setPins(LED_PORT, LED_PIN_14_PIN);
									}
								Question_Cnt += 1;
								if(Question_Cnt >= 10)
								{
									Question_Cnt = 1;
									DL_GPIO_clearPins(LED_PORT, LED_PIN_14_PIN);
									Buzzer_Close();					
								}
								Distance = 0;
								Distance_3 = 0;
								Stop_Flag = 1;	
							}
						}
					}
				break;	
				case 1:
						Execute_PID_INTimer_Grey_Black();
							if(Weight_sum == 0)
							{
								sum_cnt+=1;
								if(sum_cnt > 20)
								{
									flag = 1;
									if(flag == 1)
									{	
										flag = 0;							
										if(Question_Cnt == 1)
										{
											Buzzer_Open();
											DL_GPIO_setPins(LED_PORT, LED_PIN_14_PIN);
										}
											Question_Cnt += 1;
										if(Question_Cnt >= 10)
										{
											Question_Cnt = 2;
											DL_GPIO_clearPins(LED_PORT, LED_PIN_14_PIN);
											Buzzer_Close();					
										}
										Stop_Flag = 2;
										Distance = 0;
										Distance_3 = 0;	
									}
								}
							}
							else if(Weight_sum > 0)
							{
								sum_cnt =0;
							}				
						break;
				case 2:
				
				Yaw_Angle_Straight(126.3);
				Distance= (Distance_Left + Distance_Right)/2;
				if(Distance > 85)
				{
					Distance_3 = (Distance_Left + Distance_Right)/2 - 85;
					if(bno08x_data.yaw > 0)
					{
						Yaw_Angle_Straight(180);
					}
					else if(bno08x_data.yaw < 0)
					{
					Yaw_Angle_Straight(-180);
					}
					if(Distance_3 >=30)	
					{
						if (Weight_sum == 0)
								{
									sum_cnt =0;
									timer_cnt +=1;
									if ((timer_cnt  % 2) == 1)
									{
										Grey_Speed = 0;
										if(bno08x_data.yaw > 0)
										{
											Yaw_Angle_Straight(170);
										}
										else if(bno08x_data.yaw < 0)
										{
										Yaw_Angle_Straight(-180);
										}
									}
									else if ((timer_cnt  % 2) == 0)
									{
										Grey_Speed = 0;
										if(bno08x_data.yaw > 0)
										{
											Yaw_Angle_Straight(180);
										}
										else if(bno08x_data.yaw < 0)
										{
											Yaw_Angle_Straight(-170);
										}
									}
									if(Weight_sum > 0)
									{
										sum_cnt +=1;
										if (sum_cnt > 5)
										{
											timer_cnt = 0;
											flag = 1;
										}
									}

								}
								else if(Weight_sum > 0)
								{
									sum_cnt +=1;
									if (sum_cnt > 5)
									{
										flag = 1;
									}
								}
							}
							if(flag == 1)
							{
								Clear_KI_ALL();
								flag = 0;
								if(Question_Cnt == 2)
									{
										Buzzer_Open();
										DL_GPIO_setPins(LED_PORT, LED_PIN_14_PIN);
									}
								Question_Cnt += 1;
								if(Question_Cnt >= 10)
								{
									Question_Cnt = 3;
									DL_GPIO_clearPins(LED_PORT, LED_PIN_14_PIN);
									Buzzer_Close();					
								}
								Stop_Flag = 3;
								Distance = 0;
								Distance_3 = 0;
						}	
					}				
				
					break;
				case 3:
					Execute_PID_INTimer_Grey_Black();
					if(Weight_sum == 0)
					{
						sum_cnt+=1;
						if(sum_cnt > 20)
						{
							flag = 1;
							if(flag == 1)
							{
								flag = 0;			
								if(Question_Cnt == 3)
								{
									Buzzer_Open();
									DL_GPIO_setPins(LED_PORT, LED_PIN_14_PIN);
								}
								Question_Cnt += 1;
								if(Question_Cnt >= 10)
								{
									Question_Cnt = 4;
									DL_GPIO_clearPins(LED_PORT, LED_PIN_14_PIN);
									Buzzer_Close();					
								}
								Stop_Flag = 4;	
								}
							}								
						}
						else if(Weight_sum > 0)
						{
							sum_cnt =0;
						}
						break;
				case 4:
					Calculate_Grey_Data();
					if(Weight_sum == 0)
					{
						sum_cnt+=1;
						if(sum_cnt > 20)
						{
							flag = 1;
							if(flag == 1)
							{
								flag = 0;		
								if(Question_Cnt == 4)
								{
									Buzzer_Open();
									DL_GPIO_setPins(LED_PORT, LED_PIN_14_PIN);
								}
								Question_Cnt += 1;
								if(Question_Cnt >= 10)
								{
									Question_Cnt = 5;
									DL_GPIO_clearPins(LED_PORT, LED_PIN_14_PIN);
									Buzzer_Close();					
								}
							}
						}
					}
					else if(Weight_sum > 0)
					{
						sum_cnt =0;
					}
					Question_Circle_Num = 3;
					Stop_Flag = 0;
					Distance = 0;
					Distance_3 = 0;
					Question_Cnt = 0;
					break;
				}
			break;
			case 3:
					Calculate_Grey_Data();	
			switch (Stop_Flag)
			{
				case 0:
					
					Yaw_Angle_Straight(53.7);
					Distance = (Distance_Left + Distance_Right)/2;
					if(Distance >= 80)
					{
						Distance_3 = (Distance_Left + Distance_Right)/2 - 80;
						Yaw_Angle_Straight(0);
						if(Distance_3 >= 30)
						{					
							if (Weight_sum == 0)
							{
								sum_cnt =0;
								timer_cnt +=1;
								if ((timer_cnt / 10 % 2) == 1)
								{
									Grey_Speed = 0;
									Yaw_Angle_Straight(-8);
								}
								else if((timer_cnt /10 % 2) == 0)
								{
									Grey_Speed = 0;
									Yaw_Angle_Straight(8);
								}
								if(Weight_sum > 0)
								{
									sum_cnt +=1;
									if (sum_cnt > 5)
									{
										flag = 1;
										timer_cnt = 0;
										
									}
								}

							}
							else if(Weight_sum > 0)
							{
								sum_cnt +=1;
								if (sum_cnt > 5)
								{
									flag = 1;
								}
							}
							if(flag == 1)
							{
								Clear_KI_ALL();
								flag = 0;
								if(Question_Cnt == 0)
									{
										Buzzer_Open();
										DL_GPIO_setPins(LED_PORT, LED_PIN_14_PIN);
									}
								Question_Cnt += 1;
								if(Question_Cnt >= 10)
								{
									Question_Cnt = 1;
									DL_GPIO_clearPins(LED_PORT, LED_PIN_14_PIN);
									Buzzer_Close();					
								}
								Distance = 0;
								Distance_3 = 0;
								Stop_Flag = 1;	
							}
						}
					}
				break;	
				case 1:
						Execute_PID_INTimer_Grey_Black();
							if(Weight_sum == 0)
							{
								sum_cnt+=1;
								if(sum_cnt > 20)
								{
									flag = 1;
									if(flag == 1)
									{	
										flag = 0;							
										if(Question_Cnt == 1)
										{
											Buzzer_Open();
											DL_GPIO_setPins(LED_PORT, LED_PIN_14_PIN);
										}
											Question_Cnt += 1;
										if(Question_Cnt >= 10)
										{
											Question_Cnt = 2;
											DL_GPIO_clearPins(LED_PORT, LED_PIN_14_PIN);
											Buzzer_Close();					
										}
										Stop_Flag = 2;
										Distance = 0;
										Distance_3 = 0;	
									}
								}
							}
							else if(Weight_sum > 0)
							{
								sum_cnt =0;
							}				
						break;
				case 2:
				
				Yaw_Angle_Straight(126.3);
				Distance= (Distance_Left + Distance_Right)/2;
				if(Distance > 85)
				{
					Distance_3 = (Distance_Left + Distance_Right)/2 - 85;
					if(bno08x_data.yaw > 0)
					{
						Yaw_Angle_Straight(180);
					}
					else if(bno08x_data.yaw < 0)
					{
					Yaw_Angle_Straight(-180);
					}
					if(Distance_3 >=30)	
					{
						if (Weight_sum == 0)
								{
									sum_cnt =0;
									timer_cnt +=1;
									if ((timer_cnt  % 2) == 1)
									{
										Grey_Speed = 0;
										if(bno08x_data.yaw > 0)
										{
											Yaw_Angle_Straight(170);
										}
										else if(bno08x_data.yaw < 0)
										{
										Yaw_Angle_Straight(-180);
										}
									}
									else if ((timer_cnt  % 2) == 0)
									{
										Grey_Speed = 0;
										if(bno08x_data.yaw > 0)
										{
											Yaw_Angle_Straight(180);
										}
										else if(bno08x_data.yaw < 0)
										{
											Yaw_Angle_Straight(-170);
										}
									}
									if(Weight_sum > 0)
									{
										sum_cnt +=1;
										if (sum_cnt > 5)
										{
											timer_cnt = 0;
											flag = 1;
										}
									}

								}
								else if(Weight_sum > 0)
								{
									sum_cnt +=1;
									if (sum_cnt > 5)
									{
										flag = 1;
									}
								}
							}
							if(flag == 1)
							{
								Clear_KI_ALL();
								flag = 0;
								if(Question_Cnt == 2)
									{
										Buzzer_Open();
										DL_GPIO_setPins(LED_PORT, LED_PIN_14_PIN);
									}
								Question_Cnt += 1;
								if(Question_Cnt >= 10)
								{
									Question_Cnt = 3;
									DL_GPIO_clearPins(LED_PORT, LED_PIN_14_PIN);
									Buzzer_Close();					
								}
								Stop_Flag = 3;
								Distance = 0;
								Distance_3 = 0;
						}	
					}				
				
					break;
				case 3:
					Execute_PID_INTimer_Grey_Black();
					if(Weight_sum == 0)
					{
						sum_cnt+=1;
						if(sum_cnt > 20)
						{
							flag = 1;
							if(flag == 1)
							{
								flag = 0;			
								if(Question_Cnt == 3)
								{
									Buzzer_Open();
									DL_GPIO_setPins(LED_PORT, LED_PIN_14_PIN);
								}
								Question_Cnt += 1;
								if(Question_Cnt >= 10)
								{
									Question_Cnt = 4;
									DL_GPIO_clearPins(LED_PORT, LED_PIN_14_PIN);
									Buzzer_Close();					
								}
								Stop_Flag = 4;	
								}
							}								
						}
						else if(Weight_sum > 0)
						{
							sum_cnt =0;
						}
						break;
				case 4:
					Calculate_Grey_Data();
					if(Weight_sum == 0)
					{
						sum_cnt+=1;
						if(sum_cnt > 20)
						{
							flag = 1;
							if(flag == 1)
							{
								flag = 0;		
								if(Question_Cnt == 4)
								{
									Buzzer_Open();
									DL_GPIO_setPins(LED_PORT, LED_PIN_14_PIN);
								}
								Question_Cnt += 1;
								if(Question_Cnt >= 10)
								{
									Question_Cnt = 5;
									DL_GPIO_clearPins(LED_PORT, LED_PIN_14_PIN);
									Buzzer_Close();					
								}
							}
						}
					}
					else if(Weight_sum > 0)
					{
						sum_cnt =0;
					}
					Question_Circle_Num = 4;
					Stop_Flag = 0;
					Distance = 0;
					Distance_3 = 0;
					Question_Cnt = 0;
					break;
				}
			break;
			case 4:
				Calculate_Grey_Data();	
			switch (Stop_Flag)
			{
				case 0:
					
					Yaw_Angle_Straight(53.7);
					Distance = (Distance_Left + Distance_Right)/2;
					if(Distance >= 80)
					{
						Distance_3 = (Distance_Left + Distance_Right)/2 - 80;
						Yaw_Angle_Straight(0);
						if(Distance_3 >= 30)
						{					
							if (Weight_sum == 0)
							{
								sum_cnt =0;
								timer_cnt +=1;
								if ((timer_cnt / 10 % 2) == 1)
								{
									Grey_Speed = 0;
									Yaw_Angle_Straight(-8);
								}
								else if((timer_cnt /10 % 2) == 0)
								{
									Grey_Speed = 0;
									Yaw_Angle_Straight(8);
								}
								if(Weight_sum > 0)
								{
									sum_cnt +=1;
									if (sum_cnt > 5)
									{
										flag = 1;
										timer_cnt = 0;
										
									}
								}

							}
							else if(Weight_sum > 0)
							{
								sum_cnt +=1;
								if (sum_cnt > 5)
								{
									flag = 1;
								}
							}
							if(flag == 1)
							{
								Clear_KI_ALL();
								flag = 0;
								if(Question_Cnt == 0)
									{
										Buzzer_Open();
										DL_GPIO_setPins(LED_PORT, LED_PIN_14_PIN);
									}
								Question_Cnt += 1;
								if(Question_Cnt >= 10)
								{
									Question_Cnt = 1;
									DL_GPIO_clearPins(LED_PORT, LED_PIN_14_PIN);
									Buzzer_Close();					
								}
								Distance = 0;
								Distance_3 = 0;
								Stop_Flag = 1;	
							}
						}
					}
				break;	
				case 1:
						Execute_PID_INTimer_Grey_Black();
							if(Weight_sum == 0)
							{
								sum_cnt+=1;
								if(sum_cnt > 20)
								{
									flag = 1;
									if(flag == 1)
									{	
										flag = 0;							
										if(Question_Cnt == 1)
										{
											Buzzer_Open();
											DL_GPIO_setPins(LED_PORT, LED_PIN_14_PIN);
										}
											Question_Cnt += 1;
										if(Question_Cnt >= 10)
										{
											Question_Cnt = 2;
											DL_GPIO_clearPins(LED_PORT, LED_PIN_14_PIN);
											Buzzer_Close();					
										}
										Stop_Flag = 2;
										Distance = 0;
										Distance_3 = 0;	
									}
								}
							}
							else if(Weight_sum > 0)
							{
								sum_cnt =0;
							}				
						break;
				case 2:
				
				Yaw_Angle_Straight(126.3);
				Distance= (Distance_Left + Distance_Right)/2;
				if(Distance > 85)
				{
					Distance_3 = (Distance_Left + Distance_Right)/2 - 85;
					if(bno08x_data.yaw > 0)
					{
						Yaw_Angle_Straight(180);
					}
					else if(bno08x_data.yaw < 0)
					{
					Yaw_Angle_Straight(-180);
					}
					if(Distance_3 >=30)	
					{
						if (Weight_sum == 0)
								{
									sum_cnt =0;
									timer_cnt +=1;
									if ((timer_cnt  % 2) == 1)
									{
										Grey_Speed = 0;
										if(bno08x_data.yaw > 0)
										{
											Yaw_Angle_Straight(170);
										}
										else if(bno08x_data.yaw < 0)
										{
										Yaw_Angle_Straight(-180);
										}
									}
									else if ((timer_cnt  % 2) == 0)
									{
										Grey_Speed = 0;
										if(bno08x_data.yaw > 0)
										{
											Yaw_Angle_Straight(180);
										}
										else if(bno08x_data.yaw < 0)
										{
											Yaw_Angle_Straight(-170);
										}
									}
									if(Weight_sum > 0)
									{
										sum_cnt +=1;
										if (sum_cnt > 5)
										{
											timer_cnt = 0;
											flag = 1;
										}
									}

								}
								else if(Weight_sum > 0)
								{
									sum_cnt +=1;
									if (sum_cnt > 5)
									{
										flag = 1;
									}
								}
							}
							if(flag == 1)
							{
								Clear_KI_ALL();
								flag = 0;
								if(Question_Cnt == 2)
									{
										Buzzer_Open();
										DL_GPIO_setPins(LED_PORT, LED_PIN_14_PIN);
									}
								Question_Cnt += 1;
								if(Question_Cnt >= 10)
								{
									Question_Cnt = 3;
									DL_GPIO_clearPins(LED_PORT, LED_PIN_14_PIN);
									Buzzer_Close();					
								}
								Stop_Flag = 3;
								Distance = 0;
								Distance_3 = 0;
						}	
					}				
				
					break;
				case 3:
					Execute_PID_INTimer_Grey_Black();
					if(Weight_sum == 0)
					{
						sum_cnt+=1;
						if(sum_cnt > 20)
						{
							flag = 1;
							if(flag == 1)
							{
								flag = 0;			
								if(Question_Cnt == 3)
								{
									Buzzer_Open();
									DL_GPIO_setPins(LED_PORT, LED_PIN_14_PIN);
								}
								Question_Cnt += 1;
								if(Question_Cnt >= 10)
								{
									Question_Cnt = 4;
									DL_GPIO_clearPins(LED_PORT, LED_PIN_14_PIN);
									Buzzer_Close();					
								}
								Stop_Flag = 4;	
								}
							}								
						}
						else if(Weight_sum > 0)
						{
							sum_cnt =0;
						}
						break;
				case 4:
					Calculate_Grey_Data();
					if(Weight_sum == 0)
					{
						sum_cnt+=1;
						if(sum_cnt > 20)
						{
							flag = 1;
							if(flag == 1)
							{
								flag = 0;		
								if(Question_Cnt == 4)
								{
									Buzzer_Open();
									DL_GPIO_setPins(LED_PORT, LED_PIN_14_PIN);
								}
								Question_Cnt += 1;
								if(Question_Cnt >= 10)
								{
									Question_Cnt = 5;
									DL_GPIO_clearPins(LED_PORT, LED_PIN_14_PIN);
									Buzzer_Close();					
								}
							}
						}
					}
					else if(Weight_sum > 0)
					{
						sum_cnt =0;
					}
					Motor_Stop();
					Question_Circle_Num = 2;
					Stop_Flag = 0;
					Distance = 0;
					Distance_3 = 0;
					Question_Cnt = 0;
					break;
			break;
				default:
					break;
			}	
			
			break;
			break;
		
		default:
			break;
		}
			
		default:
			break;
	}

}