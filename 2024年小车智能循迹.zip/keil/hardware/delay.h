#ifndef __DELAY_H__
#define __DELAY_H__

#include "ti_msp_dl_config.h"

void Delay_ms(unsigned int ms);

void Delay_us( uint32_t us);

//软件的微秒延时,不精准
void delay_us(uint32_t us);
//软件的毫秒延时,不精准
void delay_ms(uint32_t ms);

#endif
