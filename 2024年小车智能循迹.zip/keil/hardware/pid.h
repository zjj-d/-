#ifndef __PID_H__
#define __PID_H__

#include "ti_msp_dl_config.h"
extern volatile uint8_t Car_Phase_Flag;//小车行驶阶段标志
typedef struct
{
	float Kp;
	float Ki;
	float Kd;
	float Target_Value; // 目标值
    float Prev_Error;   // 上一次误差
    float Integral;     // 积分累积值
    float Output_Limit; // 输出限幅值

}PID_Structure;
// 增量式PID结构体（新增误差历史记录）
typedef struct {
    float Kp;
    float Ki;
    float Kd;
    float Target_Value;     // 目标值
    float Prev_Error;       // 上一次误差 e(k-1)
    float Prev_Error2;      // 上上次误差 e(k-2)
    float DeltaOutput_Limit; // 增量输出限幅
} PID_Structure_Incremental;

extern volatile uint8_t Question_Flag;//题目标志位
extern volatile uint8_t Question_Circle_Num;//题目圈速


extern PID_Structure Speed_Left_Pid;//左轮PID初始化,0.5m/s的PID
extern PID_Structure Speed_Right_Pid;//右轮PID初始化,0.5m/s的PID;

extern volatile uint16_t Red_X;
extern volatile uint16_t Red_Y;

extern PID_Structure Angle_Pid;//角度环PID，速度0.5m/s

void Calculate_Grey_Data(void);
void Execute_PID_INTimer_Grey_Black(void);
void Clear_KI_ALL(void);//清除所有的PID积分


void PID_Init(PID_Structure* pid, float Kp, float Ki, float Kd, float Output_Limit, float Target_Angle);
float PID_Calculate(PID_Structure* pid, float Current_Angle);
extern volatile uint8_t Road_Flag;//是否在路口的标志，0：不在路口，1：在路口
extern int16_t Grey_Current_Line_Data;
void Total_PID_Init(void);
void Car_PID_Calculate(void);
extern volatile uint8_t Question_3_Flag;//题目
// 初始化增量式PID参数
void PID_Incremental_Init(PID_Structure_Incremental* pid, 
                          float Kp, float Ki, float Kd, 
                          float DeltaOutput_Limit, float Target_Value);
float PID_Incremental_Calculate(PID_Structure_Incremental* pid, float Current_Value);
#endif
