#include "buzzer.h"


//打开蜂鸣器，PA21
void Buzzer_Open(void)
{
	DL_GPIO_clearPins(LED_PORT, LED_PIN_21_PIN);
}
//关闭蜂鸣器，PA22
void Buzzer_Close(void)
{
	DL_GPIO_setPins(LED_PORT, LED_PIN_21_PIN);
}    