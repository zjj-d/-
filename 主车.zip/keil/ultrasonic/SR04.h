#ifndef __SR04_H
#define __SR04_H

#include "move_average.h"
#include "ti_msp_dl_config.h"
#define sr04_port SR04_PORT
#define sr04_trig SR04_Trig_PIN
#define sr04_echo SR04_Echo_PIN
#define SR04_TRIG(x)  ( x ? DL_GPIO_setPins(sr04_port,sr04_trig) : DL_GPIO_clearPins(sr04_port,sr04_trig) )
#define SR04_ECHO()   ( ( ( DL_GPIO_readPins(sr04_port,sr04_echo) & sr04_echo ) > 0 ) ? 1 : 0 )

void Ultrasonic_Init(void);//超声波初始化
float Hcsr04GetLength(void );//获取超声波测距的距离
void Open_Timer(void);
void Close_Timer(void);
void SR04_Init(void);
extern volatile float SR04_Distance;
extern volatile uint8_t Sr04_Flag;
#endif