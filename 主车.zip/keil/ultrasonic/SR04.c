/*
 * 立创开发板软硬件资料与相关扩展板软硬件资料官网全部开源
 * 开发板官网：www.lckfb.com
 * 技术支持常驻论坛，任何技术问题欢迎随时交流学习
 * 立创论坛：https://oshwhub.com/forum
 * 关注bilibili账号：【立创开发板】，掌握我们的最新动态！
 * 不靠卖板赚钱，以培养中国工程师为己任
 * Change Logs:
 * Date           Author       Notes
 * 2024-07-01     LCKFB-LP    first version
 */

#include "SR04.h"

volatile unsigned int msHcCount = 0;//ms计数
volatile float distance = 0;
volatile uint8_t Sr04_Flag=0;//读取SR04的标志
/******************************************************************
 * 函 数 名 称：bsp_ultrasonic
 * 函 数 说 明：超声波初始化
 * 函 数 形 参：无
 * 函 数 返 回：无
 * 作       者：LC
 * 备       注：TRIG引脚负责发送超声波脉冲串
******************************************************************/
/******************************************************************
 * 函 数 名 称：Open_Timer
 * 函 数 说 明：打开定时器
 * 函 数 形 参：无
 * 函 数 返 回：无
 * 作       者：LC
 * 备       注：
******************************************************************/
void Open_Timer(void)
{

    DL_TimerG_setTimerCount(TIMER_SR04_INST, 0);   // 清除定时器计数

    msHcCount = 0;

    DL_TimerG_startCounter(TIMER_SR04_INST);   // 使能定时器
}

/******************************************************************
 * 函 数 名 称：Get_TIMER_Count
 * 函 数 说 明：获取定时器定时时间
 * 函 数 形 参：无
 * 函 数 返 回：数据
 * 作       者：LC
 * 备       注：
******************************************************************/
uint32_t Get_TIMER_Count(void)
{
    uint32_t time  = 0;
    time   = msHcCount*1000;                         // 得到us
    time  += DL_TimerG_getTimerCount(TIMER_SR04_INST);  // 得到ms

    DL_TimerG_setTimerCount(TIMER_SR04_INST, 0);   // 清除定时器计数
    return time ;
}

/******************************************************************
 * 函 数 名 称：Close_Timer
 * 函 数 说 明：关闭定时器
 * 函 数 形 参：无
 * 函 数 返 回：无
 * 作       者：LC
 * 备       注：
******************************************************************/
void Close_Timer(void)
{
    DL_TimerG_stopCounter(TIMER_SR04_INST);     // 关闭定时器
}

/******************************************************************
 * 函 数 名 称：TIMER_0_INST_IRQHandler
 * 函 数 说 明：定时器中断服务函数
 * 函 数 形 参：无
 * 函 数 返 回：无
 * 作       者：LC
 * 备       注：1ms进入一次
******************************************************************/
void TIMER_SR04_INST_IRQHandler(void)
{
    //如果产生了定时器中断
    switch( DL_TimerG_getPendingInterrupt(TIMER_SR04_INST) )
    {
        case DL_TIMERA_IIDX_LOAD:
                msHcCount++;
				DL_TimerG_clearInterruptStatus(TIMER_SR04_INST, DL_TIMERG_INTERRUPT_LOAD_EVENT);
            break;

        default://其他的定时器中断
            break;
    }
}


/******************************************************************
 * 函 数 名 称：Hcsr04GetLength
 * 函 数 说 明：获取测量距离
 * 函 数 形 参：无
 * 函 数 返 回：测量距离
 * 作       者：LC
 * 备       注：无
******************************************************************/
MovingAverageFilter SR04_MovingAverage_Structure;
volatile float t = 0;
volatile uint8_t SR04_ReadCnt=0;
void SR04_Init(void)
{
	Move_Avergae_Filter(&SR04_MovingAverage_Structure, 10);//SR04滑动平均滤波初始化

}

float __attribute__((optnone)) Hcsr04GetLength(void)
{
    uint32_t timeout;
    uint32_t time_us;
    
    SR04_TRIG(0);
    delay_cycles(320);
    
    SR04_TRIG(1);
    delay_cycles(480);
    SR04_TRIG(0);
    
    timeout = 0;
    while(SR04_ECHO() == 0)
    {
        delay_cycles(10);
        timeout++;
        if(timeout > 50000)
        {
            distance = 0;
            return distance;
        }
    }
    
    msHcCount = 0;
    DL_TimerG_setTimerCount(TIMER_SR04_INST, 0);
    DL_TimerG_startCounter(TIMER_SR04_INST);
    
    timeout = 0;
    while(SR04_ECHO() != 0)
    {
        timeout++;
        if(timeout > 100000)
        {
            DL_TimerG_stopCounter(TIMER_SR04_INST);
            distance = 0;
            return distance;
        }
    }
    
    DL_TimerG_stopCounter(TIMER_SR04_INST);
    time_us = msHcCount * 1000 + DL_TimerG_getTimerCount(TIMER_SR04_INST) / 10;
    distance = time_us / 58.0;
    
    if(distance > 400 || distance < 2)
        distance = 0;
    else
        distance = Update_Avergae_Filter(&SR04_MovingAverage_Structure, distance);
    
    return distance;
}