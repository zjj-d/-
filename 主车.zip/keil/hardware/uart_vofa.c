#include "uart_vofa.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h> // 字符串操作相关头文件
#include "pid.h"
#include "uart.h"
/* VOFA接收数据缓冲区 */
uint8_t g_ucVofaBuf[VOFA_DATAPACK_MAXLEN];

//volatile float Uart_KP=0, Uart_KI=0, Uart_KD=0;//VOFA+发送PID值
//volatile float Uart_Target=0;//VOFA+发送的目标值

static float vofa_get_data(uint8_t, uint8_t);
static void vofa_set_sram_data(uint8_t, float);
static void vofa_set_flash_data(float);

/* 函数实现 */

/*******************************************************************************
 * @brief   向VOFA+上位机发送指定数据，实现波形绘制
 * @return {*}
 * @note    none
 * @param {uint8_t} _dataflag     当前要打印的数据源【标志位】
 *******************************************************************************/
void vofa_draw_graphical(uint8_t _dataflag)
{
/*
    FireWater协议格式:
        "<any>:ch0,ch1,ch2,...,chN\n"
        - any 为任意字符，作为换行符（\n）的前缀，可省略
        - any 如果为"image"作为前缀，代表传输图像数据；
        - 此处 \n为换行符，对应ASCII码 换行符n
        - \n也可以为\n\r 或 \r\n  
        示例:
        VOFA_printf("%.0f,"		
					"%.0f,"
					"%.4f,"
					"%.4f,"
                    "%.4f\r\n"
					,dis_pid.target, dis_pid.current, dis_pid.kp, dis_pid.kd,  dis_pid.out);
            4个通道示例:
        VOFA_printf("channels: 1.386578,0.977929,-0.628913,-0.942729\n");
        VOFA_printf("1.386578,0.977929,-0.628913,-0.942729\n")
*/

	/* 此处写入一个分支即可，通过分支选择要打印的指定数据 */
    switch(_dataflag)
	{
        /* 左电机-速度环 */
		case PID_LEFT_MOTOR:
            VOFA_printf("%.2f,%.2f,%.2f,%2f\r\n", 
						Uart_KP,Uart_KI,Uart_KD,Uart_Target);
			break;
//		/* 角度环 */
//		case PID_ANGLE:
//            VOFA_printf("%.2f,%.2f,%.2f,%2f\r\n",
//						g_tAnglePID.current, g_tAnglePID.target, g_tAnglePID.kp, g_tAnglePID.kd);
//			break;
/*		     左电机-速度环  
		case PID_LEFT_MOTOR:
            VOFA_printf("%.2f,%.2f,%.2f,%2f\r\n", car_pid_kp, turn_pid_kp, now_speed, aim_speed);
			now_speed+=0.02;
			break;*/
        default:
            break;
	}
#if 0 /* 其他电机参考（可删除） */
    switch(_dataflag)
	{
		case _left_motor_pid:
			// 左电机速度环 目标值当前值kp ki输出
			VOFA_printf("%.2f,"		
						"%.2f,"
						"%.2f,"
						"%.2f\r\n"
						,left_Motor.pid.target, left_Motor.pid.current, left_Motor.pid.kp, left_Motor.pid.ki);
			break;
		case _right_motor_pid:
			// 右电机速度环 目标值当前值kp ki输出
			VOFA_printf("%f,"
						"%f,"
						"%f,"
						"%f\r\n"
						,right_Motor.pid.target, right_Motor.pid.current, right_Motor.pid.kp, right_Motor.pid.ki);
			break;
		case _turn_pid:
			// 转向pid（车头角度）
			VOFA_printf("%.2f,"		
						"%.2f,"
						"%.2f\r\n"
						,turn_pid.target, turn_pid.current, turn_pid.kp);
			break;
		case _angle_pid:
			// 车体转向角环；
			VOFA_printf("%.0f,"		
						"%.0f,"
						"%.2f,"
						"%.0f\r\n"
						,angle_pid.target, angle_pid.current, angle_pid.kp, angle_pid.kd);
			break;
		case _track_pid:
			// 巡线pid；偏差值，转向角环；
			VOFA_printf("%.0f,"		
						"%.0f,"
						"%.5f,"
						"%.0f\r\n"
						,track_pid.target, track_pid.current, track_pid.kp, track_pid.kd);
			break;
        case _dis_pid:
			// 距离环
			VOFA_printf("%.0f,"		
						"%.0f,"
						"%.4f,"
						"%.4f,"
                        "%.4f\r\n"
						,dis_pid.target, dis_pid.current, dis_pid.kp, dis_pid.kd,  dis_pid.out);
			break;
	}
#endif
}

/*******************************************************************************
 * @brief   串口接收字节存入缓冲区，解析VOFA上位机下发的指令包
 *                   用于VOFA+上位机向单片机下发指令并执行相应操作
 * @return {*}
 * @note    目前是实现VOFA数据解析的核心函数
 *******************************************************************************/
void vofa_set_data(uint8_t _rx_byte)
{
    static uint8_t end_pos = 0;         // 指向vofa接收缓冲区的末尾位置，记录当前下标
    static uint8_t head_pos = 0;

    /* 存储接收字节 */
    g_ucVofaBuf[end_pos] = _rx_byte;

    if (_rx_byte == VOFA_DATAPACK_HEAD) {   /* 找到帧头 */
        head_pos = end_pos;                 /* 将当前下标设为帧头位置 */
    }
    else if(_rx_byte == VOFA_DATAPACK_END && g_ucVofaBuf[head_pos] == VOFA_DATAPACK_HEAD) { /* 找到帧尾且存在帧头时 */
        /* 解析VOFA下发的数据 */
        float VofaData = vofa_get_data(head_pos, end_pos);
        
        /* 解析完成，写入指定的SRAM变量地址 */
        vofa_set_sram_data(head_pos, VofaData);

        /* 清空缓冲区及下标 */
        end_pos = 0;
        head_pos = 0;
        memset(g_ucVofaBuf, 0x00, VOFA_DATAPACK_MAXLEN);
    }

    /* 缓冲区下标自增，防止溢出 */
    if(++end_pos >= VOFA_DATAPACK_MAXLEN) {
        end_pos = 0;
        memset(g_ucVofaBuf, 0x00, VOFA_DATAPACK_MAXLEN);
    }
}

/*******************************************************************************
 * @brief   从接收缓冲区提取有效数字字符串并转换为浮点型
 * @return  转换后的浮点数值
 * @note    _head 为帧头位置，_end 为帧尾位置，有效数据起始为 _head+1
 *          c语言标准库函数,需要包含头文件 stdlib.h
 *          - atof() 执行字符串转换为浮点型
 *          - atoi() 执行字符串转换为整型
 *******************************************************************************/
static float vofa_get_data(uint8_t _head, uint8_t _end)
{
    // 固定大小缓冲区，绝对不越界
    static char buf[32] = {0};
    
    // 清空
    for(int i=0;i<32;i++) buf[i]=0;
    
    // 有效长度
    int len = _end - (_head + 1);
    if(len < 0 || len >= 32) return 0.0f;
    
    // 拷贝有效数据
    for(int i=0;i<len;i++)
    {
        buf[i] = g_ucVofaBuf[_head + 1 + i];
    }
    
    // 必须加结束符！
    buf[len] = '\0';

    // 安全转换
    return atof(buf);
}
/*******************************************************************************
 * @brief   数据解析完成后，直接写入SRAM内存，修改对应参数
 *               目前用于将解析后的值修改对应PID参数
 * @return {*}
 * @note    内存此处直接操作，效率最高
 *                                                                                                                                                                                                                                 
 * |  参数标识（用来区分是什么参数,1-2byte)   |   帧头('=',1byte)   |   数值(n byte)   |   帧尾('\n',1byte)   |
 *                                                                                                                                                                                                                                 
 *      示例:
 *       "P1=%.2f\n"
 *       "V1=%.2f\n"
 * 
 *     其中 P1/V1 为参数标识，后续可根据需求扩展，定义不同的标识对应不同的参数
 *       例如：
 *      P1 - car_pid_kp
 *      P2 - turn_pid_kp
 *      I1 - car_pid_ki
 *		I2=%.2f\n
 *   可根据实际需求自行扩展定义；
 * 
 *******************************************************************************/
static void vofa_set_sram_data(uint8_t _head, float _data)
{
    uint8_t _id_pos1 = _head - 2;   /* 参数标识的第1位 - P/I/... */
    uint8_t _id_pos2 = _head - 1;   /* 参数标识的第2位 - 1/2/3/4/...*/
	
//  角度环 [1]                                                                         
    /* P1 - g_tAnglePID.kp */
	if (g_ucVofaBuf[_id_pos1] == 'P' && g_ucVofaBuf[_id_pos2] == '1') { 
        Uart_KP = _data;
    }
    /* D1 - g_tAnglePID.kI */
    else if (g_ucVofaBuf[_id_pos1] == 'I' && g_ucVofaBuf[_id_pos2] == '1') {
        Uart_KI = _data;
    }
	/* T1 - g_tAnglePID.KD */
    else if (g_ucVofaBuf[_id_pos1] == 'D' && g_ucVofaBuf[_id_pos2] == '1') {
        Uart_KD = _data;
    }
			/* T1 - g_tAnglePID.KD */
    else if (g_ucVofaBuf[_id_pos1] == 'T' && g_ucVofaBuf[_id_pos2] == '1') {
        Uart_Target = _data;
    }
////      速度环 [2]                                                                         
//    /* P2 - g_tLeftMotorPID.kp */
//	else if (g_ucVofaBuf[_id_pos1] == 'P' && g_ucVofaBuf[_id_pos2] == '2') { 
//        g_tLeftMotorPID.kp = _data;
//    }
//    /* I2 - g_tLeftMotorPID.ki */
//    else if (g_ucVofaBuf[_id_pos1] == 'I' && g_ucVofaBuf[_id_pos2] == '2') {
//        g_tLeftMotorPID.ki = _data;
//    }
//	/* T2 - g_tAnglePID.target */
//    else if (g_ucVofaBuf[_id_pos1] == 'T' && g_ucVofaBuf[_id_pos2] == '2') {
//        g_tLeftMotorPID.target = _data;
//    }

    /* 可根据需求自行扩展 */
    /* 注意如果是整型参数 - 需要做类型转换 (int) */
}

/*******************************************************************************
 * @brief   数据解析完成后，直接写入FLASH内存，掉电不丢失
 *              目前FLASH内存相关操作未实现，需自行添加内存操作API
 * @return {*}
 * @note    none
 *******************************************************************************/
static void vofa_set_flash_data(float _data)
{
    
}