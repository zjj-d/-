#include "key.h"
#include "pid.h"
KEY_t Key_Number[3];


void Key_Init(void)
{
	for(uint8_t i=0; i<3; i++)
	{
		Key_Number[i].State = KEY_IDLE_STATE;
	}
}

void Key_Check_State(void)
{
	for(uint8_t i=0; i<3; i++)
	{

			switch(i)
			{
				case 0:
					if( DL_GPIO_readPins(K0_PORT, K0_PIN) > 0 )
					{
						if(Key_Number[i].State == KEY_IDLE_STATE)
						{
							Key_Number[i].State = KEY_DITHERING_STATE;
						}
						else if(Key_Number[i].State == KEY_DITHERING_STATE)
						{
							Key_Number[i].State = KEY_PRESSED_STATE;
						}
						else if(Key_Number[i].State == KEY_PRESSED_STATE)
						{
							Key_Number[i].State = KEY_STABLE_STATE;
						}
					}
					else
					{
						Key_Number[i].State = KEY_IDLE_STATE;
					}
					break;
				case 1:
					if( DL_GPIO_readPins(K1_PORT, K1_PIN) == 0 )
					{
						if(Key_Number[i].State == KEY_IDLE_STATE)
						{
							Key_Number[i].State = KEY_DITHERING_STATE;
						}
						else if(Key_Number[i].State == KEY_DITHERING_STATE)
						{
							Key_Number[i].State = KEY_PRESSED_STATE;
						}
						else if(Key_Number[i].State == KEY_PRESSED_STATE)
						{
							Key_Number[i].State = KEY_STABLE_STATE;
						}
					}
					else
					{
						Key_Number[i].State = KEY_IDLE_STATE;
					}
					break;
				case 2:
					if( DL_GPIO_readPins(K2_PORT, K2_PIN) == 0 )
					{
						if(Key_Number[i].State == KEY_IDLE_STATE)
						{
							Key_Number[i].State = KEY_DITHERING_STATE;
						}
						else if(Key_Number[i].State == KEY_DITHERING_STATE)
						{
							Key_Number[i].State = KEY_PRESSED_STATE;
						}
						else if(Key_Number[i].State == KEY_PRESSED_STATE)
						{
							Key_Number[i].State = KEY_STABLE_STATE;
						}
					}
					else
					{
						Key_Number[i].State = KEY_IDLE_STATE;
					}
					break;

				
				
		}
	}
}

uint8_t Key_Get_State(uint8_t Key_x)
{
	return Key_Number[Key_x].State;
}

void Key_Handle(void)
{
	/**按键检测**/
	Key_Check_State();
	for(uint8_t i=0; i<3; i++)
	{
		if(Key_Get_State(i) == KEY_PRESSED_STATE)
		{
			switch(i)
			{
				
				case 0:
					if(Question_Flag == 0)
					{
						// Page_Flag++;
						// Page_Flag %= 3;
						// Clear_Flag = 0;
						Question_3_Flag++;
					}
					else if (Question_Flag == 1 || Question_Flag == 3 || Question_Flag == 4)
					{

						Question_Circle_Num++;

					}
					
					
					
					break;
				case 1:
					Start_Flag = 1;
					Clear_KI_ALL(); //清除pid积分
					break;
				case 2:
					// Road_Flag = !Road_Flag;
					// Question_Flag = 10;
					Question_Flag++;
//					Question_Flag %= 4;
					break;
			}
		}
	}
	/**按键检测**/
}