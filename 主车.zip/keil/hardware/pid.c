#include "bno08x_uart_rvc.h"
#include "pid.h"
#include "motor.h"
#include "encoder.h"
#include "uart.h"
#include "gw_grayscale_sensor.h"
#include "stdio.h"
#include "SR04.h"
#include "UART_host.h"
#include "Fuzzy_pid.h"
#include "cradle_head.h"
#include "No_Mcu_Ganv_Grayscale_Sensor_Config.h"

// 初始化PID控制器
void PID_Init(PID_Structure* pid, float Kp, float Ki, float Kd, float Output_Limit, float Target_Value) 
{
    pid->Kp = Kp;
    pid->Ki = Ki;
    pid->Kd = Kd;
    pid->Output_Limit = Output_Limit;
    pid->Prev_Error = 0.0f;
    pid->Integral = 0.0f;
	pid->Target_Value = Target_Value;
}
FuzzyPIDController FZ_Grey_BlackLine_Pid;
PID_Structure Speed_Left_Pid;//左轮PID初始化,0.5-·1m/s的PID
PID_Structure Speed_Right_Pid;//右轮PID初始化,0.5-1m/s的PID;


PID_Structure Grey_BlackLine_Pid;//灰度循迹PID
PID_Structure NO_Speed_Turn_Pid_Out;//无速度转向外环
PID_Structure NO_Speed_Turn_Pid_In;//无速度转向内环
PID_Structure Target_Tracking_X;
PID_Structure Target_Tracking_Y;
PID_Structure Distance_Pid;  //超声波距离PID

PID_Structure PID_Structure_Steer_X;//步进电机增量式PID结构体
PID_Structure PID_Structure_Steer_Y;//步进电机增量式PID结构体
// PID_Structure_Incremental PID_Structure_Steer_X;//步进电机增量式PID结构体
// PID_Structure_Incremental PID_Structure_Steer_Y;//步进电机增量式PID结构体

/*步进电机跟踪陀螺仪结构体*/
PID_Structure PID_Structure_Steer_BNO08X_X;//步进电机跟踪陀螺仪PID结构体
PID_Structure PID_Structure_Steer_BNO08X_Y;//步进电机
void Total_PID_Init(void) 
{
	/**无速度转向环**/
	PID_Init(&NO_Speed_Turn_Pid_Out,  5, 0, 0, 160, 0);
	PID_Init(&NO_Speed_Turn_Pid_In,  -16, -0.5, 6, 4000, 0);
	/**无速度转向环**/

	/**速度环**/
//	PID_Init(&Speed_Left_Pid, 15, 0.35, 0, 4000, 0);//左轮PID初始化,1m/s以内的PID**
//	PID_Init(&Speed_Right_Pid,  15, 0.35, 0, 4000, 0);//右轮PID初始化,1m/s以内的PID**
//	PID_Init(&Speed_Left_Pid, 13, 0.528, 0, 4000, 0);//左轮PID初始化,1m/s以内的PID**
//	PID_Init(&Speed_Right_Pid,  13, 0.528, 0, 4000, 0);//右轮PID初始化,1m/s以内的PID**
//	PID_Init(&Speed_Left_Pid, 16, 0.3, 0, 4000, 0);//左轮PID初始化,0.7m/s以内的PID**
//	PID_Init(&Speed_Right_Pid,  16, 0.3, 0, 4000, 0);//右轮PID初始化,0.7m/s以内的PID**
		PID_Init(&Speed_Left_Pid, 30, 1.2, 0, 4000, 0);//左轮PID初始化,高速PID**
	PID_Init(&Speed_Right_Pid,  30, 1.2, 0, 4000, 0);//右轮PID初始化,高速PID**
	/**速度环**/
		/*超声波距离PID*/
	PID_Init(&Distance_Pid,  1, 0, -0.5, 150, 0);//超声波距离控制
	/**灰度循迹PID */
//	PID_Init(&Grey_BlackLine_Pid,  0.90, -0.45, -0, 70, 0);//灰度循迹PID，0.3m/s 0.45
//	PID_Init(&Grey_BlackLine_Pid,  0.95, -0, -0.3, 100, 0);//灰度循迹PID，0.4m/s 0.45
		PID_Init(&Grey_BlackLine_Pid,  1.2, 0, -0.5, 120, 0);//灰度循迹PID，高速稳定版**
	/**灰度循迹PID */

	/**步进电机PID */

	// PID_Init(&PID_Structure_Steer_X, -0.061, -0.038, 0.051, 200, 0);//左轮PID初始化,1m/s以内的PID**
	// PID_Init(&PID_Structure_Steer_Y,  -0.061, -0.034, 0, 200, 0);//右轮PID初始化,1m/s以内的PID**
	PID_Init(&PID_Structure_Steer_X, -0.098, -0.002, 0.055, 200, 0);//左轮PID初始化,1m/s以内的PID**
	PID_Init(&PID_Structure_Steer_Y,  -0.079, -0.002, 0.003, 200, 0);//右轮PID初始化,1m/s以内的PID**
	// PID_Incremental_Init(&PID_Structure_Steer_X, 0, 0, 0, 20, 0);
	// PID_Incremental_Init(&PID_Structure_Steer_Y, 0, 0, 0, 20, 0);
	
	
	
	/**步进电机PID 跟踪陀螺仪*/
	PID_Init(&PID_Structure_Steer_BNO08X_X,-0.098, -0.002, 0.055, 200, 0);
	PID_Init(&PID_Structure_Steer_BNO08X_Y, 0, 0, 0.0, 200, 0);
}




// 单级PID计算函数（角度输入）
float PID_Calculate(PID_Structure* pid, float Current_Value) 
{
	// 1. 计算当前误差
	float Error = pid->Target_Value - Current_Value;

	// 2. 积分项计算（带抗饱和）
	pid->Integral += Error;
	// 积分限幅防止饱和
	if (pid->Integral > pid->Output_Limit) pid->Integral = pid->Output_Limit;
	else if (pid->Integral < -pid->Output_Limit) pid->Integral = -pid->Output_Limit;

	// 3. 微分项计算（使用两次误差差）
	float derivative = Error - pid->Prev_Error; // KD采用两次误差差

	// 4. 计算PID输出
	float Output = (pid->Kp * Error)           // 比例项
				+ (pid->Ki * pid->Integral)    // 积分项
				+ (pid->Kd * derivative);      // 微分项（重点）

	// 5. 输出限幅
	if (Output > pid->Output_Limit) Output = pid->Output_Limit;
	else if (Output < -pid->Output_Limit) Output = -pid->Output_Limit;

	// 6. 更新误差记录
	pid->Prev_Error = Error;

	return Output;
}
// 单级PID计算函数,微分项采用陀螺仪角速度
float PID_Calculate_2(PID_Structure* pid, float Current_Value, int16_t Angle_Speed) 
{
	// 1. 计算当前误差
	float Error = pid->Target_Value - Current_Value;

	// 2. 积分项计算（带抗饱和）
	pid->Integral += Error;
	// 积分限幅防止饱和
	if (pid->Integral > pid->Output_Limit) pid->Integral = pid->Output_Limit;
	else if (pid->Integral < -pid->Output_Limit) pid->Integral = -pid->Output_Limit;



	// 4. 计算PID输出
	float Output = (pid->Kp * Error)           // 比例项
				+ (pid->Ki * pid->Integral)    // 积分项
				+ (pid->Kd * Angle_Speed);      // 微分项（重点）

	// 5. 输出限幅
	if (Output > pid->Output_Limit) Output = pid->Output_Limit;
	else if (Output < -pid->Output_Limit) Output = -pid->Output_Limit;

	return Output;
}

// 角度环专用PID函数
float PID_Calculate_No_Speed(PID_Structure* pid, float Current_Value, int16_t Angle_Speed) 
{
	// 1. 计算当前误差
	float Error = pid->Target_Value - Current_Value;
    if (Error > 180) 
	Error -= 360;   // 误差>180°时顺时针修正
    else if(Error < -180) 
	Error += 360; // 误差<-180°时逆时针修正

	// 2. 积分项计算（带抗饱和）
	pid->Integral += Error;
	// 积分限幅防止饱和
	if (pid->Integral > pid->Output_Limit) pid->Integral = pid->Output_Limit;
	else if (pid->Integral < -pid->Output_Limit) pid->Integral = -pid->Output_Limit;



	// 4. 计算PID输出
	float Output = (pid->Kp * Error)           // 比例项
				+ (pid->Ki * pid->Integral)    // 积分项
				+ (pid->Kd * Angle_Speed);      // 微分项（重点）

	// 5. 输出限幅
	if (Output > pid->Output_Limit) Output = pid->Output_Limit;
	else if (Output < -pid->Output_Limit) Output = -pid->Output_Limit;

	return Output;
}

// 初始化增量式PID参数
void PID_Incremental_Init(PID_Structure_Incremental* pid, 
                          float Kp, float Ki, float Kd, 
                          float DeltaOutput_Limit, float Target_Value) 
{
    pid->Kp = Kp;
    pid->Ki = Ki;
    pid->Kd = Kd;
    pid->DeltaOutput_Limit = DeltaOutput_Limit;
    pid->Target_Value = Target_Value;
    pid->Prev_Error = 0.0f;
    pid->Prev_Error2 = 0.0f;
}

// 增量式PID计算函数（返回控制增量）
float PID_Incremental_Calculate(PID_Structure_Incremental* pid, float Current_Value) 
{
    // 1. 计算当前误差
    float Error = pid->Target_Value - Current_Value;

    // 2. 计算增量式PID三项
    float P = pid->Kp * (Error - pid->Prev_Error);           // 比例项：当前与上次误差差
    float I = pid->Ki * Error;                              // 积分项：当前误差
    float D = pid->Kd * (Error - 2*pid->Prev_Error + pid->Prev_Error2); // 微分项：误差变化率

    // 3. 计算控制增量
    float DeltaOutput = P + I + D;

    // 4. 增量限幅（防止突变）
    if (DeltaOutput > pid->DeltaOutput_Limit) 
        DeltaOutput = pid->DeltaOutput_Limit;
    else if (DeltaOutput < -pid->DeltaOutput_Limit) 
        DeltaOutput = -pid->DeltaOutput_Limit;

    // 5. 更新误差记录
    pid->Prev_Error2 = pid->Prev_Error;
    pid->Prev_Error = Error;

    return DeltaOutput;  // 返回控制增量
}

int16_t Left_Speed_PID_Out;
int16_t Right_Speed_PID_Out;
int16_t Angle_PID_Out=0;



/**状态机参数**/

// 全局变量定义
extern unsigned short Anolog[8];
extern unsigned short black[8];
extern unsigned short white[8];
extern unsigned short Normal[8];
extern No_MCU_Sensor sensor;              // 传感器数据结构体
extern unsigned char Digtal;							 // 数字量
/**状态机参数**/
int16_t Grey_Current_Line_Data=0;
//int16_t Weight_Grey[5]={65, 38, -0, -38, -65};//0.3-0.5m/s权重
int16_t Weight_Grey[8]={-65, -38, -18, -3, 3, 18, 38, 65};//0.8m/s权重
volatile uint8_t Road_Flag=1;//判断一次路口左转,0:左转中，1：直行中,2:直行起步阶段，不判断转弯
volatile uint8_t Road_Flag_Last=0;//判断一次路口左转,0:左转中，1：直行中
volatile uint8_t Stop_Flag=0;//停止标志位，1：停止
volatile int16_t Grey_Speed=70;//灰度循迹速度  
volatile uint8_t Out_in_flag = 1;  //1为外圈，2为内圈
volatile uint8_t sensor_count = 0;               // 检测到黑线的传感器数量
volatile uint8_t Grey[8];//OLED显示用
void Calculate_Grey_Data(void)
{
    static int16_t last_grey_data = 0;      // 上一次的偏差值（用于丢线保持）
    Grey_Data = 0;
    volatile uint8_t Weight_Tem[8] = {0};
		sensor_count = 0;
		No_Mcu_Ganv_Sensor_Task_Without_tick(&sensor);
//			//获取传感器数字量结果(只有当有黑白值传入进去了之后才会有这个值！！)
		Digtal=Get_Digtal_For_User(&sensor);
		Weight_Tem[0] = !((Digtal>>0)&0x01);
		Weight_Tem[1] = !((Digtal>>1)&0x01);
		Weight_Tem[2] = !((Digtal>>2)&0x01);
		Weight_Tem[3] = !((Digtal>>3)&0x01);
		Weight_Tem[4] = !((Digtal>>4)&0x01);
		Weight_Tem[5] = !((Digtal>>5)&0x01);
		Weight_Tem[6] = !((Digtal>>6)&0x01);
		Weight_Tem[7] = !((Digtal>>7)&0x01);
		
    for (int n = 0; n < 8; n++)  
    {
			Grey[n] = Weight_Tem[n];
        if(Weight_Tem[n] == 1)
				{
        sensor_count+=1;
	
				}
		}
    // ---------- 正常循迹----------
   if(Road_Flag == 1)
	 {
		if(Out_in_flag == 1) //外圈
		{
			for (int8_t i = 3; i >= 0; i--)
			{
				if(Weight_Tem[i] == 1)
				{
					Grey_Current_Line_Data = Weight_Grey[i];
				}
			
			}
			for (uint8_t i = 4; i < 8; i++)
			{
				if(Weight_Tem[i] == 1)
				{
					Grey_Current_Line_Data = Weight_Grey[i];
				}
			}
		}
		else if(Out_in_flag == 2) //内圈
		{
			for (uint8_t i = 4; i < 8; i++)
			{
				if(Weight_Tem[i] == 1)
				{
					Grey_Current_Line_Data = Weight_Grey[i];
				}
			}
			for (int8_t i = 3; i >= 0; i--)
			{
				if(Weight_Tem[i] == 1)
				{
					Grey_Current_Line_Data = Weight_Grey[i];
				}
			
			}	
		}
		if(sensor_count >= 6)
		{Grey_Current_Line_Data = 0;}
	}
}
int32_t Grey_Black_Line_PID_Out=0;
int32_t Distance_PID_Out=0;
extern volatile float HC_distance;//超声波距离
 /**灰度循迹串级PID **/
void Execute_PID_INTimer_Grey_Black(void)
{

	Calculate_Grey_Data();//处理灰度传感器数据
 	Grey_BlackLine_Pid.Target_Value = 0;//设置循迹PID目标值
//	Distance_Structure.Target_Value = 0;//设定距离值
//	  Speed_Right_Pid.Kp = Uart_KP;
//	  Speed_Right_Pid.Ki = Uart_KI;
//	 Speed_Right_Pid.Kd = -Uart_KD;
//		Speed_Right_Pid.Target_Value =Uart_Target;
	
//	Grey_BlackLine_Pid.Kp = Uart_KP;
//	Grey_BlackLine_Pid.Ki = Uart_KI;
//	Grey_BlackLine_Pid.Kd = -Uart_KD;	
//	Grey_BlackLine_Pid.Kp = Uart_KP;
//	Grey_BlackLine_Pid.Ki = Uart_KI;
//	Grey_BlackLine_Pid.Kd = -Uart_KD;	
	Grey_Black_Line_PID_Out = PID_Calculate(&Grey_BlackLine_Pid, Grey_Current_Line_Data);//灰度循迹PID,外环
//	sprintf(Str_Data, "%d, %d\r\n", Grey_Current_Line_Data, Grey_Black_Line_PID_Out);
//	uart0_send_string(UART_0_TEST_INST , Str_Data);
	// Grey_Black_Line_PID_Out = (int32_t)FuzzyPID_Compute(&FZ_Grey_BlackLine_Pid, 0, (float)Grey_Current_Line_Data);
	// sprintf(Str_Data, "%f, %f, %f, %f\n", FZ_Grey_BlackLine_Pid.Kp, FZ_Grey_BlackLine_Pid.Ki, FZ_Grey_BlackLine_Pid.Kd, Uart_Target);
	// uart0_send_string(UART_0_TEST_INST , Str_Data);
	Speed_Left_Pid.Target_Value = Grey_Speed - Grey_Black_Line_PID_Out ;//读取串口发的速度，速度一般0.5m/s，1m/s
	Speed_Right_Pid.Target_Value = Grey_Speed + Grey_Black_Line_PID_Out ;//读取串口发的速度，速度一般0.5m/s，1m/s

 	Left_Speed_PID_Out = (int32_t)PID_Calculate(&Speed_Left_Pid, EncoderCnt_L);//计算左轮速度环PID
 	Right_Speed_PID_Out = (int32_t)PID_Calculate(&Speed_Right_Pid, EncoderCnt_R);//计算右轮速度环PI
	sprintf(Str_Data, "%d, %d,%.2f,%.2f\r\n", Grey_Current_Line_Data, Grey_Black_Line_PID_Out,EncoderCnt_L,EncoderCnt_R);
	uart0_send_string(UART_0_TEST_INST , Str_Data);
	PWM_Output(MOTOR_LEFT, Left_Speed_PID_Out);//PWM作用到电机
	PWM_Output(MOTOR_RIGHT, Right_Speed_PID_Out);//PWM作用到电机
}
void cong_Execute_PID_INTimer_Grey_Black(void)  //从车巡线
{

	Calculate_Grey_Data();//处理灰度传感器数据
 	Grey_BlackLine_Pid.Target_Value = 0;//设置循迹PID目标值
//	Distance_Structure.Target_Value = 0;//设定距离值
//	  Speed_Right_Pid.Kp = Uart_KP;
//	  Speed_Right_Pid.Ki = Uart_KI;
//	 Speed_Right_Pid.Kd = -Uart_KD;
//		Speed_Right_Pid.Target_Value =Uart_Target;
	
//	Grey_BlackLine_Pid.Kp = Uart_KP;
//	Grey_BlackLine_Pid.Ki = Uart_KI;
//	Grey_BlackLine_Pid.Kd = -Uart_KD;	

	Distance_Pid.Target_Value = 50;	

	Distance_PID_Out = PID_Calculate(&Distance_Pid, HC_distance);
	if (HC_distance < 2.0f || HC_distance > 70.0f) {
		Distance_PID_Out = 0;
		Distance_Pid.Integral  = 0;
}
	Grey_Black_Line_PID_Out = PID_Calculate(&Grey_BlackLine_Pid, Grey_Current_Line_Data);//灰度循迹PID,外环

//	sprintf(Str_Data, "%d, %d\r\n", Grey_Current_Line_Data, Grey_Black_Line_PID_Out);
//	uart0_send_string(UART_0_TEST_INST , Str_Data);
	// Grey_Black_Line_PID_Out = (int32_t)FuzzyPID_Compute(&FZ_Grey_BlackLine_Pid, 0, (float)Grey_Current_Line_Data);
	// sprintf(Str_Data, "%f, %f, %f, %f\n", FZ_Grey_BlackLine_Pid.Kp, FZ_Grey_BlackLine_Pid.Ki, FZ_Grey_BlackLine_Pid.Kd, Uart_Target);
	// uart0_send_string(UART_0_TEST_INST , Str_Data);
	Speed_Left_Pid.Target_Value = Grey_Speed - Distance_PID_Out - Grey_Black_Line_PID_Out ;//读取串口发的速度，速度一般0.5m/s，1m/s
	Speed_Right_Pid.Target_Value = Grey_Speed - Distance_PID_Out + Grey_Black_Line_PID_Out ;//读取串口发的速度，速度一般0.5m/s，1m/s
if(Speed_Left_Pid.Target_Value > 100)
{Speed_Left_Pid.Target_Value = 100;}
if(Speed_Right_Pid.Target_Value>100)
{Speed_Right_Pid.Target_Value = 100;}
 	Left_Speed_PID_Out = (int32_t)PID_Calculate(&Speed_Left_Pid, EncoderCnt_L);//计算左轮速度环PID
 	Right_Speed_PID_Out = (int32_t)PID_Calculate(&Speed_Right_Pid, EncoderCnt_R);//计算右轮速度环PI
	PWM_Output(MOTOR_LEFT, Left_Speed_PID_Out);//PWM作用到电机
	PWM_Output(MOTOR_RIGHT, Right_Speed_PID_Out);//PWM作用到电机
}
int16_t NO_Speed_Turn_TarhetAngle=0;

int16_t Get_Angle_Turn_90(void)
{
	if(bno08x_data.yaw > 90)
	{
		return (bno08x_data.yaw - 270);
	}
	else 
	{
		return bno08x_data.yaw + 90;
	}
	
}
 /**固定角度转动PID **/
int32_t NO_Speed_Turn_PID_Value_Out=0;//外环输出
int32_t NO_Speed_Turn_PID_Value_In=0;//内环输出
void NO_Speed_Turn_PID(void)
{
//	 NO_Speed_Turn_Pid_Out.Kp = Uart_KP;
//	 NO_Speed_Turn_Pid_Out.Ki = Uart_KI;
//	 NO_Speed_Turn_Pid_Out.Kd = -Uart_KD;

	NO_Speed_Turn_Pid_Out.Target_Value = NO_Speed_Turn_TarhetAngle;
	
	// NO_Speed_Turn_Pid_In.Kp = -Uart_KP;
	// NO_Speed_Turn_Pid_In.Ki = -Uart_KI;
	// NO_Speed_Turn_Pid_In.Kd = Uart_KD;
	
	

	NO_Speed_Turn_PID_Value_Out = (int32_t)PID_Calculate_No_Speed(&NO_Speed_Turn_Pid_Out, bno08x_data.yaw, bno08x_data.az);//灰度循迹PID,外环
	NO_Speed_Turn_Pid_In.Target_Value = NO_Speed_Turn_PID_Value_Out;
	NO_Speed_Turn_PID_Value_In = (int32_t)PID_Calculate(&NO_Speed_Turn_Pid_In, bno08x_data.az);//灰度循迹PID,内环

	PWM_Output(MOTOR_LEFT, NO_Speed_Turn_PID_Value_In);//PWM作用到电机
	PWM_Output(MOTOR_RIGHT, -NO_Speed_Turn_PID_Value_In);//PWM作用到电机
}


uint16_t PID_Tartget_X=270;
uint16_t PID_Tartget_Y=110;
// uint16_t PID_Tartget_X_3=265;//第三问目标
// uint16_t PID_Tartget_Y_3=115;
int32_t PID_Target_Tracking_X_Out=0;
int32_t PID_Target_Tracking_Y_Out=0;
volatile uint16_t Red_X = 0;
volatile uint16_t Red_Y = 0;



uint16_t Last_Data_X=0;
uint16_t Last_Data_Y=0;
uint8_t Q3_Stop_Flag=0;

uint8_t KI_Clear_Flag=0;
void Clear_KI_ALL(void)//清除所有的PID积分
{
	/**无速度转向环**/
	NO_Speed_Turn_Pid_Out.Integral = 0;
	NO_Speed_Turn_Pid_In.Integral = 0;
	/**无速度转向环**/

	/**速度环**/
	Speed_Left_Pid.Integral = 0;
	Speed_Right_Pid.Integral = 0;

	/**速度环**/
	
	/**灰度循迹PID */
	Grey_BlackLine_Pid.Integral = 0;

}
volatile uint8_t Question_3_Flag=1;//题目圈速
volatile uint8_t Question_Circle_Num=1;//题目圈速
volatile uint8_t Steer_Init_Flag=10;//题目电机初始化标志
volatile uint8_t Question1_Stage=0;//0:循迹，1转弯
volatile uint16_t Question_Cnt=0;//计时
volatile uint16_t Question2_Stop_Flag=0;//计时
volatile uint8_t Question4_Start_Flag=0;//发挥1的小车启动标志
volatile float yaw_last=0;//发挥12的上次偏航角
// volatile float bno08x_data.yaw_Trans=0;//偏航角转为360
volatile uint8_t zu_cong_flag = 0;  //0第一圈，1第二圈，2第三圈
volatile uint8_t grey_flag=0;
volatile uint8_t cross_detected_flag = 0;  // 上升沿锁存标志
volatile float last_distance;
volatile uint8_t last_distance_flag = 0;   // 0:未记录，1:已记录
void Car_PID_Calculate(void)
{
	switch(Question_Flag)
	{
		case 1://题目1
			Grey_Speed = 30;
			switch(Question_Circle_Num)
			{
				case 1:
					Out_in_flag = 1;
					if(sensor_count >= 4 && (Distance_Left +Distance_Right)/2 > 30)
					{
						Stop_Flag = 1;
					}
					break;
				case 2:
					Out_in_flag = 2;
					if(sensor_count >= 4 && (Distance_Left +Distance_Right)/2 > 30)
					{
						Stop_Flag = 1;
					}
					break;
					default:
			break;
				}
			if(Stop_Flag == 0)//未停止时
			{
				Execute_PID_INTimer_Grey_Black();
			}
			else 
			{
				Motor_Stop();//关闭电机
			}
			break;
		case 2:  // 题目2
			Grey_Speed = 50;
			Out_in_flag = 1;  //跑外圈
			if(sensor_count >= 4 && (Distance_Left +Distance_Right)/2 > 600)   //距离判断停止圈数
					{
						Stop_Flag = 1;
					}
			if(Stop_Flag == 0)//未停止时
			{
				Execute_PID_INTimer_Grey_Black();
			}
			else 
			{
				Motor_Stop();//关闭电机
			}
			break;		
		case 3: //题目3
		{
				// ---------- 上升沿检测：每次横线只计一次 ----------
				if (sensor_count > 6 && cross_detected_flag == 0)
				{
						grey_flag++;                // 圈数 +1
						cross_detected_flag = 1;    // 锁存，防止重复加
				}
				if (sensor_count <= 3)          // 传感器回落，清零锁存
				{
						cross_detected_flag = 0;
				}

				// ---------- 根据圈数设置主/从车标志 ----------
				if (grey_flag == 0)
						zu_cong_flag = 0;           // 第一圈：主车
				else if (grey_flag == 1)
				{
					zu_cong_flag = 1;  
					if (last_distance_flag == 0)          // 只在第一次赋值
					{
						last_distance = (Distance_Left + Distance_Right) / 2;
						last_distance_flag = 1;           // 锁定
					}
				}
					// 第二圈：从车
				
				else if (grey_flag >= 2)
						zu_cong_flag = 2;           // 第三圈及以后：主车（内圈）

				// ---------- 内外圈标志 ----------
				if (zu_cong_flag <= 1)
						Out_in_flag = 1;            // 外圈
				else
						Out_in_flag = 2;            // 内圈

				// ---------- 停车条件：跑完三圈后停车 ----------
				if(grey_flag >= 3 &&sensor_count > 6)
				{Grey_Speed = 0;
				Stop_Flag =1;}

				// ---------- 第二圈从车启动逻辑（超声波检测前车） ----------
				if (zu_cong_flag == 1 && HC_distance > 40 && HC_distance <= 70)
				{
						Motor_Start();
						Stop_Flag = 0;
				}
				else 
				{Grey_Speed = 0;}

				// ---------- 运行控制 ----------
				if (Stop_Flag == 0)
				{
						if (zu_cong_flag == 0)               // 第一圈主车
						{
								Grey_Speed = 30;
								Execute_PID_INTimer_Grey_Black();
						}
						else if (zu_cong_flag == 1)          // 第二圈从车
						{
							if((Distance_Left + Distance_Right) / 2 - last_distance <= 220)
							{
								Grey_Speed = 30;
							Execute_PID_INTimer_Grey_Black();}
							else 
							{Grey_Speed = 45;
							cong_Execute_PID_INTimer_Grey_Black();}
								
						}
						else if (zu_cong_flag == 2)          // 第三圈主车内圈
						{
								Grey_Speed = 60;
								Execute_PID_INTimer_Grey_Black();
						}
				}
				else
				{
						Motor_Stop();   // 停止
				}
		}

					break;
					case 4: //题目4
				PID_Init(&Grey_BlackLine_Pid,  1.6, 0, -0.7, 150, 0);//灰度循迹PID，高速稳定版**
				Grey_Speed = 100;
			Execute_PID_INTimer_Grey_Black();
		default:
			break;
	}
}

void Test_Speed_Loop_Only(void)
{
    // 1. 直接使用上位机发送的目标值（或固定目标）
		Speed_Left_Pid.Kp = Uart_KP;
	  Speed_Left_Pid.Ki = Uart_KI;
	  Speed_Left_Pid.Kd = -Uart_KD;
    Speed_Left_Pid.Target_Value = Uart_Target;   // 上位机可实时修改

    
    // 2. 计算左轮速度环PID输出
    Left_Speed_PID_Out = (int32_t)PID_Calculate(&Speed_Left_Pid, EncoderCnt_L);
    
    // 3. 输出PWM（右轮可以给相同值，或单独控制）
    PWM_Output(MOTOR_LEFT, Left_Speed_PID_Out);
    //PWM_Output(MOTOR_RIGHT, Left_Speed_PID_Out);  // 双轮同速，便于直线运动
	sprintf(Str_Data, "%.2f, %.2f\r\n", Uart_Target, EncoderCnt_L);
	uart0_send_string(UART_0_TEST_INST , Str_Data);
}